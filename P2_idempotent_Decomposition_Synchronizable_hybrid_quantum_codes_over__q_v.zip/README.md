# Idempotent QSC Source Package

This is a focused, non-destructive source bundle containing the requested TeX,
BibTeX, program files, README, supporting data, tests, and related materials.

## Main files

| What you need | Path |
|---|---|
| Current authoritative TeX manuscript | `submission/Idempotent_QSC_FINAL.tex` |
| Current authoritative BibTeX bibliography | `submission/references.bib` |
| Supplied manuscript PDF | `submission/Idempotent_QSC_FINAL.pdf` |
| Supplied compiled bibliography | `submission/Idempotent_QSC_FINAL.bbl` |
| Current package census program | `code/branch_census.py` |
| Recorded census output | `code/branch_census_output.json` |
| Independent-check program | `code/independent_checks.py` |
| Supporting Python programs | `supporting_programs/python/` |
| Supporting tests | `supporting_programs/tests/` |
| Supporting build/conversion tools | `supporting_programs/tools/` |
| Supporting MAGMA programs | `supporting_programs/magma/` |
| Input data | `data/` |
| Generated tables | `tables/` |
| Figure asset | `figures/` |
| Optional blank author-response form | `author_response/PHASE5K_AUTHOR_RESPONSE_TEMPLATE.md` |
| File hashes/provenance | `SHA256SUMS.txt`, `provenance/` |

## Source priority

`submission/Idempotent_QSC_FINAL.tex` and
`submission/references.bib` are the current authoritative manuscript source and
bibliography. The materials under `supporting_programs/`, `data/`, `tables/`,
and `figures/` are supplied supporting research artifacts. They do not replace
the authoritative submission source.

## Important limits

- This archive copies existing files only; it does not apply a manuscript
  correction or represent any pending proposal as approved.
- The supplied PDF is included as an existing artifact. This archive does not
  claim a fresh successful build or source/PDF identity verification.
- The author-response form is blank. No approval is inferred from it.
- T4/Gray-map/A1 remains unverified and is not included as an authorized
  manuscript asset.
- Phase 6 and Phase 7 are not started by this package.

**Final status: AWAITING EXPLICIT AUTHOR CONFIRMATION**
