"""Independent re-check of key manuscript claims with sympy (not the authors' code)."""
import itertools, math
from sympy import Poly, symbols, GF as sGF, factor_list
x = symbols('x')

def P(coeffs_low_first, p):
    return Poly(list(reversed(coeffs_low_first)), x, modulus=p)

def recip(g, p):
    c = g.all_coeffs()  # high first
    r = Poly(list(reversed(c)), x, modulus=p)
    return r.monic() if not r.is_zero else r

def ordx(f, p, n):
    for e in range(1, n + 1):
        if (Poly(x**e - 1, x, modulus=p).rem(f)).is_zero:
            return e
    return None

def dual_containing(g, p, n):
    # C=<g>, C^perp subseteq C  iff  g | h*  , h=(x^n-1)/g
    xn = Poly(x**n - 1, x, modulus=p)
    h = xn.quo(g)
    hs = recip(h, p)
    return hs.rem(g).is_zero

def codewords(g, p, n):
    k = n - g.degree()
    gc = [int(c) % p for c in reversed(g.all_coeffs())]
    gc += [0] * (n - len(gc))
    out = []
    for msg in itertools.product(range(p), repeat=k):
        w = [0] * n
        for i, m in enumerate(msg):
            if m:
                for j in range(n):
                    w[(i + j) % n] = (w[(i + j) % n] + m * gc[(j) % n]) % p
        out.append(tuple(w))
    return out

def cyclic_shift_basis(g, p, n):
    return None

# ---------- flagship ----------
p, n = 3, 13
gC = P([1, 0, 1, 0, 0, 1, 1], p)
gD = P([2, 1, 1, 1], p)
xn = Poly(x**n - 1, x, modulus=p)
print("gC | x^n-1:", xn.rem(gC).is_zero, " gD | gC:", gC.rem(gD).is_zero)
f = gC.quo(gD)
print("f =", f.all_coeffs(), " deg f", f.degree(), " ord_x f =", ordx(f, p, n))
print("C dual-containing:", dual_containing(gC, p, n), " k_C", n - gC.degree(), " k_D", n - gD.degree())
C = set(codewords(gC, p, n)); D = set(codewords(gD, p, n))
h = xn.quo(gC); gCp = recip(h, p)
Cp = set(codewords(gCp, p, n))
print("|C|,|D|,|Cp|", len(C), len(D), len(Cp), " Cp<=C", Cp <= C, " C<=D", C <= D)
w = lambda v: sum(1 for a in v if a)
print("d(C)", min(w(v) for v in C if any(v)), " d(D)", min(w(v) for v in D if any(v)))
print("min wt C\\Cp", min(w(v) for v in C - Cp), " min wt D\\Cp", min(w(v) for v in D - Cp))
print("factors of x^13-1 over F3:", [ (fa.all_coeffs(), m) for fa, m in xn.factor_list()[1]])

# ---------- existence criterion census ----------
def minus1_in_q(q, n):
    s, t = set(), 1
    for _ in range(n + 1):
        s.add(t % n); t = t * q % n
    return (n - 1) % n in s

bad = 0; tot = 0
for q in [3, 5, 7, 11, 13, 17, 19, 23]:
    for n in range(2, 41):
        if math.gcd(n, q) != 1: continue
        xn = Poly(x**n - 1, x, modulus=q)
        facs = [fa.monic() for fa, _ in xn.factor_list()[1]]
        nonself = any(recip(fa, q) != fa for fa in facs)
        tot += 1
        if nonself != (not minus1_in_q(q, n)):
            bad += 1; print("MISMATCH", q, n)
print(f"existence criterion: {tot} (q,n) pairs checked by factorisation, mismatches {bad}")

# ---------- classical single branch at (7,10) ----------
q, n = 7, 10
xn = Poly(x**n - 1, x, modulus=q)
facs = [fa.monic() for fa, _ in xn.factor_list()[1]]
best = max(ordx(fa, q, n) for fa in facs)
print("(7,10): -1 in <7> mod 10:", minus1_in_q(7, 10), "; best classical single-branch period (C=<p> in F_q^n):", best)
print("   factors/orders:", [(fa.all_coeffs(), ordx(fa, q, n)) for fa in facs])

# ---------- Remark 2.2 q=3 idempotents ----------
# e2=(v^2+v)/2, 1/2=2 mod 3 -> 2v^2+2v
print("q=3: e2 = 2v^2+2v (no constant term); e3 = 2v^2+v")
