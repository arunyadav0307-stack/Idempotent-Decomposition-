# PACKAGE_INVENTORY — Phase 0
**Audit target:** *Idempotent Decomposition and Synchronizable Hybrid Subsystem Quantum Codes over $\mathbb{F}_q[v]/(v^3-v)$*
**Date of inspection:** 2026-10-14 (Asia/Calcutta) · **Auditor:** Arena.ai agent (automated audit, Phase 0)
**Audit workspace:** `/home/user/audit/` (git-versioned; baseline commit `438b3ae`, second commit `1a8c1a8`)

---

## 1. Provenance of the input package

| Step | Result |
|---|---|
| Workspace scan for the specified ZIP at session start | **Not present** — workspace `/home/user/` was empty; no attachment arrived. |
| Fallback: specified repository `https://github.com/arunyadav0307-stack/Idempotent-Decomposition-` | **Reachable.** `git ls-remote` HEAD = `211ad06068d154c58e0aa6aa346e4ffad762d24d` (branch `main`). |
| Clone | `/home/user/audit/repo_baseline/Idempotent-Decomposition-` (read-only reference). |
| Input ZIP located **inside the repository** | `Audit 1 Idempotent Decomposition and Synchronizable Hybrid Subsystem Quantum Codes over.zip` — exact filename specified in the audit order. Retrieved from the repository and copied to `original_package/`. |

Repository history (all commits, `git log --format="%h %ad %s" --date=iso`):

| Commit | Date (+0530) | Content |
|---|---|---|
| `fc0e3e3` | 2026-09-30 05:49 | Initial commit (README only) |
| `9a70a4e` | 2026-09-30 06:12 | `Idempotent Decomposition ... over.zip` (baseline research package, 679,338 B) |
| `211ad06` | 2026-10-13 20:36 | `Audit 1 ... .zip` (419,805 B) + `Quantum Synchronizable.zip` (10,692,025 B) |

The audit input is therefore the most recent upload (2026-10-13) and post-dates the baseline package (2026-09-30) — consistent with `INTERNAL_QC/CHANGELOG.md`, which dates the revision to 2026-09-30.

## 2. Archive-level integrity record

Preserved verbatim in `/home/user/audit/original_package/` (never modified; hashes also in `original_package/SHA256SUMS.txt`):

| File | Bytes | SHA-256 | MD5 |
|---|---|---|---|
| `Audit 1 Idempotent Decomposition and Synchronizable Hybrid Subsystem Quantum Codes over.zip` | 419,805 | `f78457485edcc95831bb58083e0af8d90336d2ed70813765e9360d403ee41b45` | `5147ff5833b19acbcb75a5003b1fe14d` |
| `Idempotent Decomposition and Synchronizable Hybrid Subsystem Quantum Codes over.zip` | 679,338 | `f49fe5dcaea729067cbfd759b8e4f036df7d931d4951307b64de764659198a67` | `2dbc6bccfa338131dac6750199e6160f` |
| `Quantum Synchronizable.zip` | 10,692,025 | `03b7b761caee621add73d4ec93766858ecf3c63f4d95f54ec86d30b9966a1224` | `2045e0fb32446000e1218cbff3274874` |

Extractions (working copies, unmodified): `working/audit1_extracted/`, `working/base_extracted/`, `working/qs_extracted/`.
Per-file hash manifests: `working/audit1_extracted/AUDIT1_FILE_HASHES.txt` (13 files), `BASE_FILE_HASHES.txt` (56 files), `QS_FILE_HASHES.txt` (12 files).

## 3. Inventory A — Audit-1 package (authoritative audit input, 13 files)

Extracted at `working/audit1_extracted/`. SHA-256 abbreviations from `AUDIT1_FILE_HASHES.txt`.

| Path | Bytes | SHA-256 (first 12) | Role |
|---|---|---|---|
| `submission/Idempotent_QSC_FINAL.tex` | 42,412 | `160ceca5ab4a` | **Authoritative manuscript source** (515 lines, `amsart`, BibTeX/`amsplain`) |
| `submission/Idempotent_QSC_FINAL.pdf` | 396,402 | `765106f0317f` | Compiled PDF; metadata: pdfTeX-1.40.25, `LaTeX with hyperref`, created `D:20260930011849Z` |
| `submission/Idempotent_QSC_FINAL.bbl` | 3,516 | `d07a4f24aea4` | Compiled bibliography (16 entries) |
| `submission/references.bib` | 4,979 | `3d6af14d2b1a` | BibTeX source, 16 entries |
| `code/branch_census.py` | 2,879 | `6bacee798a2c` | Exhaustive branch census (sympy) backing Table 4/`tab:census` |
| `code/branch_census_output.json` | 10,654 | `572cb56285ad` | Census output: 81 (q,n) pairs, 20,724 branches, all with e>deg f |
| `INTERNAL_QC/CHANGELOG.md` | 4,732 | `5c324b092027` | Prior-audit change record (2026-09-30): 10 mathematical corrections, notation, structure, build |
| `INTERNAL_QC/VALUE_LEDGER.csv` | 6,655 | `df37bbe43aca` | Prior-audit ledger: ~65 quantities, baseline vs. final value, status, evidence |
| `INTERNAL_QC/REVIEWER_QA.md` | 2,643 | `f0c2c631b1dd` | Prior-audit adversarial review: 13 objections + 5 anticipated referee questions |
| `INTERNAL_QC/AUTHOR_DECISIONS.md` | 1,560 | `d505ee5cc69e` | Open author decisions (authors, journal, 3 unverified references, AI disclosure, title) |
| `INTERNAL_QC/VOICE_CHANGES.md` | 2,174 | `d16281e63dac` | Language/voice changes made in prior revision |
| `INTERNAL_QC/independent_checks.py` | 3,399 | `e9bc73962dce` | Prior-audit independent sympy checks (flagship, existence census, (7,10) classical pair) |
| `README.md` | 473 | `9efd7dacb975` | Package map |

## 4. Inventory B — Baseline research package (56 files)

Extracted at `working/base_extracted/`; full hashes in `BASE_FILE_HASHES.txt`. Key groups:

| Group | Files | Notes |
|---|---|---|
| Manuscript (pre-audit baseline) | `manuscript/FINAL_MANUSCRIPT.{md,tex,pdf}`, `PDF_COMPILATION_STATUS.md` | Baseline TeX = 549 lines; PDF reported 17 pp.; abstract contains the claims later corrected (7883/8794 "exhaustive", window-neutral obstruction claim, `[[39,3:9,0,≥3]]₃`) |
| Project reports | `FINAL_RESEARCH_REPORT.{md,txt}`, `README.md`, `INDEX.txt` | Self-declared status "VALIDATED" (pre-audit); README references `research_package_2026-09-29.zip` (89 files) — **not present in this package** |
| Python sources | `src/python/` 7 modules (130–770 lines each, stdlib-only): `finite_field.py`, `ring_r.py`, `cyclic_codes.py`, `synchronization.py`, `quantum_css.py`, `experiments.py`, `pdf_extract.py` | Deterministic; generate the 9 data tables |
| MAGMA | `src/magma/ring_qsc.m` (189 lines), `verify_tables.m` (35 lines) | Declared **never executed** (no MAGMA interpreter at authoring time) |
| Tests | `tests/test_theorems.py` (364 l), `test_theory.py` (407 l), `test_quantum.py` (350 l) | Claimed 751 checks/0 failures; 8794 sampled pairs; quantum suite |
| Data | `data/tables.json` (209 rows), `examples.{csv,json}`, `flagship_candidates.json`; `tables/table{2,3,4,5,7,8,9,10}*.csv` | `data/README.md` warns against conflating quantum vs. classical fusion data sets |
| Results/logs | `results/verification_report.md`, `*_checks.json`, `*_log.txt`, `*_run*.txt` | Claimed run dates 2026-09-29/30 |
| Figures | `figures/interleaved_lift.svg` | Pre-audit figure (superseded by TikZ Fig. 1 in Audit-1 tex) |
| Bibliography | `bibliography/references.bib` (8 entries), `references_verified.csv` (13 records) | Audit-1 revision expanded to 16 entries |
| Tools | `src/tools/build_pdf.sh`, `src/tools/md2tex.py` | Baseline build path (md → tex → pdf) |

Spot-consistency of lineage data (checked in Phase 0, will be re-verified in Phase 3): `tables/table8_flagship.csv` row 1 = (q,n)=(3,13), g_C=1+x²+x⁵+x⁶, g_D=2+x+x²+x³, k=(7,10), d=(4,3), deg f=3, e=13, window 12 — matches Audit-1 Table 1/Example 4.5; `table10_hybrid.csv` (3,13) y=1 collisions {3,10} — matches Audit-1 Table 2 row 2.

## 5. Inventory C — Literature package (12 PDFs)

Extracted at `working/qs_extracted/Quantum Synchronizable/`. Content (by filename): Fujiwara PRA 87/88 (`0239-0252.pdf`, `1206.0260v5.pdf`), `Algebraic techniques in designing quantum synchronizable codes.pdf`, Tansuwannont–Nemec preprint (`2409.11312v2.pdf`), plus 8 journal PDFs (QIP/DCC/CAM/IMCS series identifiers incl. `s40314-023-02298-7.pdf` = Du–Ma–Liu 2023). These are the primary sources for the Phase 4 attribution audit — the paper's central external dependency (Tansuwannont–Nemec) is available locally.

## 6. Authoritative version determination

1. **Authoritative manuscript:** `submission/Idempotent_QSC_FINAL.tex` (Audit-1 ZIP). It post-dates and explicitly supersedes `manuscript/FINAL_MANUSCRIPT.tex` (baseline ZIP) per `INTERNAL_QC/CHANGELOG.md` ("Baseline: manuscript/FINAL_MANUSCRIPT.tex … Final: submission/Idempotent_QSC_FINAL.tex").
2. **Audit history:** one prior audit round ("Audit 1", 2026-09-30) is documented by `INTERNAL_QC/*` and, on the baseline side, by `results/verification_report.md` and the logs. The prior round claims 10 mathematical corrections (detailed in `BASELINE_STATUS.md` §3). **Every prior-audit claim is itself an input to be re-verified, not a fact to inherit.**
3. **Supporting computation:** base package `src/python` + `tests/` (authors' implementation) and Audit-1 `code/branch_census.py` + `INTERNAL_QC/independent_checks.py` (auditor implementations).
4. **Known gap:** `research_package_2026-09-29.zip` (89 files, full process record) is referenced by the baseline README but is not present; its absence limits provenance checks on the pre-audit process (does not block the audit — all manuscript-facing artifacts are present).

## 7. Build environment (this sandbox)

| Item | Status |
|---|---|
| OS / arch | Debian GNU/Linux 13 (trixie), x86_64 |
| Python | 3.13.16 (`/usr/local/bin/python3`) |
| sympy / numpy | 1.14.0 / 2.3.5 — sufficient for ring arithmetic, factorization over GF(q), order computations, exhaustive enumeration |
| git / unzip | 2.47.3 / present |
| LaTeX | **not installed** (no pdflatex/latexmk/tectonic). `sudo` available and `apt` candidate `texlive-latex-base 2024.20250309-1` exists → installable in Phase 7 for the rebuild check |
| SageMath / MAGMA / GAP | **not available**; MAGMA files could not have been run by the authors either (declared in baseline README). Computational audit will use Python/sympy with independent re-implementations |
| Network | Available (git clone succeeded); literature DOI verification possible in Phase 4 |

## 8. Preservation measures taken

1. Original ZIPs copied to `original_package/` with SHA-256 + MD5 recorded (`SHA256SUMS.txt`); originals remain untouched in `repo_baseline/`.
2. Read-only extractions under `working/*_extracted/`; per-file SHA-256 manifests generated for all three archives.
3. Audit workspace is a git repository (`main`), baseline commit `438b3ae` ("Phase 0: baseline preservation"), reference clone excluded from tracking (`1a8c1a8`).
4. All corrections in later phases will be made in `working/corrected/` (to be created in Phase 1), never in `original_package/`, `repo_baseline/`, or the extraction directories.
