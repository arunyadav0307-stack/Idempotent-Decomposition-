# Phase 5K — Author Response Template

**Purpose:** collect explicit author responses only. This template reproduces the
11 current decision entries from
`PHASE5J_AUTHOR_DECISION_REVIEW_SHEET.md`, including the independently
answerable D8(a) and D8(b) entries. It records no author response, approval, or
instruction at creation.

**Source decision-review document:**
`PHASE5J_AUTHOR_DECISION_REVIEW_SHEET.md`  
**Source SHA-256:**
`3f07a700477a2e61cf1061f65e6575c8a973ccfcb44a11bc11e6562ceeb98789`  
**Date prepared:** 2026-10-16  
**Final status:** **AWAITING EXPLICIT AUTHOR CONFIRMATION**

## Response instructions

- Every selection box below is intentionally blank. Only the author may mark
  `APPROVE`, `REJECT`, `MODIFY`, or `NEEDS DISCUSSION`.
- An `APPROVE` response, if supplied later, confirms only the decision entry as
  stated. It does not by itself authorize a manuscript edit, a build, Phase 6,
  or Phase 7.
- If selecting `MODIFY` or `NEEDS DISCUSSION`, provide the requested wording,
  scope, facts, conditions, or evidence in the rationale field.
- The **evidence-supported technical finding** describes what the existing
  record establishes. The **editorial or scope choice** remains for the author.
  **Missing author-specific information or evidence** must not be guessed or
  inferred from silence.
- D8(a) and D8(b) are independent. A response to one does not answer the
  other.

## Safeguards retained from the decision review

- P2-01 is supported only as a **zero-gauge specialization** under the printed
  containment. This template does not claim a nontrivial-gauge subsystem
  construction.
- T4/Gray-map/A1 remains **UNVERIFIED — NOT AUTHORIZED FOR THIS MANUSCRIPT**.
- No existing register, plan, audit record, manuscript, bibliography, script,
  or table is altered by this template.
- Phase 6 remains blocked and Phase 7 remains stopped.

---

# D1 — P2-01 framework route

**Original decision/question:** Which route governs the Remark 5.5
subsystem/gauge discussion?

**Current proposal:** **PROPOSED — NOT APPROVED:** retain the verified
zero-gauge/stabilizer-specialization route; do not claim a nontrivial-gauge
subsystem construction without a separate rigorous proof, explicit hypotheses,
and separately verified examples.

**Evidence-supported technical finding:** The printed containment
`C_z^perp subseteq C_x` forces `r=0` and implies the cited Theorem-10 emptiness
conditions. The displayed formulas remain valid as a zero-gauge/hybrid-
stabilizer specialization. The current record does not establish a generalized
nonzero-gauge q-ary ring/interleaved/common-frame construction.

**Editorial or scope choice for the author:** Choose whether to retain the
conservative zero-gauge route, pursue a separately proved broadened research
route, or remove the general subsystem discussion.

**Missing author-specific information or evidence:** If pursuing a broadened or
modified route, provide the intended scope, rigorous proof/evidence basis,
explicit hypotheses, and separately verified examples.

```text
D1 — AUTHOR RESPONSE (leave blank until completed by the author):
[ ] APPROVE    [ ] REJECT    [ ] MODIFY    [ ] NEEDS DISCUSSION
Author rationale or requested change:
____________________________________________________________________________
____________________________________________________________________________
```

---

# D2 — Title/scope framing

**Original decision/question:** Should the manuscript retain “Subsystem”
framing, or be narrowed to a hybrid quantum-code framing with a qualified
structural subsystem remark?

**Current proposal:** **PROPOSED — NOT APPROVED:** prefer hybrid quantum-code
framing consistent with the verified mathematical results, subject to exact
title, abstract, keyword, conclusion, and reviewer-facing scope review after
D1 is confirmed.

**Evidence-supported technical finding:** The evaluated construction has zero
gauge qudits under the printed containment. The verified symmetric construction
is not changed by a title or scope choice.

**Editorial or scope choice for the author:** Select a framing consistent with
the D1 route: retain “Subsystem” only if justified by that route, or use hybrid
quantum-code framing with a qualified structural subsystem remark.

**Missing author-specific information or evidence:** Exact author-approved
title, abstract, keyword, conclusion, and venue-facing scope wording after D1
is selected.

```text
D2 — AUTHOR RESPONSE (leave blank until completed by the author):
[ ] APPROVE    [ ] REJECT    [ ] MODIFY    [ ] NEEDS DISCUSSION
Author rationale or requested title/scope change:
____________________________________________________________________________
____________________________________________________________________________
```

---

# D3 — Inactive-component convention

**Original decision/question:** How should synchronization/fusion statements
treat a component with `C_i=D_i`?

**Current proposal:** **PROPOSED — NOT APPROVED:** require strict branches in
all relevant synchronization/fusion statements, thereby avoiding the undefined
`ord_x(1)` case.

**Evidence-supported technical finding:** The source permits `C_i=D_i` while
defining `f_i` and `e_i=ord_x(f_i)` for all components; then `f_i=1`, and
`ord_x(1)` is not defined. No rigorous inactive-component convention is in the
current record.

**Editorial or scope choice for the author:** Confirm the strict-branch route
or choose to pursue a rigorously proved inactive-component convention.

**Missing author-specific information or evidence:** For an alternative or
modified route, provide the convention, proof basis, and affected
revision/check scope for every use of `f_i`, `e_i`, lcm, collision sets, and
markers.

```text
D3 — AUTHOR RESPONSE (leave blank until completed by the author):
[ ] APPROVE    [ ] REJECT    [ ] MODIFY    [ ] NEEDS DISCUSSION
Author rationale or requested convention/change:
____________________________________________________________________________
____________________________________________________________________________
```

---

# D4 — Published Table-5 computation domain

**Original decision/question:** What computation domain should be represented
by Table 5 and its surrounding empirical claims?

**Current proposal:** **PROPOSED — NOT APPROVED:** document the actual 15-prime
computational domain; preserve the verified 74-family and 29-factor-greater-
than-one counts only within that documented domain; do not imply an exhaustive
scan of all odd primes up to 101.

**Evidence-supported technical finding:** The shipped 74/29 values reproduce on
the hard-coded 15-prime list. Independent audit evidence found 107/38 for an
all-odd-primes-`q<=101` scope, but that result is not an author-frozen
publication data set.

**Editorial or scope choice for the author:** Retain and disclose the existing
15-prime computation, or provide an author-frozen full-stratum replacement and
choose the corresponding publication scope.

**Missing author-specific information or evidence:** For the full-stratum
route, provide the author-frozen computation/data set, output mapping, and
authorization for changed counts, rows, footnote, and scope language.

```text
D4 — AUTHOR RESPONSE (leave blank until completed by the author):
[ ] APPROVE    [ ] REJECT    [ ] MODIFY    [ ] NEEDS DISCUSSION
Author rationale or requested computation-domain change:
____________________________________________________________________________
____________________________________________________________________________
```

---

# D5 — AUD1-P1-01 marker-boundary correction

**Original decision/question:** Should the known false marker-boundary sentence
be corrected in the selected submission source?

**Current proposal:** **PROPOSED — NOT APPROVED:** apply the preserved minimal
factual repair without extending Table 2’s marker range unless separately
approved and verified.

**Evidence-supported technical finding:** The source says collisions occur for
`y >= deg f`; the audit establishes injectivity at `y=deg f` and first failure
at `y >= deg f+1`. The current printed `0 <= y <= deg f-1` Table-2 range is
valid.

**Editorial or scope choice for the author:** Authorize the preserved minimal
repair or explicitly defer it. This decision is distinct from D8(b)’s possible
range expansion.

**Missing author-specific information or evidence:** None is required for the
preserved minimal repair. A modified or expanded route needs the author’s
intended scope and the separate verification required by D8(b).

```text
D5 — AUTHOR RESPONSE (leave blank until completed by the author):
[ ] APPROVE    [ ] REJECT    [ ] MODIFY    [ ] NEEDS DISCUSSION
Author rationale or requested correction/scope change:
____________________________________________________________________________
____________________________________________________________________________
```

---

# D6 — Author/venue/disclosure/bibliography authorization

**Original decision/question:** What author/venue/disclosure information should
be supplied, and may verified citation and bibliography fixes be authorized as
a batch? Should these be handled as a bundled workflow or as sequential
approvals with dependencies?

**Current proposal:** **PROPOSED — NOT APPROVED:** use D6-B sequential
approvals for metadata, venue, disclosures, and bibliography/citation work.

**Evidence-supported technical finding:** Five bibliography/reference facts are
verified, but the author/venue/disclosure facts and a granular approval sequence
are not supplied. Venue-specific requirements cannot be inferred.

**Editorial or scope choice for the author:** Select D6-A (one bundled
decision) or D6-B (sequential decisions with dependencies), and state whether
any verified citation/bibliography fixes may proceed before venue finalization.

**Missing author-specific information or evidence:** Final author names/order,
affiliations, corresponding contact e-mail, ORCID information if used, target
venue, venue policies, funding, conflict-of-interest, CRediT, AI-disclosure
facts or allowed not-applicable disposition, and the exact authorization
sequence/sub-batches.

```text
D6 — AUTHOR RESPONSE (leave blank until completed by the author):
[ ] APPROVE    [ ] REJECT    [ ] MODIFY    [ ] NEEDS DISCUSSION
Author rationale or requested workflow change; D6-A/D6-B and required inputs:
____________________________________________________________________________
____________________________________________________________________________
```

---

# D7 — Reproducibility and data availability

**Original decision/question:** What frozen release facts may be named in the
manuscript’s reproducibility statement? If no frozen public release is supplied,
what narrow, truthful data-availability statement may replace or qualify the
current one-line URL statement?

**Current proposal:** **PROPOSED — NOT APPROVED:** use only the existing
evidence-supported limited data-availability statement; do not claim a frozen
public release, archive, DOI, tag, commit, or complete public reproducibility
package unless one is actually supplied and verified.

**Evidence-supported technical finding:** The supplied package includes a
branch-census program, its recorded census output, and an independent-check
script. It does not establish a broader baseline test suite, version-pinned
release manifest, tag/commit reference, archival DOI, or complete public
reproducibility package.

**Editorial or scope choice for the author:** Confirm the limited
package-bounded statement or provide an alternative that remains within the
same evidence boundary; choose a stronger claim only after its release evidence
is supplied and verified.

**Missing author-specific information or evidence:** For a stronger claim,
provide an actual release identifier, manifest/hashes, environment, supported
commands, data/script paths, seed/cap details, claim/table-to-artifact mapping,
and any D6-dependent venue requirements.

```text
D7 — AUTHOR RESPONSE (leave blank until completed by the author):
[ ] APPROVE    [ ] REJECT    [ ] MODIFY    [ ] NEEDS DISCUSSION
Author rationale or requested data-availability/release change:
____________________________________________________________________________
____________________________________________________________________________
```

---

# D8 — Capacity/payload presentation and optional marker-range scope

D8 is retained as one top-level decision with two independently answerable
entries below. Complete D8(a) and D8(b) separately.

## D8(a) — Full hybrid capacity versus selected payload

**Original decision/question:** Does the author authorize a clarification that
distinguishes the flagship’s formal hybrid capacity `M=9` from the four-symbol
synchronized payload selected by `(y_1,y_2,y_3)=(0,2,2)`?

**Current proposal:** **PROPOSED — NOT APPROVED:** clarify the distinction
between the full formal hybrid capacity `M=9` and the selected four-symbol
payload.

**Evidence-supported technical finding:** Proposition 3.1 defines `M`; Example
5.4 gives `[[39,3:9,0,3]]_3` and the selected `(0,2,2)` four-symbol use. The
record supports `M=9`, four selected payload symbols, and a twelve-cell window;
it does not supply an alternative parameter convention.

**Editorial or scope choice for the author:** Confirm the clarification or
supply a different evidence-bounded presentation. The choice must not silently
re-parameterize the code.

**Missing author-specific information or evidence:** For an alternative
presentation, provide the author’s exact terminology/wording and its
evidence-bound justification.

```text
D8(a) — AUTHOR RESPONSE (leave blank until completed by the author):
[ ] APPROVE    [ ] REJECT    [ ] MODIFY    [ ] NEEDS DISCUSSION
Author rationale or requested capacity/payload presentation change:
____________________________________________________________________________
____________________________________________________________________________
```

## D8(b) — Optional `y=deg f` marker-range expansion

**Original decision/question:** Does the author wish to expand the manuscript’s
marker-family discussion and/or Table 2 scope through `y=deg f`, beyond
correcting the false sentence at line 315?

**Current proposal:** **PROPOSED — NOT APPROVED:** defer the optional expansion
and retain the valid current Table-2 range.

**Evidence-supported technical finding:** Distinct residues persist at
`y=deg f`, while the current printed `0 <= y <= deg f-1` range is valid.
Boundary distinctness alone does not establish a blanket publication expansion.

**Editorial or scope choice for the author:** Retain the current range or
explicitly choose a separately verified boundary expansion. This choice is
independent of the D5 factual correction.

**Missing author-specific information or evidence:** For expansion, provide the
intended scope and authorization for row-level distinctness, collision-set,
window, and guarantee checks; Theorem-5.2 review; and coordinated review of
§5.1, Table 2/caption, examples, capacity/payload presentation, abstract, and
conclusion.

```text
D8(b) — AUTHOR RESPONSE (leave blank until completed by the author):
[ ] APPROVE    [ ] REJECT    [ ] MODIFY    [ ] NEEDS DISCUSSION
Author rationale or requested marker-range scope change:
____________________________________________________________________________
____________________________________________________________________________
```

---

# D9 — Novelty scope and literature limits

**Original decision/question:** Should the manuscript strengthen novelty/priority
language only after missing full texts are obtained, or retain qualified language
based on the existing source coverage?

**Current proposal:** **PROPOSED — NOT APPROVED:** retain qualified novelty
wording consistent with the existing literature audit and its stated
limitations.

**Evidence-supported technical finding:** The current audit supports central
results within the examined corpus but does not turn scope-limited negative
evidence into an unqualified priority fact. Phase-4 U4-1/U4-2 identify missing
full-text coverage relevant to stronger external novelty/priority conclusions.

**Editorial or scope choice for the author:** Retain qualified wording or
authorize acquisition and direct review of the missing full texts before a
stronger claim is considered.

**Missing author-specific information or evidence:** For a stronger
novelty/priority route, provide or authorize the missing full texts and direct
source comparison; any final stronger wording must follow that review.

```text
D9 — AUTHOR RESPONSE (leave blank until completed by the author):
[ ] APPROVE    [ ] REJECT    [ ] MODIFY    [ ] NEEDS DISCUSSION
Author rationale or requested novelty/literature-review change:
____________________________________________________________________________
____________________________________________________________________________
```

---

# D10 — Future production/build pass

**Original decision/question:** When, if ever, should a clean production/build
pass be authorized?

**Current proposal:** **PROPOSED — NOT APPROVED:** perform production/build/PDF
verification only after approved corrections and required author inputs are
available in a frozen correction set.

**Evidence-supported technical finding:** No clean rebuild, log inspection,
regenerated-PDF review, source/PDF identity check, citation-rendering check, or
final metadata review has been performed. Current source/PDF rebuild identity
and final production readiness remain unverified.

**Editorial or scope choice for the author:** Confirm a conditional later
production gate or explicitly defer the production pass. No production action
starts from this template.

**Missing author-specific information or evidence:** Before any later
production activity, a frozen author-approved correction set and separate
production authorization are required.

```text
D10 — AUTHOR RESPONSE (leave blank until completed by the author):
[ ] APPROVE    [ ] REJECT    [ ] MODIFY    [ ] NEEDS DISCUSSION
Author rationale or requested production-gate change:
____________________________________________________________________________
____________________________________________________________________________
```

---

# Completeness and stop point

- This template contains exactly 11 independent response fields: D1–D7,
  D8(a), D8(b), D9, and D10.
- All response boxes remain unselected and all rationale/requested-change fields
  remain blank.
- No approval is inferred from silence, previous proposals, or assistant
  recommendations.
- No manuscript, bibliography, correction plan, decision register, or other
  existing record has been edited by preparing this template.
- No Phase 6 or Phase 7 activity is authorized or started.

**Final status: AWAITING EXPLICIT AUTHOR CONFIRMATION**
