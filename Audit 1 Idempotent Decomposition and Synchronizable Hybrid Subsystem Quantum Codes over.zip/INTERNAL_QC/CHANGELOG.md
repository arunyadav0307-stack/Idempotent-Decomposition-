# CHANGELOG — manuscript revision (2026-09-30)

Baseline: `manuscript/FINAL_MANUSCRIPT.tex` inside the uploaded zip (unchanged in the repository).
Final: `submission/Idempotent_QSC_FINAL.tex` / `.pdf`, `submission/references.bib`.

## Scientific / mathematical corrections
1. **Theorem 4.5 (fused threshold)** — baseline said the multi-component window is "the same as, or smaller than, that of its best component — never larger". False: `lcm(e1,e2,e3) >= max e_i`. Corrected to `max_i e_i <= e_R <= n` (Thm 4.6).
2. **Corollary 4.10 ("the obstruction is the quantum condition")** — false as a claim about the maximal window. Without dual containment, `e | n` still holds and the single classical pair `C=<Phi_n factor>` in `F_q^n` has `e=n` (checked independently for (7,10): factor x^4-x^3+x^2-x+1 has order 10). Rewritten as Remark 4.9: dual containment decides existence; the cap comes from `e | n`. Abstract, intro and discussion changed accordingly.
3. **Theorem 4.3 / census** — baseline headline "7883 of 8794 exhaustively checked branch pairs (89.6%)" was (a) a seeded random sample, not exhaustive, and (b) of nested pairs C<D *without* dual containment, over q<=17, n<=20 (not q<=13, n<=16 as stated). Replaced by new Proposition 4.4 (proof: `x-1` never divides `g_C` for dual-containing C, so `deg f <= e-1`; the degree bound is *never* sharp for quantum branches) and an exhaustive census of all 20724 genuine branches (code/branch_census.py). The 8794 sample is kept only as a spot check of Thm 4.2.
4. **Flagship code conflation** — baseline claimed `[[39,3:9,0,>=3]]_3` *with* a 12-cell window. With all 9 message symbols in use the window collapses (Table 10 shows y=1 -> 2, y=2 -> 0). Corrected: hybrid code `[[39,3:9,0,3]]_3`; in synchronization mode the new Proposition 5.3 (joint collision set = intersection) gives window 12 with 4 ternary message symbols for marker lengths (0,2,2) (verified with the authors' `hybrid_collisions`). Distance ">=3" sharpened to "=3".
5. **Hybrid markers** — messages are distinguishable only for `y <= deg f - 1`; 5 of 12 rows of old Table 10 (y >= deg f) are degenerate and were removed from the paper table; the restriction is stated.
6. **Existence criterion** — identified as the dual-containing counterpart of Massey (1964) reversible codes / Yang–Massey (1994); novelty claim removed. Garbled Lemma 2.5/2.6 and Thm 2.7 proof rewritten; Lemma 2.6's claim that *all* factors pair up when `-1 notin <q>` was wrong (x-1 is always self-reciprocal) — restricted to factors of Phi_n.
7. **Novelty positioning** — q-ary sufficiency of `a_l+a_r < ord_x(f)` is known (Xie–Yang–Yuan 2016; Luo–Ma 2018; Luo–Ma–Lin 2019). Removed the claim that the result is re-derived "because the char-2 proof does not transfer". Contribution is now stated as necessity + complete collision set.
8. **Table 7 claim** "criterion confirmed in all 58 pairs" — only 22 pairs were enumerated (all existence cases). Replaced by: factorisation check of 275 pairs + enumeration of 22 pairs.
9. **Table 9 claim** "n attainable in all 13 tested cases" — one case (13,4) has no d>=2 branch; now "all 12 cases". Witness distances in the CSV are min wt(D\C), not D\C^perp; column dropped, equivalence of the >=2 constraint proved in a footnote.
10. Typos with mathematical content: Remark 2.2 `e2 = 2+2v+2v^2` -> `2v+2v^2`; Prop 3.1 `d_X = min wt(C\C^perp)` -> `D\C^perp`; gauge scalar `iI` -> `omega I`; relaxation list "x6 at (61,30)" -> x5; "three times the degree bound" -> 12 vs 2; Cor 4.10 "window 9 twice 4" -> thresholds 10 = 2 x 5.

## Notation
- Idempotents renamed `e_i -> eta_i` (clash with periods `e_i`).
- `q_1` (used for two different objects) removed; marker residue `beta`.
- Marker set `M -> \mathcal{M}_y` (clash with message count M); distance `D -> d` (clash with code D).
- Automatic theorem numbering with labels (baseline used hard-coded numbers that were inconsistent with the intro list).

## Structure / compliance
- Removed: pipeline `\thanks` ("automated research pipeline"), file names, commands, test-suite timings, "Files and commands" appendix, "Verification index", MAGMA remarks, "frozen decision" / "Model A/B" jargon, self-referential audit sentences.
- Added: theorem environments, BibTeX (`amsplain`, `references.bib`), TikZ Figure 1 (interleaved lift), booktabs tables 1–6, data-availability statement, author/affiliation placeholders.
- Bibliography: 8 -> 16 entries; all cited. New: FTW13, FV14, XYY16, LM18, LML19, SEA23, Massey 1964, Yang–Massey 1994.
- Removed `lmodern`/T1 (not needed; amsart default fonts).

## Build
pdflatex + bibtex + 2x pdflatex: 0 errors, 0 undefined references/citations, 0 overfull boxes, 11 pages.
