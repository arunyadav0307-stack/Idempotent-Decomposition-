# VOICE / LANGUAGE CHANGES (representative; the manuscript was rebuilt section by section)

| Location | Original | Revised | Category |
|---|---|---|---|
| \thanks | "Produced by an automated research pipeline; no author identity is asserted…" | removed; author placeholders | pipeline/AI trace |
| Abstract | "The paper proves three things about this setting and reports them with the computation that produced them." | removed; findings stated directly | meta-commentary |
| Abstract | "All numerical values come from three deterministic programs and nine data tables (209 rows); the manuscript separates what is proved, what is computed…" | "All numerical statements were checked by exhaustive computation, including a census of all 20724 dual-containing branches…" | software-report language |
| Intro | "This paper studies the second extension in the smallest honest case" | "This paper answers both questions for the smallest ring with three components" | inflated/defensive |
| Intro | "We consider it part of the contribution that the third question has a negative answer… refuted by our own computation… documented in RESEARCH_GAP_AND_NOVELTY.md" | removed | project history / file name |
| Intro | "Novelty, stated precisely" / "Contributions, statement by statement" subsections | one prose paragraph + 4-item list | artificial headings |
| Sec. 3 | "The model (frozen decision) … recorded in quantum_model_decision.md. We work with Model A" | "Quantum model" subsection, no file or model labels | internal trace |
| Sec. 3 | "(The frequently misquoted count 3n + a_l + a_r is not what this model gives…)" | removed | defensive |
| Sec. 6 | table of commands, run times, file names | three short paragraphs describing what was computed and how | software report |
| Sec. 7 | "What the ring provably does not buy", "Declared limitations", "No priority claimed" | concise conclusions with 6 findings + one limitations paragraph | defensive chain |
| Throughout | "\texttt{7883}", "\texttt{e - 1}" typewriter numbers | plain math | typography |
| Throughout | "synchronisation" / "synchronization" mixed | "synchronization" (American) | consistency |
