# ADVERSARIAL REVIEW — questions, weaknesses, status

| # | Reviewer angle | Objection | Status |
|---|---|---|---|
| 1 | Validity | Baseline "no-gain is caused by the quantum condition" is false (classical sup is also n). | FIXED (Remark 4.9) |
| 2 | Validity | Baseline Thm 4.5 said fusion never exceeds best component per triple; lcm >= max. | FIXED (Thm 4.6) |
| 3 | Mathematics | Garbled Lemma 2.5/2.6, Thm 2.7 proof; wrong pairing claim. | FIXED (rewritten proofs) |
| 4 | Mathematics | Notation clashes e_i, q_1, M, D. | FIXED |
| 5 | Numerics | "Exhaustive 8794 branch pairs" was a random sample of non-quantum pairs. | FIXED (proof + exhaustive census of 20724 branches) |
| 6 | Validation | Existence census claimed 58 confirmations; only 22 enumerated. | FIXED (275-pair factorisation + 22 enumerations, stated precisely) |
| 7 | Novelty | q-ary order criterion already known; existence criterion equivalent to Massey 1964. | FIXED (repositioned; citations added). REMAINING: contribution is modest — main risk at a Q1 venue. |
| 8 | Claims | Flagship claimed 9 message symbols AND 12-cell window simultaneously. | FIXED (Prop 5.3, Example 5.4: 4 symbols with window 12) |
| 9 | Claims | Hybrid rows with y >= deg f are not valid codes. | FIXED |
| 10 | Reproducibility | Paper cited internal file paths; code not referenced publicly. | FIXED (data-availability statement; internal paths removed) |
| 11 | Figures | No figure; model hard to visualise. | FIXED (Fig. 1 TikZ) |
| 12 | Language | Audit/pipeline language, "honest", "frozen decision", verification index. | FIXED |
| 13 | Editor | No authors, pipeline disclaimer in \thanks → desk reject. | AUTHOR DECISION (placeholders) |

## Likely referee questions (with suggested answers)
1. *Is the no-gain theorem more than `e | n`?* — It is elementary; its value is correcting the common assumption that ring fusion increases synchronization capability, plus Lemma 4.7 (a period-n branch exists whenever any branch exists).
2. *What is new relative to Xie–Yang–Yuan / Luo–Ma?* — Necessity and the complete collision set (Thm 4.2), the strict gap `deg f <= e-1` for all quantum branches (Prop 4.4), the fusion analysis, and the joint hybrid window (Prop 5.3).
3. *Why only cell-aligned offsets?* — The interleaved lift defines the frame at cell level; sub-cell offsets need a different error model (stated as open).
4. *Is the distance of the flagship competitive?* — d=3 on 39 qudits is modest; the example illustrates the window gap, not distance optimality.
5. *Prime powers?* — Arguments are field-independent; the computations used prime fields only.
