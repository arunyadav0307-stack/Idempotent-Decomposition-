# Idempotent-Decomposition-
Research Paper

- `submission/` — revised manuscript (`Idempotent_QSC_FINAL.tex/.pdf`), `references.bib`, compiled `.bbl`.
- `code/branch_census.py` — exhaustive census of dual-containing branches used in Table 3 (requires `sympy`); `branch_census_output.json` is its output.
- The uploaded zip holds the original manuscript, the table-generating programs and their data.
- `INTERNAL_QC/` — internal revision records (not for submission).
