# VERIFICATION REPORT (Phases 13–14 deliverable)

All numbers below were produced by the programs in `src/python` and `tests/` on
2026-09-29; raw output is in `results/*.txt` and `results/*_checks.json`.

## 1. Suites

| Suite | Command | Result | Log / JSON |
|---|---|---|---|
| Theorem suite | `python3 tests/test_theorems.py` | **751 checks, 0 failures** (27.2 s idle; 46.5 s in a later confirmation run) (sections A–G) | `theorem_log.txt`, `theorem_checks.json` |
| Theory suite | `python3 tests/test_theory.py` | 8794 branch pairs (0 mismatches), 1026 windows, 60/60 boundary cases, 11 triples, 16 families, ring algebra; 424.4 s | `computational_log.txt`, `theory_checks.json` |
| Quantum suite | `python3 tests/test_quantum.py` | 18 bridge rows, 6 CSS instances, 13 recovery instances, 4 non-free instances; all pass, 144.2 s | `quantum_log.txt`, `quantum_checks.json` |
| Table generator | `python3 src/python/experiments.py` | nine data tables, **209 rows** (217 lines in the flattened CSVs, since branch-wise tables expand one ring instance into three lines), no assertion failed, ≈14 s | `experiments_log.txt`, `tables/*.csv`, `data/tables.json` |

## 2. What each suite establishes

### 2.1 Theorem suite (A–G)
* **A** — reciprocity and existence: the map $(x^n-1)^*=-(x^n-1)$ and the
  criterion "nontrivial dual-containing cyclic code exists iff
  $-1\notin\langle q\rangle$" against explicit factorisations.
* **B** — for every enumerated branch, $e\mid n$ (Lemma 4.8), and whenever any
  branch exists the maximum threshold is exactly $n$ (Theorem 4.9). No exception
  in any enumerated $(q,n)$.
* **C** — no-gain: $\operatorname{lcm}(e_1,e_2,e_3)\le\max E=n$ for three-branch
  ring codes, with witnesses.
* **D** — classical contrast: at $(q,n)=(7,10)$ the branches of periods
  $(2,2,5)$ fuse to $10$, and none of them is dual-containing (Theorem 4.8
  forbids dual-containing codes there).
* **E** — degree census and characteristic-2 controls (Hamming $[7,4,3]$, BCH
  $[15,11,3]$: $e=7,15$ versus degree bounds $3,4$).
* **F** — ring windows: joint syndrome injectivity iff
  $a_l+a_r\le e_R-1$, with failure exactly at $\delta=e_R$.
* **G** — hybrid message criterion: the residue criterion
  $x^\delta b\bmod f\in M$ agrees with the brute-force syndrome search, and the
  guarantee $\delta+y\ge\deg f$ holds in every case.

### 2.2 Theory suite
Ring algebra (native vs CRT multiplication, $625$ pairs; idempotents); the
collision criterion and the full collision set on $8794$ ordered pairs with
$0$ mismatches; $7883$ pairs strictly beating the degree bound; $1026$ windows
and the $60/60$ boundary cases $a_l+a_r=e-1$; $11$ branch triples with the
$\operatorname{lcm}$ and intersection identities; $16$ $(q,n)$ families of which
$12$ attain $e_R=n$; calibration against known codes.

### 2.3 Quantum suite (Model A frozen in `quantum_model_decision.md`)
* **§1 bridge:** $C^\perp\subseteq C$ over $R$ $\iff$ $C_i^\perp\subseteq C_i$
  for $i=1,2,3$; 18 rows, including mixed cases such as $(1,1+x)$ where the
  component flags differ.
* **§2–3 CSS instances:** $K=\sum_i(2k_{C,i}-n)$ confirmed against the explicit
  stabiliser rank; stabiliser commutation checked pair by pair; distances
  computed exactly where the weight budget allowed, with
  $\min\wt(C\setminus C^\perp)$ and $\min\wt(D\setminus C^\perp)$ reported
  separately.
* **§4 recovery:** $\alpha$ recovered from the joint syndrome in 13 $(q,n)$
  cases; the window map is injective on $[-a_l,a_l]$ and $\alpha$ and
  $\alpha+e_R$ are genuinely ambiguous (the check that exposed the earlier
  lookup-table artefact, see `MATHEMATICAL_CONSISTENCY_AUDIT.md` D2).
* **§5 non-freeness:** $|\mathcal{C}|=q^{\sum k_i}$ with $k$-vectors such as
  $(4,3,4)$; no $R$-rank is used.

## 3. Table-by-table summary

| Table | Rows | Key fact verified |
|---|---|---|
| 2 single-branch | 16 | sharp window vs degree bound; e.g. $(3,13)$: $e=13$ vs $\deg f=3$ (gain ×6) |
| 3 fusion | 10 (2 no-go) | `needs_fusion = False` everywhere; structural no-gos $(3,10)$, $(7,10)$ |
| 4 relaxation families | 74 | 29 families with relaxation factor $>1$, max ×12 at $(61,60)$ |
| 5 non-free | 12 | e.g. $(5,4,(4,4,1))$: $|\mathcal{C}|=5^9$ but not free |
| 6 edge cases | 8 | $q=2$ excluded, $D=\mathbb{F}_q^n$ trade-off, $k_C=n/2$, no-go cases |
| 7 existence | 58 | criterion $=$ census in all 58; 28 predicted no-gos, 0 mismatches |
| 8 flagship | 6 | $d\ge2$ with maximal window; $(3,13)$: window 12, separations 4/3 |
| 9 distance-constrained | 13 | no gain with $d\ge2$; max threshold $=n$ in every non-empty case |
| 10 hybrid | 12 | exact collision sets; degree-type guarantee sharp in some rows, weak in others |

## 4. Honest limitations carried into the paper

1. Only cell-aligned offsets (multiples of three qudit positions) are correctable
   in Model A.
2. Question 4.13 ($\max E_t=n$ for $t\ge2$) is verified for $t=2$ in 13 cases but
   not proved.
3. $q$ is prime; prime powers are out of scope.
4. Distance columns read `None` where the weight-class budget was exceeded —
   reported as unknown, never as an estimate.
5. `n` with $\gcd(n,q)=1$ only (squarefree $x^n-1$).

## 5. Reproducibility check performed

| Rerun | Result |
|---|---|
| `experiments.py` twice in a row | identical tables and logs (deterministic; no randomness anywhere) |
| `test_theorems.py` after every repair | 751 checks / 0 failures each time |
| Table 10 recomputation after the §G audit finding | collision sets corrected for 4 flagship branches; manuscript numbers updated |
| Package archive extracted into a clean directory | file count, manifest and spot-checks of tables all agree |
