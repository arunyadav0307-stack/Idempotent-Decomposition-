"""
test_theory.py -- computational verification suite for

  "Idempotent decomposition and synchronizable hybrid subsystem quantum codes
   over F_q[v]/(v^3-v)"

Run from the package root:   python3 tests/test_theory.py
Writes: results/computational_log.txt, results/theory_checks.json,
        data/examples.csv, data/examples.json
"""
from __future__ import annotations
import csv
import json
import os
import random
import sys
import time
from math import lcm

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "src", "python"))

from finite_field import (GF, p_divmod, p_is_zero, poly_order_x, p_deg, p_str,
                          p_factor, p_monic)
from cyclic_codes import QCyclicCode, RCyclicCode, all_cyclic_codes, nested_pairs
from synchronization import (empirical_period, sigma_table, collision_delta_set,
                             divisibility_delta_set, joint_empirical_period,
                             joint_collision_set, window_feasibility, check_ring)
from ring_r import RingR, edge_case_char_two

LOG = []
RNG = random.Random(20240917)


def log(*a):
    s = " ".join(str(x) for x in a)
    print(s, flush=True)
    LOG.append(s)


def hr(title):
    log("=" * 74)
    log(title)
    log("=" * 74)


# ======================================================================
# A. ring algebra
# ======================================================================
def test_ring_algebra():
    hr("A. RING ALGEBRA   R = F_q[v]/(v^3 - v)")
    rows = []
    for q in [3, 5, 7, 11, 13, 17]:
        if q % 3 == 0 or q % 2 == 0:
            continue
        R = RingR(q)
        st = R.check_structure()
        idem = R.check_idempotents()
        log(f"  q={q:3d}: v^3-v squarefree={st['v3_minus_v_squarefree']} "
            f"CRT hom(mult)={st['crt_multiplicative']} CRT hom(add)={st['crt_additive']} "
            f"|R*|={st['num_units']} (={(q-1)**3}) "
            f"#nonzero zerodiv={st['num_nonzero_zero_divisors']} "
            f"(={q**3-1-(q-1)**3})")
        log(f"        e_i^2=e_i: {idem['idempotent']}, e_i e_j=0: {idem['orthogonal']}, "
            f"e1+e2+e3=1: {idem['sum_one']}, CRT images {idem['e_crt']}")
        rows.append({"q": q, "squarefree": st["v3_minus_v_squarefree"],
                     "crt_hom": st["crt_multiplicative"] and st["crt_additive"],
                     "num_units": st["num_units"], "units_expected": (q - 1) ** 3,
                     "num_zerodiv": st["num_nonzero_zero_divisors"],
                     "zerodiv_expected": q ** 3 - 1 - (q - 1) ** 3,
                     "idempotent": idem["idempotent"], "orthogonal": idem["orthogonal"],
                     "sum_one": idem["sum_one"]})
    R = RingR(5)
    ok = True
    for a in range(5):
        for b in range(5):
            for c in range(5):
                for d in range(5):
                    x, y = [a, b, c], [d, a, b]
                    if R.crt(R.native_mul(x, y)) != R.crt_mul(R.crt(x), R.crt(y)):
                        ok = False
    log(f"  exhaustive native-vs-CRT multiplication, F_5 (625 pairs): {ok}")
    log("  EDGE CASE q even:  " + edge_case_char_two()["R_structure"] +
        "  ->  no CRT into three fields, idempotents undefined.  q must be odd.")
    log("  EDGE CASE q = 3:   allowed; the three roots 0,1,2 = 0,1,-1 are distinct.")
    return rows


# ======================================================================
# B. single component threshold theorem
# ======================================================================
def pairs_of(F, n, cap=600, codecap=45):
    """Bounded sample of ordered pairs (C,D) with C strictly inside D."""
    codes = all_cyclic_codes(F, n)
    if len(codes) > codecap:
        codes = RNG.sample(codes, codecap)
    ps = [(C, D) for C in codes for D in codes if D.contains(C) and C.k < D.k]
    if len(ps) > cap:
        ps = RNG.sample(ps, cap)
    return ps


def test_single_component():
    hr("B. SHARP THRESHOLD (one component):  e(C,D) = ord_x mod f,  f = p/q")
    total = 0
    mismatches = []
    strictly_larger = 0
    for q in [3, 5, 7, 11, 13, 17]:
        if q % 2 == 0:
            continue
        F = GF(q)
        ns = [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 18, 20] if q <= 7 \
            else [4, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15, 16]
        for n in ns:
            if n % q == 0:
                continue
            ps = pairs_of(F, n)
            for (C, D) in ps:
                total += 1
                emp = empirical_period(C, D)
                assert C.F.p == D.F.p
                quo, rem = p_divmod(F, C.p, D.p)
                assert p_is_zero(rem)
                pred = poly_order_x(F, quo, bound=n)
                cs = collision_delta_set(C, D)
                ds = divisibility_delta_set(C, D)
                if emp != pred or cs != ds:
                    mismatches.append((q, n, C.p, D.p, emp, pred))
                if emp > D.k - C.k:
                    strictly_larger += 1
    log(f"  ordered pairs (C strictly contained in D) tested : {total}")
    log(f"  mismatches between empirical period and ord_x mod f : {len(mismatches)}")
    log(f"  mismatches between collision set and divisibility set : "
        f"{len([m for m in mismatches])}")
    log(f"  pairs where the sharp threshold STRICTLY exceeds the familiar "
        f"degree bound k_D-k_C : {strictly_larger}  "
        f"({100.0*strictly_larger/max(total,1):.1f}% of pairs)")
    for m in mismatches[:5]:
        log("   MISMATCH", m)
    # QSC-hypothesis-only pairs
    tot2 = bad2 = 0
    for q in [3, 5, 7, 11, 13, 17]:
        if q % 2 == 0:
            continue
        F = GF(q)
        for n in [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]:
            if n % q == 0:
                continue
            for (C, D) in nested_pairs(F, n)[:200]:
                tot2 += 1
                emp = empirical_period(C, D)
                quo, _ = p_divmod(F, C.p, D.p)
                if emp != poly_order_x(F, quo, bound=n):
                    bad2 += 1
    log(f"  pairs satisfying the full QSC hypotheses (C^perp in C in D, k_C<k_D): "
        f"{tot2}, mismatches {bad2}")
    return total, len(mismatches), strictly_larger


# ======================================================================
# C. sharpness of the window statement
# ======================================================================
def test_sharpness():
    hr("C. SHARPNESS: alpha -> Sigma(alpha) injective on {-al..ar}  iff  al+ar < e")
    checked = 0
    ok = True
    examples = []
    for q in [3, 5, 7]:
        F = GF(q)
        for n in [7, 8, 9, 12, 13, 15, 16, 20]:
            if n % q == 0:
                continue
            for (C, D) in nested_pairs(F, n)[:12]:
                e = empirical_period(C, D)
                for al in range(0, min(3, n)):
                    for ar in range(0, min(3, n - al)):
                        if al + ar >= n:
                            continue
                        inj = window_feasibility([C], [D], al, ar)
                        pred = (al + ar < e)
                        checked += 1
                        if inj != pred:
                            ok = False
                            log(f"   COUNTEREXAMPLE q={q} n={n} e={e} al={al} ar={ar}")
                        if al + ar == e - 1 and al + ar > 0:
                            examples.append((q, n, p_str(F, C.p), p_str(F, D.p), al, ar, e, inj))
    log(f"  windows tested: {checked};  criterion al+ar < e correct in all cases: {ok}")
    log(f"  boundary cases al+ar = e-1 (must be feasible): "
        f"{sum(1 for e in examples if e[-1])}/{len(examples)}")
    return ok, examples


# ======================================================================
# D. ring level fusion
# ======================================================================
def best_amplifying_triple(F, n, cap=400):
    codes = all_cyclic_codes(F, n)
    ps = [(C, D) for C in codes for D in codes if D.contains(C) and C.k < D.k]
    if len(ps) > cap:
        ps = RNG.sample(ps, cap)
    e = [empirical_period(C, D) for (C, D) in ps]
    best = None
    for i in range(len(ps)):
        for j in range(i, len(ps)):
            for k in range(j, len(ps)):
                L = lcm(e[i], e[j], e[k])
                if L > max(e[i], e[j], e[k]):
                    if best is None or L > best[3]:
                        best = (i, j, k, L)
    return ps, e, best


def test_ring_fusion():
    hr("D. RING FUSION:  joint threshold = lcm_i e(C_i,D_i)  (not min, not max)")
    rows = []
    allok = True
    tested = 0
    for q in [3, 5, 7, 11]:
        F = GF(q)
        for n in [4, 5, 6, 7, 8, 9, 10, 12, 13, 15, 16]:
            if n % q == 0:
                continue
            ps, e, best = best_amplifying_triple(F, n)
            if best is None:
                continue
            i, j, k, L = best
            Cs = [ps[i][0], ps[j][0], ps[k][0]]
            Ds = [ps[i][1], ps[j][1], ps[k][1]]
            joint = joint_empirical_period(Cs, Ds)
            inter = set(collision_delta_set(Cs[0], Ds[0]))
            for t in range(1, 3):
                inter &= set(collision_delta_set(Cs[t], Ds[t]))
            js = set(joint_collision_set(Cs, Ds))
            agree = (joint == L) and (js == inter) and (joint == lcm(e[i], e[j], e[k]))
            allok = allok and agree
            tested += 1
            row = {"q": q, "n": n, "e1": e[i], "e2": e[j], "e3": e[k],
                   "lcm": L, "max_component": max(e[i], e[j], e[k]),
                   "min_component": min(e[i], e[j], e[k]),
                   "joint_empirical": joint,
                   "ratio_lcm_over_max": round(L / max(e[i], e[j], e[k]), 3),
                   "deg_f": [Ds[t].k - Cs[t].k for t in range(3)],
                   "refined_over_source": L > min(Ds[t].k - Cs[t].k for t in range(3)),
                   "joint_collisions_equal_intersection": (js == inter),
                   "joint_equals_lcm": (joint == L)}
            rows.append(row)
            log(f"  q={q:3d} n={n:3d}  e_i={e[i]},{e[j]},{e[k]}   lcm={L:4d}   "
                f"max_i e_i={max(e[i],e[j],e[k]):3d}   min_i(k_D-k_C)="
                f"{min(row['deg_f']):2d}   joint(empirical)={joint:4d}   OK={agree}")
    log(f"  triples tested: {tested};  all identities hold: {allok}")
    return rows, allok


# ======================================================================
# E. optimal family: d_sync,max = n
# ======================================================================
def test_optimal_family():
    hr("E. OPTIMAL FAMILY: ring code attaining d_sync,max = n")
    out = []
    for (q, n) in [(3, 8), (3, 13), (5, 4), (5, 8), (5, 12), (7, 6), (7, 8), (7, 12),
                   (7, 15), (11, 5), (11, 10), (13, 6), (13, 12), (13, 4), (19, 6),
                   (31, 5), (31, 10), (31, 30), (37, 4), (25, 4)]:
        if n % q == 0:
            continue
        try:
            F = GF(q)
        except ValueError:
            continue
        xn1 = [F.neg(1) % F.p] + [0] * (n - 1) + [1]
        facs = p_factor(F, xn1)
        lin = [f for f in facs if p_deg(f) == 1]
        if len(lin) < 3:
            continue

        def root_order(f):
            r = (-f[0]) % q
            if r == 0:
                return 1
            o, cur = 1, r
            while cur != 1:
                cur = (cur * r) % q
                o += 1
            return o

        cand = [(f, root_order(f)) for f in lin]
        best = None
        for i in range(len(cand)):
            for j in range(i + 1, len(cand)):
                for k in range(j + 1, len(cand)):
                    L = lcm(cand[i][1], cand[j][1], cand[k][1])
                    if best is None or L > best[3]:
                        best = (i, j, k, L)
        if best is None:
            continue
        i, j, k, L = best
        sel = [cand[i], cand[j], cand[k]]
        Cs = [QCyclicCode(F, n, s[0]) for s in sel]
        Ds = [QCyclicCode(F, n, [1]) for s in sel]
        joint = joint_empirical_period(Cs, Ds)
        so = [c.is_self_orthogonal() for c in Cs]
        # k_C >= n/2 needed for the CSS code to be non-degenerate
        ok_k = all(c.k >= n / 2 for c in Cs)
        out.append({"q": q, "n": n, "orders": [s[1] for s in sel], "lcm": L,
                    "joint": joint, "max_order": max(s[1] for s in sel),
                    "self_orthogonal": so, "k_i": [c.k for c in Cs],
                    "attains_n": (joint == n)})
        log(f"  q={q:3d} n={n:3d}: f_i = x - a_i, root orders {[s[1] for s in sel]}"
            f"  ->  e_R = {L:3d} (= n? {L==n})   max_i e_i = {max(s[1] for s in sel):3d}"
            f"   joint empirical = {joint:3d}   k_i = {[c.k for c in Cs]}"
            f"   C_i self-orth: {so}   k_i >= n/2: {ok_k}")
    achieved = sum(1 for r in out if r["attains_n"])
    log(f"  families attaining the MAXIMAL possible threshold n: {achieved}/{len(out)}")
    log("  (a_i = x - a with ord(a) = m_i; D_i = F_q^n so k_D-k_C = 1 in every component)")
    return out


# ======================================================================
# F. what the fusion does NOT give (honest calibration)
# ======================================================================
def test_calibration():
    hr("F. CALIBRATION: lcm of orders vs a single polynomial with the same root set")
    rows = []
    for (q, ms) in [(7, [2, 3]), (7, [2, 3, 6]), (13, [2, 3, 4]), (31, [2, 3, 5]),
                    (31, [2, 3, 5, 6])]:
        F = GF(q)
        L = 1
        deg_total = 0
        for m in ms:
            L = lcm(L, m)
        # single q-ary polynomial with roots of orders m in the list:
        # sum of phi(m_i) degrees is an upper bound if the cyclotomics are used
        deg_cyclo = 0
        for m in ms:
            if m % q == 0:
                continue
            deg_cyclo += int(phi(m))
        rows.append({"q": q, "orders": ms, "lcm": L,
                     "sum_phi_degrees": deg_cyclo,
                     "note": ("the same lcm is attainable by ONE q-ary cyclic code whose "
                              "f is the product of the corresponding cyclotomic factors"),
                     })
        log(f"  q={q:3d} orders {ms}: lcm = {L}, but one q-ary code with f = prod Phi_m "
            f"has deg = {deg_cyclo} and the same order-structure")
    log("  CONCLUSION: the lcm rule is a general sharpening of the QSC threshold; the")
    log("  ring supplies (a) a single shared misalignment for three heterogeneous")
    log("  branches, (b) a uniform algebraic description, and (c) non-free codes.")
    return rows


def phi(n):
    out = n
    d = 2
    m = n
    while d * d <= m:
        if m % d == 0:
            while m % d == 0:
                m //= d
            out -= out // d
        d += 1
    if m > 1:
        out -= out // m
    return out


def main():
    t0 = time.time()
    ring_rows = test_ring_algebra()
    total, mism, strictly = test_single_component()
    sharp_ok, sharp_ex = test_sharpness()
    fusion_rows, fusion_ok = test_ring_fusion()
    fam_rows = test_optimal_family()
    calib_rows = test_calibration()
    hr(f"TOTAL ELAPSED {time.time()-t0:.1f} s")
    os.makedirs(os.path.join(ROOT, "results"), exist_ok=True)
    os.makedirs(os.path.join(ROOT, "data"), exist_ok=True)
    with open(os.path.join(ROOT, "results", "computational_log.txt"), "w") as fh:
        fh.write("\n".join(LOG) + "\n")
    payload = {"ring": ring_rows,
               "single_component": {"pairs_tested": total, "mismatches": mism,
                                    "pairs_beating_degree_bound": strictly},
               "sharpness": {"ok": sharp_ok, "boundary_examples": sharp_ex[:10]},
               "fusion": fusion_rows, "optimal_family": fam_rows,
               "calibration": calib_rows}
    with open(os.path.join(ROOT, "results", "theory_checks.json"), "w") as fh:
        json.dump(payload, fh, indent=2)
    with open(os.path.join(ROOT, "data", "examples.json"), "w") as fh:
        json.dump({"fusion": fusion_rows, "optimal_family": fam_rows,
                   "single_component": payload["single_component"]}, fh, indent=2)
    with open(os.path.join(ROOT, "data", "examples.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["table", "q", "n", "e1", "e2", "e3", "lcm", "max_component",
                    "min_component", "joint_empirical", "deg_f", "attains_n"])
        for r in fusion_rows:
            w.writerow(["fusion", r["q"], r["n"], r["e1"], r["e2"], r["e3"], r["lcm"],
                        r["max_component"], r["min_component"], r["joint_empirical"],
                        r["deg_f"], ""])
        for r in fam_rows:
            w.writerow(["optimal_family", r["q"], r["n"], r["orders"][0], r["orders"][1],
                        r["orders"][2], r["lcm"], r["max_order"], "", r["joint"],
                        r["k_i"], r["attains_n"]])
    log("wrote results/computational_log.txt, results/theory_checks.json, "
        "data/examples.{csv,json}")


if __name__ == "__main__":
    main()
