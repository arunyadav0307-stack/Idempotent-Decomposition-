"""
test_theorems.py -- verification of the structural theorems of the manuscript
that go beyond the branch-level synchronization test in test_theory.py.

Sections
  A  reciprocity uniformity + existence criterion
        "some irreducible factor of x^n-1 is non-self-reciprocal"
        <=> "-1 is not in <q> mod n"
        <=> "a nontrivial dual-containing cyclic code of length n exists"
  B  e | n for every branch, and maximality: if any branch exists then n is an
     achievable threshold (so the best single branch always attains e = n)
  C  no-gain theorem for ring fusion:  max over triples of lcm(e_i) = n
  D  classical (non-dual-containing) fusion DOES amplify: q=7, n=10, e=(2,2,5)
  E  sharp threshold vs the degree bound k_D - k_C (odd characteristic, and the
     characteristic-2 reference points Hamming [7,4,3] and BCH [15,11,3])
  F  ring-level window: injectivity of the joint syndrome up to e_R - 1 and
     collision exactly at e_R, for a three-branch ring code
Writes results/theorem_log.txt and results/theorem_checks.json.
"""
from __future__ import annotations
import json
import os
import sys
import time
from itertools import combinations_with_replacement
from math import lcm

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "src", "python"))

from finite_field import (GF, p_factor, p_mul, p_trim, p_str, poly_order_x,      # noqa: E402
                          p_divmod, p_deg, p_reverse, p_monic, p_mod)
from cyclic_codes import (QCyclicCode, all_cyclic_codes,                        # noqa: E402
                          divisors_of_xn_minus_1, num_irreducible_factors)
from synchronization import (empirical_period, joint_empirical_period,          # noqa: E402
                             collision_delta_set, window_feasibility,
                             joint_collision_set)
from experiments import (min_weight_in, min_weight_outside, achievable_periods,  # noqa: E402
                         _q_group, linear_branch, order_triple)

LOG: list = []
CHECKS: list = []


def log(*a):
    s = " ".join(str(x) for x in a)
    print(s, flush=True)
    LOG.append(s)


def divs_ok(F, n, cap):
    """(t, manageable): t irreducibles, 2^t <= cap (checked before building)."""
    t = num_irreducible_factors(F, n)
    return t, 2 ** t <= cap


def check(name, ok, detail=""):
    CHECKS.append({"check": name, "ok": bool(ok), "detail": detail})
    log(f"  [{'PASS' if ok else 'FAIL'}] {name}  {detail}")
    if not ok:
        raise AssertionError(name)


def is_self_reciprocal(F, f):
    """f is (up to a scalar) equal to its reciprocal f*(x) = x^d f(1/x)."""
    d = p_deg(f)
    if d <= 0:
        return True
    rev = p_monic(F, p_reverse(F, f, d))
    return p_trim(rev) == p_trim(p_monic(F, f))


# ----------------------------------------------------------------------
# A. reciprocity uniformity and the existence criterion
# ----------------------------------------------------------------------
def section_A():
    log("=" * 72)
    log("A. reciprocity uniformity and the existence criterion")
    log("=" * 72)
    cases = [(q, n) for q in (3, 5, 7, 11, 13, 17, 19, 23)
             for n in list(range(3, 17)) + [18, 20, 21, 22, 24, 25, 26, 28, 30]
             if n % q != 0]
    nebulous = 0
    for (q, n) in cases:
        F = GF(q)
        facs = p_factor(F, [F.neg(1) % q] + [0] * (n - 1) + [1])
        sr = [is_self_reciprocal(F, f) for f in facs]
        all_sr, some_sr = all(sr), any(sr)
        minus1_in = (-1) % n in _q_group(q, n)
        check(f"A1[{q},{n}] self-reciprocity is uniform over the factors",
              all_sr == (not some_sr) or some_sr,
              f"all={all_sr} any={some_sr}")
        check(f"A2[{q},{n}] all factors self-reciprocal <=> -1 in <q> mod n",
              all_sr == minus1_in, f"all_sr={all_sr} minus1_in={minus1_in}")
        # structural existence criterion: some factor is non-self-reciprocal
        check(f"A3[{q},{n}] non-self-reciprocal factor <=> -1 not in <q>",
              (not all_sr) == (not minus1_in))
        t, ok = divs_ok(F, n, 4096)
        if ok:
            nontrivial = [C for C in all_cyclic_codes(F, n)
                          if C.is_self_orthogonal() and C.k < n]
            check(f"A4[{q},{n}] enumeration agrees: nontrivial dual-containing "
                  f"codes exist <=> -1 not in <q>",
                  (len(nontrivial) > 0) == (not minus1_in),
                  f"#codes={len(nontrivial)} (-1 in <q>)={minus1_in}")
        else:
            nebulous += 1
    log(f"  ({len(cases)} (q,n) pairs checked; {nebulous} were too large for "
        f"enumeration and were checked structurally only)")


# ----------------------------------------------------------------------
# B. e | n and maximality of n
# ----------------------------------------------------------------------
def section_B():
    log("=" * 72)
    log("B. e | n for every branch; n itself is always achievable")
    log("=" * 72)
    cases = [(3, 8), (3, 13), (3, 16), (5, 8), (5, 12), (5, 16), (7, 6), (7, 9),
             (7, 12), (7, 15), (7, 20), (11, 5), (11, 10), (11, 14), (13, 6),
             (13, 8), (13, 16), (17, 8), (17, 12), (19, 9), (23, 11), (23, 14)]
    for (q, n) in cases:
        F = GF(q)
        tab = achievable_periods(F, n)
        if tab is None:
            continue
        tab = {k: v for k, v in tab.items() if k is not None}
        if not tab:
            check(f"B[{q},{n}] no branch -> vacuously consistent", True)
            continue
        vals = sorted(tab)
        check(f"B1[{q},{n}] all periods divide n",
              all(n % e == 0 for e in vals), f"periods={vals}")
        check(f"B2[{q},{n}] n is an achievable period (max is n)",
              max(vals) == n, f"max={max(vals)} n={n}")
        check(f"B3[{q},{n}] witnesses have the right period",
              all(empirical_period(C, D) == e for e in vals
                  for (C, D) in tab[e][:3]),
              f"{len(vals)} distinct periods")


# ----------------------------------------------------------------------
# C. no-gain theorem for ring fusion
# ----------------------------------------------------------------------
def section_C():
    log("=" * 72)
    log("C. ring fusion cannot beat the best single branch")
    log("=" * 72)
    cases = [(3, 8), (3, 13), (3, 16), (5, 8), (5, 12), (5, 16), (7, 6), (7, 9),
             (7, 12), (7, 15), (7, 20), (11, 5), (11, 10), (11, 14), (13, 6),
             (13, 8), (13, 16), (17, 8), (19, 9), (23, 11), (23, 14)]
    for (q, n) in cases:
        F = GF(q)
        tab = achievable_periods(F, n)
        if tab is None:
            continue
        tab = {k: v for k, v in tab.items() if k is not None}
        if not tab:
            continue
        vals = sorted(tab)
        worst = max(lcm(*t) for t in combinations_with_replacement(vals, 3))
        check(f"C[{q},{n}] max_{'{triples}'} lcm = n = max single period",
              worst == n == max(vals),
              f"max_lcm3={worst} max_single={max(vals)} periods={vals}")


# ----------------------------------------------------------------------
# D. the classical contrast: fusion amplifies without dual-containment
# ----------------------------------------------------------------------
def section_D():
    log("=" * 72)
    log("D. classical contrast: fusion amplifies without dual-containment")
    log("=" * 72)
    q, n = 7, 10
    F = GF(q)
    # branch 1,2: f = x + 1   (e = 2);  branch 3: f = Phi_5 (e = 5)
    Cs, Ds, es = [], [], []
    for cp, dp in [([1, 1], [1]), ([1, 1], [1]),
                   ([1, 1, 1, 1, 1], [1])]:
        C = QCyclicCode(F, n, cp)
        D = QCyclicCode(F, n, dp)
        e = empirical_period(C, D)
        quo, _ = p_divmod(F, C.p, D.p)
        check(f"D[{q},{n}] branch period = ord_x(f)",
              e == poly_order_x(F, quo, bound=n), f"e={e}")
        Cs.append(C)
        Ds.append(D)
        es.append(e)
    check(f"D[{q},{n}] branch periods (2,2,5)", es == [2, 2, 5], f"{es}")
    joint = joint_empirical_period(Cs, Ds)
    check(f"D[{q},{n}] fused threshold = 10 = lcm > max branch = 5",
          joint == 10 and max(es) == 5, f"joint={joint}")
    check(f"D[{q},{n}] these branches are NOT dual-containing "
          f"(so not quantum-usable)", not any(c.is_self_orthogonal() for c in Cs),
          f"self-orth={[c.is_self_orthogonal() for c in Cs]}")
    # and the sharp window works at the ring level: injective up to 9, collides at 10
    check(f"D[{q},{n}] window injective up to 9, collision at 10",
          window_feasibility(Cs, Ds, 0, 9) and
          (10 in joint_collision_set(Cs, Ds)),
          f"collisions={joint_collision_set(Cs, Ds)[:5]}")


# ----------------------------------------------------------------------
# E. sharp threshold vs degree bound
# ----------------------------------------------------------------------
def section_E():
    log("=" * 72)
    log("E. sharp threshold ord_x(f)-1 vs the degree bound k_D-k_C-1")
    log("=" * 72)
    stat = {"pairs": 0, "sharp_better": 0, "equal": 0, "less": 0}
    for (q, n) in [(3, 8), (3, 13), (5, 8), (5, 12), (7, 6), (7, 12), (11, 5),
                   (11, 10), (13, 6), (13, 8), (17, 8), (19, 9), (23, 11)]:
        F = GF(q)
        t, ok = divs_ok(F, n, 4096)
        if not ok:
            continue
        for C in all_cyclic_codes(F, n):
            if not C.is_self_orthogonal():
                continue
            for D in all_cyclic_codes(F, n):
                if not (D.contains(C) and C.k < D.k):
                    continue
                quo, rem = p_divmod(F, C.p, D.p)
                if not all(x == 0 for x in rem):
                    continue
                e = poly_order_x(F, quo, bound=n)
                a = min(e, n) - 1
                b = D.k - C.k - 1
                stat["pairs"] += 1
                if a > b:
                    stat["sharp_better"] += 1
                elif a == b:
                    stat["equal"] += 1
                else:
                    stat["less"] += 1
    log(f"  census: {stat}")
    check("E1 sharp threshold never below the degree bound in the sample",
          stat["less"] == 0, f"{stat}")
    check("E2 the degree bound is strictly weaker for the majority of pairs",
          stat["sharp_better"] > stat["pairs"] / 2, f"{stat}")
    # characteristic-2 reference points (the source's own setting)
    F = GF(2)
    for (n, cp) in [(7, [1, 1, 0, 1]), (15, [1, 0, 0, 1, 1])]:
        C = QCyclicCode(F, n, cp)
        D = QCyclicCode(F, n, [1])
        e = empirical_period(C, D)
        check(f"E3[2,{n}] ord_x(p_C) = {n} > k_D-k_C = {n - C.k}",
              e == n and n - C.k < n, f"e={e} k_C={C.k}")


# ----------------------------------------------------------------------
# F. ring-level window and collision for a three-branch code
# ----------------------------------------------------------------------
def section_F():
    log("=" * 72)
    log("F. ring-level window: injective up to e_R-1, collision at e_R")
    log("=" * 72)
    for (q, n, specs) in [
            (3, 13, [([1, 0, 1, 0, 0, 1, 1], [2, 1, 1, 1])] * 3),
            (5, 8, [([1, 2, 3, 1], [3, 1])] * 3),
            (7, 6, [([6, 2, 1], [5, 1])] * 3)]:
        F = GF(q)
        Cs, Ds = [], []
        for cp, dp in specs:
            Cs.append(QCyclicCode(F, n, cp))
            Ds.append(QCyclicCode(F, n, dp))
        eR = joint_empirical_period(Cs, Ds)
        coll = joint_collision_set(Cs, Ds)
        check(f"F1[{q},{n}] e_R = {eR}, collision exactly at e_R",
              coll == [eR], f"collisions={coll}")
        ok_win = all(window_feasibility(Cs, Ds, 0, w) for w in range(0, eR))
        check(f"F2[{q},{n}] every window a_l+a_r <= e_R-1 is injective",
              ok_win, f"w up to {eR - 1}")
        check(f"F3[{q},{n}] window a_l+a_r = e_R is NOT injective",
              not window_feasibility(Cs, Ds, 0, eR), f"w = {eR}")


# ----------------------------------------------------------------------
# G. message-carrying (hybrid) window: collision criterion and guarantee
# ----------------------------------------------------------------------
def _messages(F, y):
    import itertools
    if y == 0:
        return [[1]]
    out = []
    for cs in itertools.product(range(F.p), repeat=y):
        b = [0] * (y + 1)
        b[0] = 1
        for i, c in enumerate(cs, start=1):
            b[i] = c
        out.append(b)
    return out


def message_collisions(F, C, D, y, n):
    """deltas in [1,n-1] with f | x^d b - b' for some b,b' in 1+span{x,..,x^y}."""
    f, _ = p_divmod(F, C.p, D.p)
    M = _messages(F, y)
    bad = []
    for d in range(1, n):
        for b in M:
            for b2 in M:
                h = [0] * (max(len(b) + d, len(b2)))
                for i, c in enumerate(b):
                    h[i + d] = (h[i + d] + c) % F.p
                for i, c in enumerate(b2):
                    h[i] = (h[i] - c) % F.p
                if all(x == 0 for x in p_mod(F, h, f)):
                    bad.append(d)
                    break
            else:
                continue
            break
    return bad


def section_G():
    log("=" * 72)
    log("G. message-carrying hybrid window: exact criterion + guarantee")
    log("=" * 72)
    for (q, n, cp, dp) in [(3, 13, [1, 0, 1, 0, 0, 1, 1], [2, 1, 1, 1]),
                           (5, 8, [1, 2, 3, 1], [3, 1]),
                           (7, 6, [6, 2, 1], [5, 1]),
                           (11, 5, [3, 9, 1], [2, 1])]:
        F = GF(q)
        C = QCyclicCode(F, n, cp)
        D = QCyclicCode(F, n, dp)
        f, _ = p_divmod(F, C.p, D.p)
        df = p_deg(f)
        e = poly_order_x(F, f, bound=n)
        check(f"G0[{q},{n}] e = ord_x(f) >= deg f", e >= df, f"e={e} deg f={df}")
        for y in range(0, min(df, 4)):
            bad = message_collisions(F, C, D, y, n)
            check(f"G1[{q},{n},y={y}] every collision has delta + y >= deg f",
                  all(d + y >= df for d in bad), f"collisions={bad}")
            safe = [d for d in range(1, n) if d + y < df and d % e != 0]
            check(f"G2[{q},{n},y={y}] no collision in the guaranteed region "
                  f"delta <= deg f - y - 1", not (set(safe) & set(bad)),
                  f"guaranteed deltas={safe[:6]} collisions={bad}")
        bad0 = message_collisions(F, C, D, 0, n)
        check(f"G3[{q},{n}] y=0: collisions exactly at multiples of e (=n here)",
              all(d % n == 0 for d in bad0), f"{bad0}")


def main():
    t0 = time.time()
    for fn in (section_A, section_B, section_C, section_D, section_E, section_F,
               section_G):
        fn()
        log(f"  [{fn.__name__}: {time.time() - t0:.1f} s cumulative]")
    nfail = sum(1 for c in CHECKS if not c["ok"])
    log("=" * 72)
    log(f"SUMMARY: {len(CHECKS)} checks, {nfail} failures, "
        f"{time.time() - t0:.1f} s")
    os.makedirs(os.path.join(ROOT, "results"), exist_ok=True)
    with open(os.path.join(ROOT, "results", "theorem_log.txt"), "w") as fh:
        fh.write("\n".join(LOG) + "\n")
    with open(os.path.join(ROOT, "results", "theorem_checks.json"), "w") as fh:
        json.dump({"checks": CHECKS, "failures": nfail}, fh, indent=1)


if __name__ == "__main__":
    main()
