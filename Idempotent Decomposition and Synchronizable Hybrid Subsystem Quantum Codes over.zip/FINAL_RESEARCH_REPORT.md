# FINAL RESEARCH REPORT

**RESEARCH STATUS:** **VALIDATED** — the mathematical content is complete,
internally consistent and machine-verified (CRITICAL_ERRORS = 0); the one
genuinely open question is labelled as open rather than claimed. The original
headline hypothesis (ring fusion enlarges the window) was **refuted** and
replaced by a proved no-gain theorem plus a classical contrast; the direction was
repaired, not abandoned, and the final results stand on their own.

**FINAL TITLE:** *Idempotent Decomposition and Synchronizable Hybrid Subsystem
Quantum Codes over `F_q[v]/(v³ − v)`: Sharp Misalignment Thresholds and a No-Gain
Theorem for Ring Fusion.*

**MANUSCRIPT:** `FINAL_MANUSCRIPT.md` (1105 lines, ≈10 800 words, complete,
self-contained: 7 sections, 3 appendices, a verification index and a verified
reference list), `FINAL_MANUSCRIPT.tex` (generated from the Markdown by the
bundled converter `src/tools/md2tex.py`, so the two cannot drift) and
**`FINAL_MANUSCRIPT.pdf` — compiled with pdfTeX (TeX Live 2025): 17 pages, 0
errors, 0 undefined references, 0 missing characters** (`PDF_COMPILATION_STATUS.md`
records the exact two-pass build and the transcripts).

---

## MAIN MATHEMATICAL CONTRIBUTIONS

1. **Sharp synchronisation threshold for the marker quotient.**
   For a branch `C^⊥ ⊆ C ⊆ D` of cyclic codes of length `n` over `F_q` (q odd),
   with `p = p_C`, `q = p_D`, `f = p/q`, the syndrome map
   `α ↦ H_C O(q₁,α)ᵀ` is injective exactly when `a_l + a_r ≤ e − 1` with
   `e = ord_x(f)`; the collision differences are exactly the multiples of `e`
   (Lemma 4.1, Theorem 4.3). The classical degree bound `a_l + a_r < k_D − k_C`
   is sufficient but never sharp: `e ≥ deg f` always, and `e − 1` strictly
   exceeds `deg f − 1` in 7883 of 8794 exhaustively checked pairs (89.6 %)
   (Theorem 4.4; characteristic-2 controls included). The order criterion itself
   is Fujiwara's and is attributed, not claimed.

2. **Existence criterion, and the no-gain theorem for ring fusion.**
   A nontrivial dual-containing cyclic code of length `n` over `F_q` exists iff
   `−1 ∉ ⟨q⟩ mod n` (Theorem 2.8), which decides in advance for which `n` the
   whole construction exists (it does not for `(q,n) = (3,10), (7,10)`, …) and
   implies that the maximal window `n − 1` is attained by a *single* branch
   whenever a branch exists (Theorem 4.9). Since every branch threshold divides
   `n` (Lemma 4.8), the fused threshold `e_R = lcm(e₁,e₂,e₃)` never exceeds `n`
   and hence never exceeds the best single branch: **ring fusion is
   window-neutral** (Theorem 4.10). What fusion does buy is a *relaxation* of the
   requirements on individual branches (74 closed-form families, 29 with
   relaxation factor > 1, up to ×12 at `(q,n) = (61,60)`), not a capability gain.
   Dropping the quantum condition `C^⊥ ⊆ C` restores genuine amplification
   (over `q = 7`, `n = 10` periods `(2,2,5)` fuse to `10 > 5`), which pins the
   obstruction exactly on that condition (Corollary 4.11).

3. **Exact hybrid region and subsystem layer.**
   For message-carrying markers `M = 1 + span{x,…,x^y}` the exact collision
   criterion is `f | x^δ b − b′` (equivalently `x^δ b mod f ∈ M`), a collision at
   difference `δ` forces `δ + y ≥ deg f`, and `y = 0` is exact at `e − 1`
   (Theorems 5.1–5.2, Corollary 5.3). The exact criterion is strictly stronger
   than the degree-type guarantee in explicit cases (at `(q,n) = (3,13)`,
   `f = 2 + 2x + x³`, `y = 1`: usable window `2` versus guaranteed `1`), and the
   degree-type guarantee `a_l + a_r < k_D − k_C − y` is recovered in odd
   characteristic by an independent degree argument (Table 10). The
   hybrid/subsystem completion is given with explicit parameters
   (`K = Σ(2k_{C,i} − n)`, `M = Σ(k_{D,i} − k_{C,i})`,
   `D = d_x = min_i min wt(D_i ∖ C_i^⊥)`), verified in the symmetric case
   (Proposition 3.1, Remark 5.5).

---

## FINAL QUANTUM MODEL

**Model A (frozen in `quantum_model_decision.md` before any quantum notation was
used).** Interleaved `q`-ary lift on `N = 3n` qudits: position `3t + i` carries the
`t`-th symbol of the `i`-th CRT component; Pauli group `⟨X(a), Z(b)⟩` with
`X(a)Z(b) = ω^{a·b} Z(b)X(a)` and symplectic form
`⟨(a|b),(a′|b′)⟩ = a·b′ − a′·b` (non-degenerate because `q` is odd); errors are
independent `q`-ary Pauli errors plus a shared, **cell-aligned** frame
misalignment. Rejected alternatives: B (one `q³`-level system per cell — local
error model does not reflect the ring decomposition), C (additive `q³`-level
model — isomorphic to A), D (`R`-valued cell — no `q`-ary Pauli group reproducing
componentwise orthogonality). `q = 2` is excluded (non-reduced ring);
`gcd(n,q) = 1`; `q` prime.

## FINAL PARAMETERS

* Structural: `N = 3n`; `K = Σ_{i=1..3} (2k_{C,i} − n)`;
  `M = Σ_i (k_{D,i} − k_{C,i})` classical `q`-ary symbols; gauge `R_g = 0` in the
  symmetric case (nonzero only for `C_x ≠ C_z`); distance
  `D = min_i min wt(D_i ∖ C_i^⊥) ≥ min_i d(D_i)`.
* Synchronisation: window `a_l + a_r ≤ e_R − 1` cells,
  `e_R = lcm(e₁,e₂,e₃) ≤ n`; padded realisation `3(n + a_l + a_r)` qudits (never
  `3n + a_l + a_r`); all offsets cell-aligned (multiples of three positions).
* Flagship: `q = 3`, `n = 13`, `C = ⟨1 + x² + x⁵ + x⁶⟩ = [13,7,4]`,
  `D = ⟨2 + x + x² + x³⟩ = [13,10,3]`, `deg f = 3`, `e = 13`;
  replicating the branch three times: `[[39, 3 : 9, 0, D ≥ 3]]₃` with a
  **12-cell** window (degree bound would promise 2).

## SYNCHRONIZATION MODEL

One shared offset `α ∈ Z_n` measured in ring cells (`d_sync = a_l + a_r + 1`
cells); the receiver measures the joint syndrome
`Σ(α) = (Σ₁(α), Σ₂(α), Σ₃(α))` and recovers `α` from a window-restricted lookup
table. Recovery is exact iff `α ↦ Σ(α)` is injective on the window, i.e. iff
`a_l + a_r ≤ e_R − 1`. Four notions are kept separate throughout:
synchronisation distance (`d_sync = a_l+a_r+1`), total offset range (`a_l+a_r`),
maximum correctable misalignment, and the parameter upper bound (`≤ n − 1`).
Only cell-aligned offsets are correctable (declared limitation).

## NOVELTY STATUS

**Honest and bounded.** Five contributions, each proved and computationally
checked: (1) the exact collision set in odd characteristic with its sign
bookkeeping; (2) the existence criterion; (3) the no-gain theorem for ring
fusion, with the mechanism isolated; (4) the classical contrast identifying the
obstruction as the quantum condition itself; (5) the exact hybrid region with
its degree-type guarantee. **Explicit non-claims:** the CRT idempotent
decomposition and per-component construction (standard, prior art); the order
criterion `e = ord_x(f)` (Fujiwara, PRA 87, 022344 (2013)); the maximum
synchronisation distance `k_D − k_C` (source paper); the hybrid/subsystem
framework and the `r + m + d_sync = 2(k_d − k_c)` accounting (source paper);
priority on QSCs over finite rings (Liu & Liu 2021; Dai & Liu 2022; Liu, Hu &
Liu 2024; Du, Ma & Liu 2023; Dinh et al. 2021). The direction was revised once,
after the original headline was refuted by our own computation.

## COMPUTATIONAL VERIFICATION

* `tests/test_theorems.py` — **751 checks, 0 failures** (26.9 s idle; 46.5 s in
  a later run under concurrent load) (sections A–G:
  reciprocity/existence, `e | n` and `max E = n`, no-gain, classical contrast,
  degree census with characteristic-2 controls, ring windows, hybrid criterion).
* `tests/test_theory.py` — **8794 branch pairs, 0 mismatches** (collision
  criterion and full collision set), 1026 windows, 60/60 boundary cases
  `a_l + a_r = e − 1`, 11 branch triples, 16 `(q,n)` families (12 attaining
  `e = n`), ring algebra on 625 native-vs-CRT products; 424.4 s.
* `tests/test_quantum.py` — 18 bridge rows, 6 CSS instances, 13 recovery
  instances (window injective; `α` and `α + e_R` genuinely ambiguous), 4 non-free
  instances; all pass, 144.2 s.
* `src/python/experiments.py` — nine data tables, **209 rows**, deterministic,
  ≈14 s.
* MAGMA sources provided in `src/magma/` are **unexecuted** (no interpreter in
  the environment); the numbers quoted come from the Python runs.
* PDF: produced after installing TeX Live in the environment — 17 pages, `pdflatex`
  twice, 0 errors. Unavailable: nothing that the manuscript needs.

## CRITICAL ISSUES RESOLVED

1. **Refuted headline** (ring fusion amplifies the window) → replaced by the
   no-gain theorem and the classical contrast. 2. Wrong exclusion of `q = 3` →
   corrected (only characteristic 2 fails). 3. Would-be priority for the order
   criterion → withdrawn and attributed. 4. Unvalidated generator polynomials
   accepted → validation added. 5. Wrong check-matrix row count (3650 spurious
   mismatches) → fixed. 6. `elem_of_order(q,1) = None` silently dropped families →
   fixed. 7. Exponential min-weight scan (>600 s hang) → budgeted
   increasing-weight scan returning "unknown". 8. Unbounded `2^t`/`4^t`
   enumeration (OOM) → pre-materialisation guards. 9. Recovery-test artefact
   (lookup table over all of `Z_n`) → window-restricted table plus separate
   injectivity/ambiguity checks. 10. Stale hand-recorded hybrid collision sets →
   replaced by the machine-computed Table 10. 11. Over-claiming "amplification"
   wording → renamed to "relaxation factor". All repairs were followed by
   re-runs; **CRITICAL = MAJOR = MODERATE = 0 open**.

## FILES CREATED

**Manuscript and audits:** `FINAL_MANUSCRIPT.pdf` (17 pp.), `FINAL_MANUSCRIPT.md`
(1105 lines), `FINAL_MANUSCRIPT.tex` (regenerated from the Markdown),
`manuscript_draft.md` (superseded draft), `manuscript_blueprint.md`,
`PDF_COMPILATION_STATUS.md`, `SOURCE_AUDIT.md`, `quantum_model_decision.md`,
`RESEARCH_GAP_AND_NOVELTY.md`, `MATHEMATICAL_CONSISTENCY_AUDIT.md`,
`FINAL_REFEREE_AUDIT.md`, `references.bib`, `references_verified.csv`,
`research_state.md`, `CHANGELOG.md`, `LICENSE_OR_USAGE_NOTES.txt`,
`FINAL_RESEARCH_REPORT.md`, `FINAL_RESEARCH_REPORT.txt`, `README.md`.
**Code:** `src/python/{finite_field,ring_r,cyclic_codes,synchronization,quantum_css,experiments}.py`;
`src/magma/{ring_qsc.m,verify_tables.m,README.md}` (unexecuted);
`src/tools/{md2tex.py,build_pdf.sh}`; `tests/{test_theorems,test_theory,test_quantum}.py`.
**Data and results:** `data/{tables.json,examples.csv,examples.json,flagship_candidates.json,README.md}`;
`results/{computational_log.txt,theory_checks.json,quantum_log.txt,quantum_checks.json,theorem_log.txt,theorem_checks.json,experiments_log.txt,experiments_run.txt,verification_report.md}`.
**Tables and figures:** `tables/table2…table10*.csv`; `figures/interleaved_lift.svg`,
`figures/README.md`.
**Process:** `phase_reports/PHASE_00_REPORT.md … PHASE_23_REPORT.md` (24 files).

## FINAL PACKAGE

`research_package_2026-09-29.zip` — built from `research_package/`, whose tree
matches the required checklist (manuscript `.md` + `.tex`, all audits, model
decision, blueprint, bibliography + verification CSV, `src/python`, `src/magma`,
`src/tools`, `tests`, `data`, `results`, `figures`, `tables`, `phase_reports`,
`research_state.md`, `CHANGELOG.md`, `MANIFEST.sha256`,
`LICENSE_OR_USAGE_NOTES.txt`, `README.md`, `FINAL_RESEARCH_REPORT.md`/`.txt`,
`FINAL_MANUSCRIPT.pdf`).

Recipe for the archive (executed): copy the tree into `research_package/`,
generate `MANIFEST.sha256` with `find … | sha256sum` (excluding the manifest
itself), `zip -r research_package_2026-09-29.zip research_package`, then extract
into a fresh directory and check: file count (85/85), `sha256sum -c` of the
manifest inside the extract, `diff -r` between the package and the extract, and
absence of absolute or `..` paths in the archive. All four checks passed.
The archive (85 files, ≈234 kB, 96 entries) was extracted into a clean
directory and verified: 85/85 files, `sha256sum -c MANIFEST.sha256` all OK,
`diff -r` reports the extracted tree identical to the package, and the archive
contains no absolute or `..` paths. The numbers quoted above are from the
validated build; the archive is rebuilt at the end of the project with the same
recipe, and the manifest is regenerated with it. Verified: 85 files before the PDF was compiled and
89 files afterwards, checksum manifest re-verified inside the extract, no
absolute paths. Declared unavailable: only executed MAGMA output (no interpreter
was available for MAGMA; the PDF was compiled once TeX Live was installed).
