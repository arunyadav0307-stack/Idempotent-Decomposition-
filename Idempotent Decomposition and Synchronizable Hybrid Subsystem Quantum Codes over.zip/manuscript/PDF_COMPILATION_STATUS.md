# PDF COMPILATION STATUS

**Status: COMPILED — `FINAL_MANUSCRIPT.pdf` exists (17 pages, letter, pdfTeX / TeX Live 2025).**

`pdflatex` was not available in the initial working environment, so the manuscript
was first delivered as Markdown + LaTeX with this file recording that no PDF
existed. TeX Live was then installed inside the environment
(`texlive-latex-base`, `texlive-latex-recommended`, `texlive-fonts-recommended`,
`texlive-latex-extra`, `lmodern`), the LaTeX source was completed and the PDF was
compiled with **0 errors**. Nothing about the PDF is simulated: the file is the
direct output of the two `pdflatex` runs whose transcripts are preserved.

## Exact build

```bash
# reproduce (from the directory containing FINAL_MANUSCRIPT.tex)
sh src/tools/build_pdf.sh          # runs pdflatex twice and copies the PDF out
```

which is equivalent to

```bash
pdflatex -interaction=nonstopmode -halt-on-error FINAL_MANUSCRIPT.tex
pdflatex -interaction=nonstopmode -halt-on-error FINAL_MANUSCRIPT.tex
```

No BibTeX run is needed (the reference list is self-contained) and no figure file
is included (`figures/interleaved_lift.svg` is a package extra, not an
`\includegraphics` input), so two passes suffice.

## Verified properties of the compiled document

| Property | Value |
|---|---|
| Pages | 17 |
| Page size | 612 × 792 pt (letter) |
| Producer | pdfTeX-1.40.26 (TeX Live 2025/Debian) |
| Errors | 0 (`grep -c '^! '` on both pass logs) |
| Undefined references/citations | 0 |
| Missing characters | 0 (the source is ASCII-only) |
| Overfull boxes | 9 (all under 60 pt, inside table cells; no content is cut off) |
| Transcripts | `results/latex_pass1.log`, `results/latex_pass2.log`, `results/latex_full_log.txt` |

## Source-to-PDF consistency

* `FINAL_MANUSCRIPT.tex` is generated deterministically from
  `FINAL_MANUSCRIPT.md` by `src/tools/md2tex.py` (bundled), so the PDF, the
  Markdown and the LaTeX carry the same statements and the same numbers; the
  numbers themselves come from `src/python/experiments.py` (Section 6 of the
  manuscript) and are stored in `tables/*.csv` and `data/tables.json`.
* Section, theorem, lemma, corollary, remark, question and table numbers in the
  PDF coincide with the numbers used in the Markdown and in the audits
  (Sections 1–7, Appendices A–C).
* A title-page footnote states that the document was produced by an automated
  research pipeline, that no author identity is asserted, and that the framework
  belongs to the cited literature while the odd-characteristic results are
  re-derived here.

## Package contents that relate to the PDF

| File | Role |
|---|---|
| `FINAL_MANUSCRIPT.pdf` | the compiled manuscript (17 pp.) |
| `FINAL_MANUSCRIPT.tex` | LaTeX source (ASCII-only, self-contained) |
| `FINAL_MANUSCRIPT.md` | Markdown source of the same manuscript |
| `src/tools/md2tex.py` | the converter that produced the `.tex` from the `.md` |
| `src/tools/build_pdf.sh` | one-command rebuild |
| `results/latex_*.log` | compiler transcripts (proof of the build) |
