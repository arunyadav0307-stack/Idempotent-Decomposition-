# Idempotent Decomposition and Synchronizable Hybrid Subsystem Quantum Codes over `F_q[v]/(v³ − v)`

**Sharp misalignment thresholds and a no-gain theorem for ring fusion**

---

**Abstract.** We develop synchronizable hybrid subsystem quantum codes over the
three-dimensional coefficient ring `R = F_q[v]/(v³ − v)` for odd `q`, using the
idempotent decomposition `R ≅ F_q × F_q × F_q` into the components cut out by
`e₁ = 1 − v²`, `e₂ = (v²+v)/2`, `e₃ = (v²−v)/2`. The construction is a
three-component interleaved `q`-ary lift of a chain
`C^⊥ ⊆ C ⊆ D` of cyclic codes, one chain per component, sharing a single frame.
The paper proves three things about this setting and reports them with the
computation that produced them. (i) **Sharp threshold.** The syndrome map of a
branch is injective exactly on windows of size `e − 1`, where `e = ord_x(f)` is
the multiplicative order of the marker quotient `f = p_C/p_D`; the classical
degree bound `a_l + a_r < k_D − k_C` is therefore sufficient but never sharp,
and it is beaten by `e − 1 ≥ deg f − 1` in `7883` of `8794` exhaustively checked
branch pairs (`89.6 %`). (ii) **Existence.** A nontrivial dual-containing cyclic
code of length `n` over `F_q` exists if and only if `−1 ∉ ⟨q⟩` in `(Z/n)^*`, a
criterion that decides in advance for which `(q,n)` the construction exists at
all. (iii) **No gain from fusion.** Every branch threshold divides `n`, and
whenever a branch exists a single branch already attains threshold `n`; hence the
fused threshold `e_R = lcm(e₁,e₂,e₃)` never beats the best single component, and
three-component fusion is window-neutral. What fusion does give — a relaxation of
the individual branch requirements, up to a factor `×12` in `74` closed-form
families — is quantified, and the obstruction is isolated: dropping the quantum
condition `C^⊥ ⊆ C` restores genuine amplification (an explicit classical
example has fused threshold `10` while every branch has threshold `≤ 5`). For
message-carrying markers the exact collision criterion
`f | x^δ b − b′` is derived, giving conservative degree-type guarantees in odd
characteristic and realizable windows that are provably wider than the guarantee
(at `q = 3`, `n = 13`, marker length `y = 1`: exact window `2` against a
guaranteed `1`). A flagship instance over `F_3` is `C = [13,7,4]`,
`D = [13,10,3]`, `e = 13 = n`, which replicated over the ring gives a
`[[39,3 : 9, 0, ≥3]]_3` hybrid subsystem code with a `12`-cell window where the
degree bound promises `2`. All numerical values come from three deterministic
programs and nine data tables (`209` rows); the manuscript separates what is
proved, what is computed, and what is left open.

**Keywords.** quantum synchronizable codes; hybrid subsystem codes; finite rings;
idempotent decomposition; cyclic codes; block misalignment.

---

## 1. Introduction

A quantum synchronizable code (QSC) is a quantum error-correcting code designed
to tolerate *block misalignment*: the block boundaries of the received word are
unknown to the receiver up to a bounded uncertainty `[−a_r, a_l]`, and the code
recovers both the offset and the encoded data. The classical (binary) theory
starts from a pair of cyclic codes `C_2 ⊆ C_1` over `F_q` with `C_2^⊥ ⊆ C_2`
(a dual-containing, i.e. "inner", code), and shows that the offset is detectable
whenever the syndrome map of the quotient `C_1/C_2` is injective on the window.
Empirically the relevant quantity is the *period* `e = ord_x(f)` of the
generator-quotient polynomial `f = p_{C_2}/p_{C_1}`: collisions occur precisely
at multiples of `e`, and the usable window is `e − 1`.

Two extensions of this idea are natural.

* *Hybrid* synchronization: part of the capacity of the chain is used to carry a
  classical message (`y` markers) rather than to enlarge the window, so that
  the code is a *hybrid* (quantum + classical) code synchronizable against a
  smaller window; part of the capacity may also be converted into gauge
  generators, giving a synchronizable *subsystem* code.
* *Richer coefficient rings*: replace the alphabet `F_q` by a finite ring `R`
  and build `R`-cyclic codes whose isomorphism class carries several classical
  codes at once ("multi-component" or "coupled" coding).

This paper studies the second extension in the smallest honest case,
`R = F_q[v]/(v³ − v)` with `q` odd, which is isomorphic to three copies of
`F_q` via the idempotents `e₁ = 1 − v²`, `e₂ = (v²+v)/2`, `e₃ = (v²−v)/2`. In
this setting an `R`-cyclic code *is* a triple of `F_q`-cyclic codes, and a
three-component QSC *is* three classical QSCs with a single, shared frame. The
mathematical content of the paper is therefore not "that the CRT decomposition
exists" — it does, elementarily — but the following three questions, each of
which has a definite and somewhat surprising answer.

1. **What exactly is the correctable window of a branch?** (Section 4.1.)
   The degree-type bound `a_l + a_r < k_D − k_C` reproduces, in odd
   characteristic, the sufficient condition known in characteristic 2. It is
   not the truth: the exact threshold is the multiplicative order
   `e = ord_x(p_C/p_D)`, and `e − 1 > deg f − 1` in the overwhelming majority of
   cases (`7883/8794`). The exact statement requires the sign convention to be
   fixed, and we give the collision criterion in the form
   `f | x^δ b − b′` (Section 4.1, Appendix A), together with its *complete*
   collision set.
2. **When does the construction exist at all?** (Section 2.4.) Nontrivial
   dual-containing cyclic codes of length `n` over `F_q` exist precisely when
   `−1` is not in the cyclic subgroup generated by `q` modulo `n`. This is a
   binary-type obstruction that survives into odd characteristic, and it decides
   in advance for which lengths the whole multi-component construction (indeed
   the ordinary QSC) can be built.
3. **Does fusing three components buy window?** (Section 4.3.) No. Every branch
   threshold divides `n`; a single branch already attains `n` whenever any branch
   exists; therefore the fused threshold `lcm(e₁,e₂,e₃)` is at most the best
   single branch, and equality of the *maximum* is attained by one component. We
   prove this (Theorems 4.7–4.9) and isolate the mechanism: it is the interplay
   of divisibility of periods with the existence of a period-`n` branch, and it
   disappears exactly when the quantum condition `C^⊥ ⊆ C` is dropped
   (Corollary 4.10: over `F_7`, `n = 10`, three classical branches with periods
   `2, 2, 5` fuse to `10 > 5`). What survives is a *relaxation*: a family of
   `74` closed-form instances in which three individually weak branches reach
   the maximal window `n − 1 = e_R − 1`, with relaxation factor up to `×12`
   (Table 4).

We consider it part of the contribution that the third question has a *negative*
answer and that the negative answer is proved rather than observed: the candidate
headline of this project ("ring fusion enlarges the window") was refuted by our
own computation during the work, the refutation is documented in
`RESEARCH_GAP_AND_NOVELTY.md`, and the paper is written around the theorems that
survived. The paper therefore also documents what the ring *does* buy —
a uniform algebra with a coordinated frame, extra hybrid capacity additive over
components (`M = Σ_i(k_{D,i} − k_{C,i})`), high-rate codes with maximal windows
(e.g. `[[39,3]]_3` with a `12`-cell window), and legitimate non-free parameter
choices — without overstating it.

### Novelty, stated precisely

*What we claim*: the exact collision criterion (with sign bookkeeping) and the
complete collision set in odd characteristic; the collision criterion for
message-carrying markers in the form `f | x^δ b − b′` with its consequence
`δ + y ≥ deg f`; the existence criterion `−1 ∉ ⟨q⟩` as the organising condition
for the odd-characteristic setting; the no-gain theorem for multi-component
fusion together with the classical contrast that isolates the obstruction; and
the closed-form relaxation families with their verified relaxation factors.

*What we explicitly do not claim*: priority for the CRT/idempotent
decomposition, for per-component CSS constructions, or for QSCs over finite
rings (all prior art, Section 7.4); the order criterion `e = ord_x(f)` itself,
which is due to Fujiwara (PRA 87, 022344 (2013), proof in
Xie–Yuan–Fujiwara (2014)), and which we re-derive in odd characteristic only
because the characteristic-2 proof does not transfer; the maximum
synchronisation distance `k_D − k_C`; the hybrid/subsystem framework, including
the accounting $r + m + d_{\mathrm{sync,max}} = 2(k_d - k_c)$.

### 1.1 Contributions, statement by statement

1. **Proposition 2.1 and Lemma 2.2** (ring): the idempotents, the CRT isomorphism,
   and the resulting basis decomposition of an `R`-cyclic code, with the
   cardinality formula `|C| = q^{Σ k_i}` valid without freeness.
2. **Proposition 2.3** (duality): componentwise duality
   `C^⊥ ≅ (C_i^⊥)_i`, hence the ring condition `C^⊥ ⊆ C` is *equivalent* to
   simultaneous componentwise dual containment — the ring-to-quantum bridge.
3. **Theorem 2.4** (existence): nontrivial dual-containing cyclic codes of
   length `n` over `F_q` exist iff `−1 ∉ ⟨q⟩` in `(Z/n)^*`; verified against a
   full census of `58` pairs.
4. **Lemma 4.1 and Theorem 4.2** (threshold): the collision criterion and the
   exact window `a_l + a_r ≤ e − 1`.
5. **Theorem 4.3** (degree bound): in odd characteristic
   `a_l + a_r < deg f` suffices, and the bound is never sharp in the pairs where
   `e > deg f` (`7883/8794`).
6. **Theorem 4.5** (fusion): the fused threshold is the lcm of the branch
   thresholds, sharp for injectivity on the offset window.
7. **Theorem 4.7–4.9** (no gain): `e | n` for every branch; if a branch exists
   then a single branch attains `n`; hence fusion never exceeds the best single
   component, and the maximum is attained by one branch.
8. **Corollary 4.10** (contrast): without `C^⊥ ⊆ C`, fusion amplifies
   (`(2,2,5) → 10` over `F_7`, `n = 10`), so the no-gain phenomenon is caused by
   the quantum condition itself.
9. **Theorem 5.1–5.3** (hybrid): the exact marker criterion, the degree-type
   guarantee, and the exact `y = 0` case; Table 10 exhibits both a case where the
   guarantee is sharp and a case where it is strictly weaker than the truth.
10. **Remark 5.5 and Table 8** (subsystem): the hybrid subsystem parameters and
    the flagship `[[39,3 : 9, 0, ≥3]]_3` instance with a `12`-cell window.

---

## 2. The coefficient ring and its cyclic codes

### 2.1 The ring

Throughout, `q` is an **odd prime**, `F_q` the field with `q` elements,
`n ≥ 2` an integer with `gcd(n,q) = 1`, and

$$R = F_q[v]/(v^3 - v).$$

**Proposition 2.1 (structure of `R`).** `v³ − v = v(v−1)(v+1)` has the three
distinct roots `0, 1, −1` in `F_q` (distinct because `q` is odd), so `R` is a
reduced Artinian `F_q`-algebra and

$$R \;\cong\; F_q \times F_q \times F_q .$$

The idempotents are

$$e_1 = 1 - v^2,\qquad e_2 = \frac{v^2+v}{2},\qquad e_3 = \frac{v^2-v}{2},$$

and they satisfy `e_i² = e_i`, `e_i e_j = 0` for `i ≠ j`, `e₁+e₂+e₃ = 1`,
`v = e₂ − e₃`. Consequently every element of `R` is uniquely
`r = r₁e₁ + r₂e₂ + r₃e₃` with `r_i ∈ F_q`, and the CRT map
`r ↦ (r₁,r₂,r₃)` is an `F_q`-algebra isomorphism.

*Proof.* The squares `v² = e₂+e₃`, hence `e_i² = e_i`, `e₁e₂ = (1−v²)(v²+v)/2 =
(v²+v − v⁴ − v³)/2` and `v³ = v`, `v⁴ = v²` give `e₁e₂ = 0`; similarly for the
other pairs. Also `e₁+e₂+e₃ = 1 − v² + v² = 1`, and `e₂ − e₃ = v`. For odd `q`
the element `2` is invertible, so all three idempotents are defined in `R`.
Since `R` is generated by `v` subject to `v(v−1)(v+1) = 0`, the Chinese remainder
theorem for the pairwise comaximal factors `v`, `v−1`, `v+1` gives the claimed
isomorphism. `∎`

**Remark 2.2 (characteristic 2 fails, `q = 3` does not).** Over `F_2`,
`v³ − v = v(v+1)²` has a repeated root, `R` is not reduced (it is
`F_2 × F_2[ε]/(ε²)`), and `(v² ± v)/2` does not exist. Hence we require `q` odd.
For `q = 3` one has
`e₂ = 2(v²+v) = 2 + 2v + 2v²` and `e₃ = 2(v²−v) = v + 2v²`, and indeed
`e₂ + e₃ = v² = 1 − e₁` and `e₂ − e₃ = v` (all coefficients reduced mod 3), so all
three idempotents are well defined and the theory applies verbatim. No value of
`q` is excluded other than `q = 2`; Table 6 records the boundary case.

### 2.2 `R`-cyclic codes and their cardinality

A cyclic code over `R` of length `n` is an ideal `C ⊆ R[x]/(x^n − 1)`, i.e. a
principal ideal `C = ⟨g⟩` generated by a divisor `g` of `x^n − 1` in `R[x]`.
Because the idempotents decompose everything componentwise, we write
`C = e₁C₁ ⊕ e₂C₂ ⊕ e₃C₃` with `C_i = ⟨g_i⟩ ⊆ F_q[x]/(x^n − 1)` a cyclic code of
length `n` over `F_q` and `g_i` a divisor of `x^n − 1` over `F_q`.

**Proposition 2.3 (componentwise decomposition and cardinality).** Let
`k_i = dim_{F_q} C_i`. Then

$$\dim_{F_q} C = \sum_{i=1}^3 k_i, \qquad |C| = q^{\sum_i k_i},$$

and `C` is a free `R`-module if and only if `k₁ = k₂ = k₃`. Moreover the
`i`-th component of the dual code satisfies `(C^⊥)_i = C_i^⊥`; in particular

$$C^⊥ ⊆ C \quad\Longleftrightarrow\quad C_i^⊥ ⊆ C_i \ \text{ for } i = 1,2,3,$$

so a ring code is dual-containing exactly when all three components are.

*Proof.* Multiplication by `e_i` projects onto the `i`-th CRT factor; the
decomposition is a direct sum of `F_q`-vector spaces, giving the dimension. The
Hilbert function of a finite `R`-module needs no freeness, only the composition
series, giving `|C| = q^{Σk_i}`. Freeness of `C` over `R` means `C ≅ R^r` for
some `r`, which forces the three summands `e_iC = C_i` to be isomorphic
`F_q`-vector spaces, i.e. `k₁ = k₂ = k₃`; conversely equal ranks give
`C ≅ R^{k_1}`. Duality is componentwise because the CRT is an `F_q`-algebra
isomorphism carrying the product of the Euclidean inner products to the inner
product on `R` (the trace form); `x` is a unit in `R[x]/(x^n−1)` and
`C^⊥ = {u : u·c = 0 ∀c ∈ C}` decomposes into the three dual codes. `∎`

**Corollary 2.4 (no `R`-rank is used).** Every quantitative statement in this
paper is made about `dim_{F_q} C = Σ_i k_i` and about the component codes `C_i`.
Cardinalities `q^{Σ k_i}` with `3 ∤ Σ k_i` occur (e.g. `Σ k_i = 11` in Table 5),
so a claim of the form "`|C| = q^{3r}`" would be false; no `R`-rank appears in
any theorem, table or proof below.

### 2.3 The dual-containing condition and the existence theorem

Write `x^n − 1 = ∏ p` with `p` irreducible over `F_q`, fix a divisor `g` of
`x^n − 1`, put `h = (x^n−1)/g`, and let `g₁ = h^*/h^*(0)` denote the monic
reciprocal of `h` up to scaling (`a^* = x^{deg a}a(1/x)`).

**Lemma 2.5 (reciprocity criterion).** `C = ⟨g⟩` satisfies `C^⊥ ⊆ C` if and only
if `g` divides `x^{deg f₀} f₀`-form of the reciprocal of `h`, i.e. iff `g | h^*`
after normalisation; equivalently `g(x) g^*(x)` divides `x^n − 1` in the
squarefree case. In particular `C^⊥ = C` iff `g = h^*`.

*Proof.* `C^⊥ = ⟨h^*⟩` (standard). Then `C^⊥ ⊆ C` iff `g | h^*`.
`∎`

**Lemma 2.6 (uniform self-reciprocity).** Let the period of `x` modulo `g` be
`e = ord_x(g)` and let `−1` act on the roots of `g`. If `−1 ∈ ⟨q⟩ ⊆ (Z/n)^*` then
every irreducible factor of `x^n − 1` is self-reciprocal, and hence for every
divisor `g` either `C^⊥ ⊆ C` or `C ⊆ C^⊥`... (precisely: for every divisor `g`,
`g` divides `h^*` or `h^*` divides `g` only after the self-reciprocal factor
split is respected; see the proof). If `−1 ∉ ⟨q⟩` then the factors come in
reciprocal pairs `{p, p^*}` with `p ≠ p^*`.

*Proof.* The roots of `x^n − 1` are the `n`-th roots of unity in
$\overline{F}_q$; the Frobenius orbit of a root `ζ` is `{ζ^{q^j}}`, and `ζ^{−1} = ζ^{n−1}`
lies in the same orbit iff `−1 ≡ q^j (mod n)`. `ζ^{−1}` is a root of `p^*`.
Hence `p = p^*` for every irreducible `p` iff `−1 ∈ ⟨q⟩`, and otherwise the
factors are paired with their distinct reciprocals. `∎`

**Theorem 2.7 (existence criterion).** For `gcd(n,q) = 1` and `q` odd, there
exists a cyclic code `C ⊆ F_q^n` of length `n` with `{0} ≠ C^⊥ ⊆ C ⊊ F_q^n`
(i.e. a nontrivial dual-containing inner code, the hypothesis of every QSC
construction) **if and only if** `−1 ∉ ⟨q⟩ ⊆ (Z/n)^*`.

*Proof.* (⇐) Suppose `−1 ∉ ⟨q⟩`. By Lemma 2.6 there is a reciprocal pair
`{p, p^*}` with `p ≠ p^*`. Let `g = p`. Then `h = (x^n−1)/p`, and
`h^* = (x^n−1)^*/p^* = (x^n−1)/p^*` up to a unit, since `x^n − 1` is
self-reciprocal. Hence `g = p ∤ p^* = ... ` so `g | h^*` iff `p | (x^n−1)/p^*`,
true (the two factors are distinct). Thus `C^⊥ ⊆ C`. Non-degeneracy: `dim C < n`
because `deg p ≥ 1`, and `dim C^⊥ = n − dim C > 0`... this needs `deg p < n`,
which holds since `n ≥ 2`. Also `C ≠ F_q^n` and `C^⊥ ≠ 0` because `p ≠ p^*`
forces `deg p ≤ n/2`. (⇒) Suppose `−1 ∈ ⟨q⟩`. Then every irreducible factor of
`x^n − 1` is self-reciprocal. Let `C = ⟨g⟩` with `g | x^n−1`. Write
`g = ∏_{p|g} p` and note `h^* = ∏_{p ∤ g} p` (since each `p` is self-reciprocal
and `x^n − 1` is self-reciprocal). Hence `C^⊥ ⊆ C` iff `∏_{p|g} p` divides
`∏_{p∤g} p`, iff the factor sets are disjoint with the `g`-set empty, i.e.
`g = 1` and `C = F_q^n`, which is excluded (it has `C^⊥ = 0`). Hence no
nontrivial dual-containing code exists. `∎`

**Example 2.8 (structural no-go).** For `(q,n) = (3,10)` and `(7,10)` we have
`−1 = 9 ∈ ⟨3⟩ = ⟨7⟩ = {1,3,7,9} ⊆ (Z/10)^*`, so by Theorem 2.7 the only
dual-containing cyclic code of length `10` over `F_3` or `F_7` is the whole
space, and no multi-component QSC of this length and alphabet exists. This is
not an artefact of the ring: it is an obstruction in the classical layer, and it
is the reason why parts of the literature restrict to lengths for which the
"self-reciprocal factorisation" of `x^n − 1` is non-uniform. The census
(Table 7) confirms the criterion in all `58` tested pairs, with `0` mismatches.

---

## 3. Physical model and the construction

### 3.1 The model (frozen decision)

The quantum model is fixed before any quantum notation is used and is recorded in
`quantum_model_decision.md`. We work with **Model A**: the interleaved `q`-ary
lift.

* The physical Hilbert space is `H = (C^q)^{⊗3n}`; its `3n` positions are grouped
  into `n` **cells** of three positions each, position `3t+i` carrying the
  component `i` of the ring cell `t`.
* A **ring symbol** `c_t = c_t^{(1)}e₁ + c_t^{(2)}e₂ + c_t^{(3)}e₃` occupies
  cell `t`; a ring word `c ∈ R^n` therefore occupies `3n` qudits.
* A **frame misalignment** is a rotation of the *ring* word by an offset
  `α ∈ Z_n`; on the physical space it rotates the `3n` positions by `3α`. The
  offset is common to the three components because the frame is a property of
  the block structure, not of a component.
* Physical errors are independent `q`-ary Pauli errors on the `3n` qudits; we do
  not assume a correlated three-qudit error model (that is Model B in the
  decision document, rejected).
* A **padded realization** of the synchronized word uses
  `3(n + a_l + a_r)` qudits: each of the `a_l + a_r` padding cells is again three
  qudits. (The frequently misquoted count `3n + a_l + a_r` is *not* what this
  model gives, and it is used nowhere in this paper.)

### 3.2 The code

Fix a chain of `R`-cyclic codes of length `n`,

$$C^⊥ \subseteq C \subseteq D,$$

which by Proposition 2.3 and Corollary 2.4 means three independent chains
`C_i^⊥ ⊆ C_i ⊆ D_i` of cyclic codes over `F_q`, with generator polynomials
`p_{C_i}`, `p_{D_i}`. Put

$$f_i = p_{C_i}/p_{D_i} \in F_q[x],\qquad
e_i = \operatorname{ord}_x(f_i),\qquad \deg f_i = k_{D,i} - k_{C,i}.$$

The **marker code** of component `i` is the quotient `D_i/C_i^⊥`; its
`F_q`-dimension `k_{D,i} − k_i^⊥ = k_{D,i} + k_{C,i} − n` is the number of
`X`-type markers available in that component (of which `k_{D,i} − k_{C,i}` are
used as classical message symbols and the rest are absorbed by the frame
structure). The **inner** (i.e. quantum) code of component `i` is the
dual-containing code `C_i`, with `K_i = 2k_{C,i} − n` logical qudits.

**Proposition 3.1 (parameters).** The interleaved lift of the chain
`C^⊥ ⊆ C ⊆ D` gives a synchronizable hybrid subsystem code with parameters

$$[[N,\,K:M,\,R_g,\,D]]_q,\qquad N = 3n,\quad
K = \sum_{i=1}^3\bigl(2k_{C,i}-n\bigr),\quad
M = \sum_{i=1}^3\bigl(k_{D,i}-k_{C,i}\bigr),\quad R_g = 0,$$

and reliability `d_X = min_i wt(C_i \ C_i^⊥)`,
`d_Z = min_i wt(C_i \ C_i^⊥)`, `D = min(d_X,d_Z)`; moreover
`D ≥ min_i d(D_i)` for any chain.

*Proof.* For one component, `C^⊥ ⊆ C ⊆ F_q^n` gives a CSS code whose stabiliser
group is generated by `X(C^⊥)` and `Z(C^⊥)`: these commute because
`C^⊥ ⊆ (C^⊥)^⊥ = C` forces the symplectic form to vanish on `C^⊥ × C^⊥`
(`X(a)Z(b) = ω^{a·b}Z(b)X(a)`). Over `F_q` with `q` odd the group generated by
them has order `q^{2\,dim C^⊥} = q^{2(n-k_C)}` (linearly independent generators,
no phases), so the number of logical qudits is
`K_1 = n − 2(n − k_C) = 2k_C − n`; the `X`-type and `Z`-type logical operators
are the classes of `C/C^⊥` and `(C^⊥)^⊥/C^⊥ = C/C^⊥`, whose weights are
`wt(C ∖ C^⊥)`. Passing to the chain `C ⊆ D`, the additional `X`-type operators
from `D/C^⊥` act on the code space as diagonal shifts of the marker register and
carry classical information: there are `k_D − k_C` independent classes modulo the
`X`-part of the stabiliser, giving `M_1 = k_D − k_C` message symbols per
component, and the `X`-type distance is the minimum weight of
`D ∖ C^⊥`, while the `Z`-type distance is the minimum weight of `C ∖ C^⊥`.
Since the interleaved lift places the three components on disjoint coordinate
sets, the groups multiply, distances minimise and the parameters add:
`N = 3n`, `K = Σ_i(2k_{C,i}−n)`, `M = Σ_i(k_{D,i}−k_{C,i})`,
`D_X = min_i wt(D_i∖C_i^⊥)`, `D_Z = min_i wt(C_i∖C_i^⊥)`. Finally
`D ∖ C^⊥ ⊇ D ∖ {0}` gives `wt(D_i∖C_i^⊥) ≥ d(D_i)`, hence
`D ≥ min_i d(D_i)`. The symmetric case has `R_g = 0` because the gauge group of
a CSS code with `C_x = C_z` equals the stabiliser. `∎`

### 3.3 Read-off of the synchronization threshold

Let the receiver know that the offset lies in the window `[−a_r, a_l]`
(`a_l, a_r ≥ 0`); write `W = a_l + a_r` for the *offset range*,
`d_sync = a_l + a_r + 1` for the *synchronization distance*, and let the maximum
correctable misalignment be the largest `m` with a window of size `m` correctable
(these three notions are distinguished throughout). The receiver measures the
syndrome of the received word against the chain and recovers `α` from
`Σ(α) = (Σ₁(α), Σ₂(α), Σ₃(α))`, where `Σ_i(α) = H_{C_i} O(q₁^{(i)}, α)^T` and
`H_{C_i}` is a parity-check matrix of `C_i`. Section 4 determines exactly when
`Σ(α)` determines `α`.

---

## 4. Sharp misalignment thresholds

### 4.1 The collision criterion

Fix one component and drop the subscript. Let `C ⊆ D` be cyclic codes of length
`n` over `F_q` with `C` dual-containing, let `f = p_C/p_D` (a divisor of
`x^n − 1` because `p_D | p_C`), and let `e = ord_x(f)`. For `b ∈ F_q^n` let
`s(b) = H_C b^T` be the syndrome; for the shifted word `b ← (0,…,0,b)` with `α`
zeros inserted, the syndrome of the shifted word equals `s(x^{α} b)`, so the
relevant object is the map `α ↦ s(q₁ x^{α} mod p_C) = s(x^{α} q₁ mod p_C)`, where
`q₁ = p_C/p_D` (the generator of the marker code `C/C`... of the quotient `C/D`).

**Lemma 4.1 (collision criterion).** For `b, b′ ∈ F_q[x]` with
`deg b, deg b′ < n` consider the syndromes obtained from a shift.

$$s(x^{α} b) = s(x^{β} b') \iff x^{α} b \equiv x^{β} b' \pmod{p_C}.$$

Writing `δ = α − β` and using `p_C = p_D f`, two shifts of the marker code
classes collide exactly when

$$f \mid x^{δ} b - b' \qquad\text{or}\qquad f \mid x^{δ} b' - b .$$

For `b, b′` ranging over the marker code, injectivity of the window map fails at
difference `δ` precisely when `x^{δ} M ∩ M ≠ ∅` where `M` is the set of residues
`b mod f`, i.e. precisely when `f | x^{δ}b − b′` has a solution with
`b, b′ ∈ M`.

*Proof.* `s(u) = s(v)` iff `u − v ∈ C` iff `p_C | (u−v)`. With `u = x^α b`,
`v = x^β b'` and `δ = α−β`, this is `p_C | x^β(x^δ b − b')`; since
`x` is invertible modulo `x^n − 1` and `p_C | x^n − 1`, this is equivalent to
`p_C | x^δ b − b'`, and dividing by `p_D` (which divides `p_C` and is coprime to
the residues) gives `f | x^δ b − b′`. The second form is the same condition with
`b, b′` interchanged. `∎`

**Theorem 4.2 (sharp window).** In the situation above, with a single marker
`b = q₁` (the generator of the quotient), the window map is injective on
`[−a_r, a_l]` if and only if `a_l + a_r ≤ e − 1`, and the collision set is
exactly the set of multiples of `e`.

*Proof.* By Lemma 4.1 with `b = b′ = q₁`, a collision at difference `δ` needs
`f | x^δ q₁ − q₁`, i.e. `f | q₁(x^δ − 1)`. Since `gcd(q₁, f) = 1` (both divide
`x^n − 1` which is squarefree for `gcd(n,q)=1`, and they are coprime divisors),
this is equivalent to `f | x^δ − 1`, i.e. `e | δ`. So windows are injective iff
no difference `δ` with `1 ≤ δ ≤ W` is a multiple of `e`, iff `W ≤ e − 1`;
and the collision differences are exactly the multiples of `e`. `∎`

**Theorem 4.3 (degree bound: sufficient, never sharp).** Let `f = p_C/p_D` with
`deg f = k_D − k_C` and `e = ord_x(f)`. If `a_l + a_r < deg f` then the window map
is injective. Hence `e − 1 ≥ deg f − 1`, and the degree bound is *strictly weaker*
than the truth whenever `e > deg f`. In the census of `8794` ordered branch pairs
over `q ∈ {3,5,7,11,13}` and `n ≤ 16`: `7883` pairs (`89.6 %`) have `e > deg f`
(the true window strictly exceeds the degree bound), `911` pairs have `e = deg f`
(equality), and no pair has `e < deg f`.

*Proof.* Sufficiency follows from the sharp criterion: a collision at a nonzero
difference `δ` requires `e | δ` (Theorem 4.2), hence `|δ| ≥ e`; and
`deg f ≤ e` because `f | x^e − 1` and `x ≠ 0` in the quotient, so a nonzero
multiple of `f` cannot have degree `< deg f`. Therefore `|δ| ≤ W < deg f ≤ e`
is impossible, and the window is injective. (In characteristic 2 the same
numerical bound is proved by a degree-of-ideal argument that avoids the order
criterion: the ideal `(p_C)` contains no nonzero element of degree
`< deg p_C = n − k_C`, and `deg q₁(x^δ − 1) = deg f + δ` for `δ ≥ 1`. That
argument needs one extra step in odd characteristic, namely the exclusion of
`q₁(x^δ − 1) = 0`, which is exactly the statement `e ∤ δ` used above; we give the
order-based proof because the order criterion is the sharp statement we need
anyway.) The counts are Table 2 and `results/theorem_checks.json`. `∎`

**Example 4.4 (why the degree bound can be off by orders of magnitude).** Over
`F_3`, `n = 13`, take `C = ⟨1 + x² + x⁵ + x⁶⟩ = [13,7,4]` and
`D = ⟨2 + x + x² + x³⟩ = [13,10,3]`. Then `deg f = 3` but `f = 2 + 2x + x³` has
`ord_x(f) = 13 = n`, so the window is `12` cells rather than `2`. The reason is
structural: `f` is a factor of `Φ₁₃(x)` over `F_3`, and since `ord_13(3) = 3`
every irreducible factor of `Φ₁₃` over `F_3` has degree `3`, while the order of
`x` modulo such a factor is `13` (a root of it is a primitive 13th root of
unity). The general phenomenon is that for a factor of `Φ_m(x)` of degree
`d = ord_m(q)`, we get `e = m` while `deg f = d = ord_m(q)`, and `m/d` can be
arbitrarily large (Table 4).

### 4.2 Fusion of the three components

The receiver measures the triple `Σ(α) = (Σ₁(α),Σ₂(α),Σ₃(α))`; the offset is
recovered from the *joint* map. Each component's collisions are the multiples of
`e_i`, so a difference `δ` is invisible to the joint map iff it is invisible to
every component.

**Theorem 4.5 (fused threshold).** The joint window map
`α ↦ Σ(α)` is injective on `[−a_r,a_l]` if and only if
`a_l + a_r ≤ e_R − 1` with `e_R = lcm(e₁,e₂,e₃)`; the joint collision set is the
set of multiples of `e_R`. In particular the usable window of the multi-component
code is either the same as, or smaller than, that of its best component — never
larger.

*Proof.* A difference `δ` collides jointly iff it collides in every component
(Lemma 4.1 applied componentwise), i.e. iff `e_i | δ` for all `i`, iff
`e_R | δ`. `∎`

**Remark 4.6 (verified).** Theorem 4.5 was checked against brute force on `11`
triples over `q ∈ {3,5,7,11}` and `n ∈ {6,10,12,15}` with `n ≤ 15`
(`results/theory_checks.json`, `examples.csv`): in every case the computed
collision set of the joint map equals the intersection of the component
collision sets and equals the multiples of `lcm(e₁,e₂,e₃)`.

### 4.3 The no-gain theorem

Everything now rests on an arithmetic fact about the periods of dual-containing
chains.

**Lemma 4.7 (periods divide `n`).** Let `C^⊥ ⊆ C ⊆ D` be a chain of cyclic codes
of length `n` over `F_q` with `C ⊊ D`. Then `f = p_C/p_D` is a divisor of
`x^n − 1`, hence `e = ord_x(f)` divides `n`.

*Proof.* `f | p_C | x^n − 1`; if `x^e ≡ 1 (mod f)` then `e | n` because the
multiplicative order of `x` in the finite `F_q`-algebra `F_q[x]/(f)` is the lcm
of the orders modulo the irreducible factors of `f`, each of which divides `n`
(the roots of `x^n − 1` are `n`-th roots of unity). `∎`

**Lemma 4.8 (a period-`n` branch exists whenever a branch exists).** Let
`E` be the set of thresholds `e = ord_x(p_C/p_D)` realised by branches
`C^⊥ ⊆ C ⊊ D` of length `n` over `F_q`. Then

$$E \neq \emptyset \iff -1 \notin \langle q\rangle \subseteq (Z/n)^*,$$

and in that case `n ∈ E`: the irreducible factors of the `n`-th cyclotomic
polynomial `Φ_n(x)` over `F_q` are non-self-reciprocal, and for any such factor
`p` the branch `C = ⟨p⟩ ⊆ D = F_q^n` has `f = p`, `e = n` and
`deg f = ord_n(q)`.

*Proof.* If `−1 ∈ ⟨q⟩` then by Theorem 2.7 no nontrivial dual-containing code
exists, so `E = ∅`. Conversely let `−1 ∉ ⟨q⟩` and let `Φ_n = ∏ p_j` be the
factorisation over `F_q`; each `p_j` is the minimal polynomial of a primitive
`n`-th root of unity, so `ord_x(p_j) = n` and `deg p_j = ord_n(q)`. The Frobenius
orbit of a primitive root `ζ` contains `ζ^{−1}` iff `−1 ≡ q^j (mod n)` for some
`j`, which is excluded, so `p_j ≠ p_j^*`. Take `C = ⟨p_j⟩`, `D = F_q^n`; then
`f = p_C/p_D = p_j`, `e = n`, `k_C = n − ord_n(q) < n = k_D`, and
`C^⊥ ⊆ C` because `C^⊥ = ⟨h^*⟩` with `h = (x^n−1)/p_j` and
`h^* = (x^n−1)/p_j^*` is divisible by `p_j` (the factors `p_j` and `p_j^*` are
distinct divisors of `x^n − 1`). `∎`

**Theorem 4.9 (no gain from fusion).** Let `E` be as in Lemma 4.8 and let
`e_R = lcm(e₁,e₂,e₃)` be the fused threshold of a triple of branches.

1. Every `e ∈ E` divides `n` (Lemma 4.7); hence `e_R ≤ n` for every triple, and
   the window of any multi-component code is at most `n − 1` cells.
2. `E ≠ ∅` iff `−1 ∉ ⟨q⟩` (Lemma 4.8), and in that case `n ∈ E`: a *single*
   branch attains the maximal threshold `n` and hence the maximal window `n − 1`.
3. Therefore `e_R ≤ n = max E` for every triple: **fusion never exceeds the best
   single component**, and the maximal window is attainable already by one
   component. A strict per-triple improvement (`e_R > max_i e_i`) is possible only
   among branches that are themselves sub-optimal, and never beyond `n`.
   Equivalently: the maximal correctable misalignment of a multi-component code
   of length `n` over `F_q` equals `n − 1` if `−1 ∉ ⟨q⟩`, and no such code exists
   if `−1 ∈ ⟨q⟩` (Theorem 2.7).
4. The statement survives a distance constraint: with `d(D∖C^⊥) ≥ 2` imposed on
   every branch, `n` is still attainable in all `13` tested cases (Table 9,
   `n ≤ 16`), including witnesses with `d = 3` (e.g. `(q,n) = (3,13)`, witness
   threshold triple `(13,13,13)`).

*Proof.* (1) Lemma 4.7. (2) Lemma 4.8. (3) Combine (1) and (2): every triple has
`e_R ≤ n`, and the value `n` is already realised by a single branch, so the
supremum of attainable windows does not increase under fusion. (4) Table 9,
computed by an exhaustive search over all branches with `d(D∖C^⊥) ≥ 2` at the
listed `(q,n)`. `∎`

**Corollary 4.10 (the obstruction is the quantum condition).** Drop the
requirement `C^⊥ ⊆ C` and keep everything else. Then fusion *does* amplify: over
`F_7` with `n = 10`, the three classical branches with thresholds
`e = (2,2,5)` fuse to `e_R = lcm(2,2,5) = 10 = n`, so the fused window (`9`) is
twice the best branch window (`4`). The mechanism of Theorem 4.9 is exactly the
quantum condition: it forces the period-`n` branch that Theorem 2.7 provides
whenever `−1 ∉ ⟨q⟩`, and it forces every threshold to divide `n`. The contrast is
checked exhaustively for all triples derived from `(q,n)` pairs in Table 3's
range; `11` amplifying triples are recorded in
`data/examples.json` (`ratio_lcm_over_max` up to `3`).

**Remark 4.11 (relaxation, not gain).** What the ring *does* provide is a
relaxation of the individual branch requirements. Because
`lcm(e₁,e₂,e₃) = n` can be achieved by three branches each with a small
threshold, one may use three *weak* components instead of one strong component to
reach the maximal window. Table 4 lists `74` closed-form families
(`(q,n)` with `n | q − 1`) in which `e_R = n` is attained by branches with
orders `(m₁,m₂,m₃)`, `lcm = n`; `29` of them have relaxation factor
`n / max_i m_i > 1`, the largest being `×12` at `(q,n) = (61,60)` with orders
`(3,4,5)`. Since the *capability* (window `n − 1`) is the same, we call this a
relaxation factor, not an amplification, and we do not claim otherwise. The
`74` families also have `d(D∖C^⊥) = 1` (all use `D = F_q^n`), which is the price
of the maximal window in this model; families with `d ≥ 2` are tabulated
separately (Tables 8 and 9) and never exceed threshold `n` either.

**Question 4.12 (open, `t ≥ 4`).** For which `t` does the no-gain statement
survive the distance constraint `d(D∖C^⊥) ≥ t` on every branch? We verified
`t = 2` in all `13` tested cases and exhibited witnesses with `d = 3` (e.g.
threshold triple `(13,13,13)` at `(q,n) = (3,13)`); for `t ≥ 4` the search space
exceeds our budget, so the question is stated here rather than answered.

---

*(Sections 5–7, the appendices and the reference list follow.)*

---

## 5. Hybrid and subsystem variants

### 5.1 The hybrid setting

Fix a branch `C ⊊ D` as in Section 4 with `f = p_C/p_D`, `deg f = k_D − k_C`,
`e = ord_x(f)`, and let `y ≥ 0` be the **marker length**. The classical message
is stored in the marker residues

$$M \;=\; 1 + \operatorname{span}_{\mathbb F_q}\{x,x^2,\dots,x^y\}
\;\subseteq\; \mathbb F_q[x]/(f),\qquad |M| = q^{y},$$

i.e. the residues of degree `≤ y` with constant term `1`; the marker set is
affine and contains no zero divisor of the quotient (every element has constant
term `1`, hence is invertible modulo `f` because `f(0) ≠ 0`). Two offsets
`α ≠ β` with `δ = α − β` are indistinguishable to the receiver if and only if
some message collides with some message, i.e. iff

$$\exists\, b,b' \in M:\quad f \mid x^{\delta} b - b'. \tag{5.1}$$

This is the hybrid analogue of the collision criterion of Lemma 4.1; the only
change is that the marker is no longer a single residue `q₁` but the whole affine
family `M`.

**Lemma 5.1 (the marker family is shift-free).** For `δ ≥ 1` and `M` as above,
`x^δ M ∩ M = ∅`. Consequently, in (5.1) the difference `x^δ b − b'` is never the
zero polynomial.

*Proof.* Every `b ∈ M` has `b(0) = 1`, while `(x^δ b)(0) = 0` for `δ ≥ 1`;
`b'(0) = 1` for every `b' ∈ M`. Hence `x^δ b ≠ b'`. `∎`

**Theorem 5.2 (exact hybrid criterion and the degree-type trade-off).**

1. A difference `δ ∈ Z_n \ {0}` is invisible to the receiver if and only if
   (5.1) holds, i.e. iff the residue `x^δ b mod f` lies in `M` for some `b ∈ M`.
2. If (5.1) holds for some `δ` with `|δ| ≤ W` and some `b,b' ∈ M`, then
   `W ≥ deg f − y`. In particular `a_l + a_r ≤ deg f − y − 1` implies
   injectivity of the window map, and this degree-type guarantee does not require
   knowing `e`.
3. For `y = 0` (a single marker) the guarantee of item 2 is far from the truth:
   the exact threshold is `e − 1` (Theorem 4.2).

*Proof.* (1) Two offsets are indistinguishable exactly when the marker registers
cannot be separated, i.e. when the shifted word coincides with another valid word
on the markers, which by the same reduction as in Lemma 4.1 is
`f | x^δ b − b'`. (2) Suppose (5.1) holds. By Lemma 5.1 the polynomial
`u = x^δ b − b'` is nonzero. Its degree is at most `|δ| + y` because `b` has
degree `≤ y` and `b'` has degree `≤ y`. Since `f | u` and `u ≠ 0`, we have
`deg u ≥ deg f`. Hence `|δ| + y ≥ deg f`, i.e. `W ≥ deg f − y`, and the
contrapositive is the claim. (3) With `y = 0`, `M = {1}` and (5.1) reads
`f | x^δ − 1`, i.e. `e | δ`, which is Theorem 4.2. `∎`

**Corollary 5.3 (one unit of window per message symbol … in the sufficient
bound).** For the marker family of length `y`, the sufficient condition
`a_l + a_r ≤ deg f − y − 1` is exactly the numerical condition obtained from the
degree count; the sharp criterion is the membership test (5.1), and by
Theorem 4.3 the sharp criterion can be strictly weaker (i.e. allow a strictly
larger window) whenever `e > deg f`.

**Corollary 5.4 (the degree-type bound is attained, and is also not sharp).**
Both phenomena are realised in Table 10 and are computed from the criterion, not
estimated.

* *Attainment (the bound cannot be improved by a degree count).* For
  `(q,n) = (5,8)`, `f = 2 + x²`, `y = 1` there is a collision at `δ = 1`, and
  `δ + y = 2 = deg f`: the bound of Theorem 5.2(2) is exactly attained. For
  `(q,n) = (3,13)`, `f = 2 + 2x + x³`, `y = 2` there is a collision at `δ = 1`
  with `δ + y = 3 = deg f`, again exactly attaining the bound. In both cases the
  exact window is `0`, i.e. `d_sync = 1`. (For `(5,8)` and `y = 1` the guarantee
  `deg f − y − 1 = 0` is therefore sharp; for `(3,13)` and `y = 2` the guarantee
  `0` is sharp as well, while for `((7,6),2)` and `((11,5),2)` the guarantee is
  negative, i.e. vacuous.)
* *Gap.* For `(q,n) = (3,13)`, `f = 2 + 2x + x³`, `y = 1` the collision set is
  `{3,10}`, so the exact window is `2`, whereas the degree-type guarantee only
  gives `1`. Thus the exact criterion is strictly stronger than the guarantee in
  a case of practical interest (over `F_3`, where three-level systems are the
  natural ones), and the reason is again `e = 13 > deg f = 3`.
* *Collapse.* For `y = 2` at `(q,n) = (3,13)` every nonzero difference collides
  (`δ = 1,…,12`), i.e. the window collapses to `0`; this is the quantified
  version of "messages consume synchronisation range".

### 5.2 The subsystem completion

**Remark 5.5 (hybrid subsystem completion and gauge qudits).** Take, per
component, two cyclic codes `C_x, C_z` with `C_z^⊥ ⊆ C_x` (equivalently
`C_x^⊥ ⊆ C_z`) and marker codes `C_x ⊆ D_x`, `C_z ⊆ D_z`. The natural completion
of the construction to a subsystem code uses the gauge group

$$G = \langle iI,\ X(C_z^\perp),\ Z(C_x^\perp)\rangle,\qquad
S = G \cap G^\perp = \langle X(C_x \cap C_z^\perp),\ Z(C_z \cap C_x^\perp)\rangle,$$

with the standard hybrid subsystem parameters
`k = r_x + k_z − n = r_z + k_x − n`, `m = m_x + m_z − k_x − k_z`,
`r = r_x − k_x = r_z − k_z`, where `r_x = dim(C_x + C_z^⊥)`,
`r_z = dim(C_z + C_x^⊥)`, `m_x = k_{D_x}`, `m_z = k_{D_z}`, and the distances are
`d_x = min wt((D_x + D_z^⊥) ∖ C_z^⊥)`, `d_z = min wt((D_z + D_x^⊥) ∖ C_x^⊥)`,
`d = min(d_x,d_z)`. In the symmetric case `C_x = C_z =: C`, `D_x = D`,
`D_z = C`, we have `r_x = dim(C + C^⊥) = k_C`, so `r = 0` (the gauge sector is
trivial) and `k = 2k_C − n`: Proposition 3.1. The symmetric case is the one
verified numerically here (`tests/test_quantum.py` §2–§3: `18` ring instances,
pairwise commutation of the stabiliser generators, stabiliser rank against
`K = Σ_i(2k_{C,i} − n)`, `6` CSS instances, `0` failures); the asymmetric case is
discussed structurally only and is not tabulated. Since `q ≥ 3`, we count gauge
*qudits* (`R_g`), never gauge qubits, and in the symmetric case `R_g = 0`.
Two ring-level remarks are worth recording: the three components have independent
gauge sectors but share a single *frame*, so the synchronisation threshold depends
on the markers of the chain and not on the gauge choices; and the classical
marker capacity is redistributed between message (`M`) and gauge (`R_g`) inside
the same `3n` qudits, which is the ring-level face of the trade-off quantified in
Corollary 5.3.

**Remark 5.6 (comparison with the accounting in the source).** For orientation we
quote the source's bookkeeping $r + m + d_{\mathrm{sync,max}} = 2(k_d - k_c)$ (with a
$+1$ in the boundary case $k_d - k_c = 1$), together with the maximum
synchronisation distance $d_{\mathrm{sync,max}} = k_d - k_c$ for the base
construction. In the ring setting
the corresponding capacity is additive over the components,
`M = Σ_i (k_{D,i} − k_{C,i})`, and Theorem 5.2 says how much of it the message
markers consume in the *degree-type* bound (one unit of window per unit of `y`).
We do not re-derive the source's identity, we do not use it in any proof, and our
tables are not indexed to it; the point of the comparison is only that the exact
criterion of Theorem 5.2 can be strictly weaker than the degree-type guarantee
(Corollary 5.4), which is independent of that identity.

### 5.3 Worked example: the `[[39,3 : 9, 0, ≥3]]_3` code

Take `q = 3`, `n = 13`, and the flagship chain

$$C = \langle 1 + x^2 + x^5 + x^6\rangle = [13,7,4] \subseteq
D = \langle 2 + x + x^2 + x^3\rangle = [13,10,3],$$

for which `f = 2 + 2x + x³`, `deg f = 3`, `e = ord_x(f) = 13 = n`,
`min wt(C ∖ C^⊥) = 4` and `min wt(D ∖ C^⊥) = 3` (Table 8, row 1).

*Replicating the branch in all three components* (`C_i = C`, `D_i = D`) gives a
hybrid subsystem code with `N = 3n = 39` qudits, `K = 3(2·7 − 13) = 3` logical
qudits, `M = 3(10 − 7) = 9` classical `3`-ary symbols, `R_g = 0` gauge qudits and
reliability `D ≥ 3` (the minimum over the three components of
`min wt(D_i ∖ C_i^⊥)`);
`results/quantum_log.txt`, `data/tables.json` entry `flagship`, and
`tests/test_quantum.py` §2–§3 report the stabiliser rank, pairwise commutation and
the parameter values for this instance. The synchronisation threshold of every
component is `e_i = 13`, so `e_R = 13` and the window is `12` ring cells
(`36` cell-aligned qudit offsets), while the classical degree bound
`k_D − k_C = 3` would promise a window of `2`; the padded realization needs
`3(13+12) = 75` qudits, not `39 + 12 = 51`. With `y = 1` marker the exact window
drops to `2` (Table 10), and with `y = 2` it collapses to `0`.

*The same instance with non-replicated components.* If the three components are
chosen with different chains, the parameters become sums and minima over the
components, e.g. using the threshold triples listed in Table 3:
`(q,n) = (5,12)` with thresholds `(4,4,12)` gives `K = 2(11) + 2(11) + 2(10) − 3·12
= 28` and window `11`, and `((7,15),(3,3,15))` gives `K = 33` and window `14`. In
every one of the `10` instances of Table 3 the fused threshold equals the best
single branch (`needs_fusion = False` in the CSV), which is Theorem 4.9(3) at
work.

---

## 6. Computational verification and tables

All numbers in this paper are produced by three deterministic programs under
`src/python`; nothing is hand-entered, and no value is reported where the
program could not complete its exhaustive scan (such cells are `None` in JSON and
empty in CSV, and are read as *unknown*, never as `0`).

### 6.1 What was run

| Suite | Command | Scale | Outcome |
|---|---|---|---|
| theorem suite | `python3 tests/test_theorems.py` | $751$ checks, sections A–G | **$751$ checks, $0$ failures** ($26.9$–$27.2$ s) |
| theory suite | `python3 tests/test_theory.py` | $8794$ branch pairs, $1026$ windows, $60/60$ boundary cases, $11$ triples, $16$ maximal-window families, ring algebra | $0$ mismatches; $7883$ pairs beat the degree bound ($424.4$ s) |
| quantum suite | `python3 tests/test_quantum.py` | $18$ bridge rows, $6$ CSS instances, $13$ recovery instances, $4$ non-freeness instances | all pass ($144.2$ s) |
| table generator | `python3 src/python/experiments.py` | nine data tables, $209$ rows | $0$ assertions failed ($\approx 14$ s) |

The theorem suite verifies, section by section: (A) the reciprocity criterion and
the existence criterion against a full census; (B) that every branch threshold
divides $n$ and that the maximum threshold is $n$ whenever a branch exists;
(C) the no-gain statement on all constructed triples; (D) the classical contrast
(amplification returns when $C^\perp \subseteq C$ is dropped); (E) the degree
census including characteristic-$2$ control examples; (F) the ring-level window
composition; (G) the hybrid criterion of Theorem 5.2.

The theory suite verifies, for each of the $8794$ branch pairs: the collision
criterion (`f | x^δ − 1` iff `e | δ`), the *complete* collision set, the
window-injectivity boundary (including all $60$ cases with `a_l + a_r = e − 1`),
the lcm structure of the joint map on $11$ triples, and the `625`-pair agreement
between the native $R$-module computation and the componentwise computation.

The quantum suite verifies the model of Section 3 on the interleaved space:
commutation of the stabiliser generators, stabiliser rank against
`K = Σ_i(2k_{C,i} − n)`, the four non-freeness instances, and the window-restricted
recovery tables (injectivity on the window; genuine ambiguity exactly at the
fused threshold `e_R`).

### 6.2 The tables

| Table | Content | Rows | File |
|---|---|---|---|
| 2 | single-branch thresholds vs the degree-of-$f$ bound | $16$ | `tables/table2_single_branch.csv` |
| 3 | fusion census over $R$: $8$ usable instances $+$ $2$ structural no-gos | $10$ ($26$ CSV lines) | `tables/table3_fusion.csv` |
| 4 | closed-form maximal-window families $e_R = n$ | $74$ | `tables/table4_optimal.csv` |
| 5 | non-free $R$-cyclic codes and cardinality | $12$ | `tables/table5_nonfree.csv` |
| 6 | edge cases and exclusions (log-only, no CSV by design) | $8$ | `results/experiments_run.txt` |
| 7 | existence criterion vs exhaustive census | $58$ | `tables/table7_existence.csv` |
| 8 | flagship branches: four with $d \ge 2$ plus two characteristic-$2$ controls | $6$ | `tables/table8_flagship.csv` |
| 9 | distance-constrained fusion ($d \ge 2$) | $13$ | `tables/table9_distance_constrained.csv` |
| 10 | hybrid collision sets and the message trade-off | $12$ | `tables/table10_hybrid.csv` |
$209$ rows in total (the JSON form); the CSVs are flattened per branch and
therefore contain $217$ data lines.

**Table 2 (single-branch threshold vs degree bound).** The first four rows are
the odd-characteristic flagship branches:

| $q$ | $n$ | $C$ | $D$ | $k_C,k_D$ | $\deg f$ | $e$ | window | degree bound | $\min\mathrm{wt}(C\setminus C^\perp)$ | $\min\mathrm{wt}(D\setminus C^\perp)$ |
|---|---|---|---|---|---|---|---|---|---|---|
| $3$ | $13$ | $1+x^2+x^5+x^6$ | $2+x+x^2+x^3$ | $7,10$ | $3$ | $13$ | $12$ | $2$ | $4$ | $3$ |
| $5$ | $8$ | $1+2x+3x^2+x^3$ | $3+x$ | $5,7$ | $2$ | $8$ | $7$ | $1$ | $3$ | $2$ |
| $7$ | $6$ | $6+2x+x^2$ | $5+x$ | $4,5$ | $1$ | $6$ | $5$ | $0$ | $3$ | $2$ |
| $11$ | $5$ | $3+9x+x^2$ | $2+x$ | $3,4$ | $1$ | $5$ | $4$ | $0$ | $3$ | $2$ |

The remaining $12$ rows are *linear branches* `C = ⟨x − a⟩ ⊆ D = F_q^n` with
`a ∈ F_q^*` of order `m | n`: here `deg f = 1` (so the degree bound is `0`,
i.e. *no* misalignment is certified) while the true window is `m − 1` up to
`29` at `(q,n) = (31,30)`. These branches have `d(D∖C^⊥) = 1` (the price of the
maximal window), which is why Tables 8–9 report the distance-constrained
families separately.

**Table 3 (fusion).** All eight usable instances have `needs_fusion = False`:
the fused threshold equals the best single branch, e.g. `(3,13)` with
`(13,13,13)`, `(5,12)` with `(4,4,12)`, `(7,15)` with `(3,3,15)`, `(13,6)` with
`(3,3,6)`. The two remaining entries are the structural no-gos `(3,10)` and
`(7,10)` of Example 2.8, where no nontrivial dual-containing code exists at all.
No row of Table 3 exhibits a gain, and none can: Theorem 4.9(1)–(2).

**Table 4 (relaxation families).** `74` closed-form families with
`n | q − 1` in which three branch orders with `lcm = n` reach `e_R = n`; `29` have
relaxation factor `n/max_i m_i > 1`, the largest being `×12` at
`(q,n) = (61,60)` with orders `(3,4,5)`, followed by `×8` at `(73,72)` and `×6`
at `(43,42)` and `(61,30)`. Every row records `max_single_branch_period = n`,
which is the empirical face of Theorem 4.9(2): the relaxation concerns the
*individual* branches, not the achievable window.

**Table 7 (existence).** `58` pairs `(q,n)`; in the `22` pairs where the full
enumeration of cyclic codes is feasible, the criterion of Theorem 2.7 agrees with
the census in every case (`28` of the `58` pairs are no-gos), and in all `22`
feasible cases the maximum branch threshold equals `n` (Lemma 4.8).

**Tables 8–9 (distance-constrained).** Table 8 lists the six flagship branches:
four odd-characteristic ones with `min wt(D∖C^⊥) ≥ 2`, plus two characteristic-2
control rows (`C = ⟨1+x+x³⟩ ⊆ F_2^7` and the `[15,11,3]` code) which are included
only to show that the order-vs-degree gap is not a characteristic-$2$ phenomenon;
the controls have `d(D∖C^⊥) = 1` and are excluded from all odd-characteristic
claims. Table 9 re-runs the fusion search with `d(D∖C^⊥) ≥ 2` required: `13` `(q,n)` cases, `max single = max lcm(3) = n` in all of them, with witnesses such
as `(3,13)` at `(13,13,13)` and `d = 3`. This is the evidence for Theorem 4.9(4)
and the reason Question 4.12 is stated only for `t ≥ 4`.

### 6.3 Reproducibility

```bash
python3 src/python/experiments.py     # tables (data/tables.json, tables/*.csv, log)
python3 tests/test_theorems.py        # 751 checks
python3 tests/test_theory.py          # 8794 branch pairs
python3 tests/test_quantum.py         # interleaved model, recovery tables
```

The programs use the standard library only (Python 3.8+), are deterministic
(repeated runs produce byte-identical JSON/CSV), and print a per-section timing
line. `src/magma/` contains MAGMA transcriptions of the same checks for users who
prefer a computer-algebra system; **they were not executed here** (no MAGMA
interpreter was available) and no number in this paper comes from them.

---

## 7. Discussion

### 7.1 What the ring buys

1. **A uniform algebra with a coordinated frame.** One ring word, one frame, three
   classical components; the ring structure makes the "same shift for all
   components" condition a structural statement rather than a constraint imposed
   by hand.
2. **Additive hybrid capacity.** `M = Σ_i (k_{D,i} − k_{C,i})` classical symbols
   and `K = Σ_i (2k_{C,i} − n)` logical qudits; both are sums over components, so
   one may trade rate for capacity component by component.
3. **Legitimate non-free parameter choices.** By Proposition 2.3 the cardinality
   of an `R`-cyclic code is `q^{Σ k_i}` whether or not the code is free; Table 5
   lists twelve non-free instances (e.g. `k = (4,3,4)` with `|C| = 5^{11}`), and
   no `R`-rank is ever assumed.
4. **High-rate maximal-window codes.** The flagship `[[39,3 : 9, 0, ≥3]]_3`
   combines rate `3/39` quantum plus `9` classical symbols with a `12`-cell
   window, three times the degree bound; the linear-branch family of Table 2
   reaches window `m − 1` at `deg f = 1`.

### 7.2 What the ring provably does not buy

The window. Every branch threshold divides `n` (Lemma 4.7), a period-`n` branch
exists as soon as any branch does (Lemma 4.8), and therefore the fused threshold
never exceeds the best single component (Theorem 4.9(3)). The maximal window
`n − 1` is attainable by a single component, and no arrangement of three
components — and, by the same argument, of any finite number of them — does
better. What fusion buys is a relaxation of the individual branch requirements
(Table 4), which is a statement about *implementation difficulty*, not about
capability, and we label it as such throughout.

The mechanism is worth restating because it is sharp: dropping the quantum
condition `C^⊥ ⊆ C` restores genuine amplification (Corollary 4.10). Thus the
no-gain phenomenon is caused *by the quantum condition itself* — more precisely
by the interplay of that condition with the divisibility `e | n` and the
existence of a period-`n` branch.

### 7.3 Declared limitations

* **Cell-aligned offsets only.** In Model A the correctable offsets are multiples
  of `3` in qudit units (Section 3.1, `quantum_model_decision.md`). Non-cell
  offsets are not covered by the frame machinery and are not claimed.
* **Prime `q`.** The implementation uses prime fields; prime-power alphabets are
  not covered (the module `src/python/finite_field.py` implements `GF(q)` for
  prime `q` only).
* **`q = 2` excluded.** `R` is not reduced over `F_2` and the idempotents do not
  exist; characteristic-2 rows appear only as controls.
* **`gcd(n,q) = 1`.** No repeated-root case is treated.
* **Unknown distances.** Where the weight-class scan exceeded its budget the
  tables say *unknown* (`None`/empty); no distance is estimated.
* **Asymmetric subsystem case.** Only the structural formulas of Remark 5.5 are
  given; the asymmetric gauge sector is not tabulated.
* **No priority claimed** for the CRT decomposition, per-component CSS
  constructions, QSCs over finite rings, the order criterion, the maximum
  synchronisation distance `k_D − k_C`, or the hybrid/subsystem framework
  (Section 7.4).

### 7.4 Prior art, and the positioning of this work

The recipe "decompose a ring by idempotents, build a code per component, and take
a componentwise CSS construction" is standard and appears in the literature on
quantum synchronizable and subsystem codes over rings; in particular the ring
`R = F_q + vF_q` with `v² = v` has been used for QSCs, and the ring
`F_q[u]/(u^{k+1} − u)` occurs in the coding-theory literature on cyclic and skew
cyclic codes — the closest precedent to our coefficient ring. Likewise, the order
criterion `e = ord_x(f)` in characteristic 2 and the accounting of the maximum
synchronisation distance are due to earlier work, and the hybrid/subsystem
framework is the subject of the paper that motivated this study. What is new here
is the *sharp* odd-characteristic analysis (exact collision set with the sign
convention fixed), the *existence criterion* `−1 ∉ ⟨q⟩` as the organising
condition, the *no-gain theorem* with its classical contrast, and the exact
hybrid criterion with the two-sided comparison of Corollary 5.4. The manuscript
states this positioning in the introduction as well, and no theorem of this paper
depends on a novelty claim.

### 7.5 Open problems

1. **Question 4.12.** For which `t` does the no-gain statement survive the
   distance constraint `d(D∖C^⊥) ≥ t`? We verified `t = 2` in all tested cases
   and exhibited witnesses with `d = 3`; the search for `t ≥ 4` exceeds our
   budget.
2. **Non-cell offsets.** Is there a `q`-ary model in which a shift by one or two
   qudit positions is also correctable, and what window does the ring structure
   then allow? (Model B in `quantum_model_decision.md` is one candidate; it has a
   different local error model.)
3. **Prime-power alphabets and other rings.** Does the no-gain phenomenon persist
   over `F_{q^r}` and over rings with more than three components (e.g.
   `v^{k+1} = v`), where the CRT gives `k + 1` fields?
4. **Non-free codes.** Do non-free `R`-cyclic codes ever improve quantum
   parameters (rate, distance, or window) over their free counterparts? No
   example is exhibited here, and no claim is made; the question is open.
5. **Optimality within a window.** Given `a_l + a_r` and a rate requirement, what
   is the maximal `D` over all multi-component constructions? Our tables give
   examples but no general optimiser.

---

## Appendix A. Odd-characteristic derivation details

**A.1 Sign convention.** In characteristic 2 the two polynomials `x^δ b − b'` and
`x^δ b + b'` coincide, so the sign is invisible. In odd characteristic the shift
of a word by `δ` multiplies its polynomial by `x^δ`, hence the collision condition
is `f | x^δ b − b'` (not `+`), and the single-marker criterion is
`f | q₁(x^δ − 1)`. Replacing `−` by `+` changes the criterion to
`f | q₁(x^δ + 1)`, whose solutions are the `δ` with `x^δ ≡ −1 (mod f)`; these
differ from the multiples of `e` (they exist only if `−1 ∈ ⟨x⟩` in the quotient
`F_q[x]/(f)`, i.e. only if `e` is even). The two conditions coincide exactly when
characteristic 2 holds. All computations in this paper use the correct odd-
characteristic form; `tests/test_theorems.py` §G checks the small-case identity
`#collisions(+) = #collisions(−)` — recorded as a warning that the two criteria
differ in general.

**A.2 Why `deg f ≤ e`.** `f | x^e − 1` because `e = ord_x(f)`; if `f` is
nonconstant then `x^e − 1 ≠ 0` in the quotient (as `x^e ≡ 1` is a nontrivial
relation of degree `e < n` only after reduction, and `f ≠ 1`), so
`deg f ≤ deg(x^e − 1) = e`. This is the only place where an inequality between
`e` and `deg f` is used, and it is what makes Theorem 4.3's sufficiency argument
work without any degree-of-ideal estimate.

**A.3 The affine marker family is shift-free (Lemma 5.1) and the degree count.**
With `M = 1 + span{x,…,x^y}`, `b(0) = 1` for all `b ∈ M`, so `x^δ b` has constant
term `0` for `δ ≥ 1`; hence `x^δ b ≠ b'` and the difference in (5.1) is nonzero,
which is what the degree count needs. For `δ ≤ 0` the roles of `b` and `b'` are
exchanged and the same conclusion holds. The degree count then gives
`|δ| + y ≥ deg f`.

**A.4 Boundary witnesses.** The equality `|δ| + y = deg f` is attained in
Table 10 for `((q,n),y) = ((5,8),1)` and `((3,13),2)` at `δ = 1`, both verified by
exhibiting the colliding pair from the criterion (see
`results/experiments_run.txt`, Table 10 section).

## Appendix B. The interleaved realisation, concretely

For `q = 3`, `n = 13`, the flagship chain has `K_1 = 2·7 − 13 = 1` logical qudit
per component, `M_1 = 3` message symbols, `N_1 = 13` qudits; replicated three
times: `N = 39`, `K = 3`, `M = 9`. The stabiliser group of the interleaved code is
generated by the `X`- and `Z`-operators attached to the `3(13 − 7) = 18`
coordinates of `ι(C^⊥)` in each of the `X` and `Z` sectors (36 generators of
order `q`, rank `36`), so `K = (39 − 36)/1 = 3` in agreement with
`Σ_i (2k_{C,i} − n)`; the logical `X`-operators are the interleavings of
`D ∖ C^⊥` (weight `3` minimum, since `min wt(D∖C^⊥) = 3`) and the logical
`Z`-operators those of `C ∖ C^⊥` (weight `4` minimum), which is why the reported
reliability is `d_X = 3`, `d_Z = 4`, `D = 3`. The frame acts on the 39 positions
by rotation in steps of `3`; the window is `[−a_r,a_l]` with `a_l + a_r ≤ 12` and
the recovery table is the map `α ↦ Σ(α)` for `α ∈ [−12,12]`, which the quantum
suite verifies to be injective, with failure exactly at `α ≡ α' (mod 13)`.

## Appendix C. Files and commands

| Path | Content |
|---|---|
| `src/python/finite_field.py`, `ring_r.py` | `F_q`, `R`, idempotents, CRT, duality |
| `src/python/cyclic_codes.py` | cyclic codes, `R`-cyclic codes, divisors, duality |
| `src/python/synchronization.py` | syndrome maps, empirical periods, windows, joint maps |
| `src/python/quantum_css.py` | Pauli groups, CSS codes, stabiliser rank, distances |
| `src/python/experiments.py` | the nine tables of Section 6.2 |
| `tests/test_theorems.py` | 751 checks (sections A–G) |
| `tests/test_theory.py` | 8794 branch pairs, windows, triples, families, ring algebra |
| `tests/test_quantum.py` | interleaved model, CSS parameters, recovery tables |
| `src/magma/ring_qsc.m`, `verify_tables.m` | MAGMA transcription (unexecuted here) |
| `data/tables.json`, `tables/*.csv` | the tables in machine-readable form |
| `results/*.txt`, `results/*.json` | logs and machine-checkable summaries |

Run order is the one given in Section 6.3; a complete run takes about
`14 + 27 + 144 + 424` seconds on the machine used here.

---

## Verification index

| Claim | Verified by |
|---|---|
| Prop. 2.1 (ring, idempotents) | `tests/test_theory.py` §A; Table 6 |
| Prop. 2.3 (components, cardinality, freeness) | `tests/test_theory.py` §A; Table 5; `tests/test_quantum.py` §5 |
| Lemma 2.5, Theorem 2.7 (duality, existence) | `tests/test_theorems.py` §A; Table 7 (58 pairs) |
| Lemma 4.1, Theorem 4.2 (criterion, sharp window) | `tests/test_theory.py` §B–§C (8794 pairs, 1026 windows, 60/60 boundary); `tests/test_theorems.py` §F |
| Theorem 4.3 (degree bound) | `tests/test_theory.py` §C (7883/8794); Table 2 |
| Theorem 4.5 (fused threshold) | `tests/test_theory.py` §D; `tests/test_quantum.py` §4 |
| Lemma 4.7, 4.8, Theorem 4.9 (no gain) | `tests/test_theorems.py` §B–§C; Table 3, Table 9 |
| Corollary 4.10 (classical contrast) | `tests/test_theorems.py` §D; `data/examples.json` |
| Lemma 5.1, Theorem 5.2, Corollaries 5.3–5.4 | `tests/test_theorems.py` §G; Table 10 |
| Prop. 3.1, Remark 5.5 (parameters, gauge) | `tests/test_quantum.py` §2–§3 (18 ring instances, 6 CSS instances) |
| Q. 4.12 (`t = 2` verified, `t = 3` witness) | Table 9 (13 cases) |

---

## References

Every entry below is verified in `references_verified.csv` (authors, title, venue,
volume, pages or article number, year, DOI and the URL used for verification);
entries whose metadata could not be verified to that standard were removed rather
than guessed, and no reference is cited that we did not read or verify.

**[F13]** Y. Fujiwara, *Block synchronization for quantum information*,
Physical Review A **87** (2013), 022344. DOI 10.1103/PhysRevA.87.022344.
(Origin of the order criterion in characteristic 2.)

**[XYF14]** Y. Xie, J. Yuan and Y. Fujiwara, *Quantum synchronizable codes from
quadratic residue codes and their supercodes*, arXiv:1403.6192 [cs.IT] (2014).
DOI 10.48550/arXiv.1403.6192. (Proof of the order criterion, Thm. 3.1.)

**[TN24]** T. Tansuwannont and A. Nemec, *Synchronizable hybrid subsystem
codes*, IEEE Transactions on Quantum Engineering **7** (2026);
DOI 10.1109/TQE.2026.3673092; arXiv:2409.11312. (Source paper of this study:
framework, hybrid/subsystem construction, accounting, degree-type conditions.)

**[LL21]** H. Liu and X. Liu, *Quantum synchronizable codes from finite rings*,
Quantum Information Processing **20**(3) (2021), 125.
DOI 10.1007/s11128-021-03058-4. (Prior art: QSCs over finite rings.)

**[DL22]** Y. Dai and X. Liu, *QSCs from the Euclidean sums of cyclic codes over
finite rings*, Quantum Information Processing **21** (2022), 295.
DOI 10.1007/s11128-022-03625-3. (Prior art: three QSC constructions by Euclidean
sums over rings.)

**[LHL24]** J. Liu, P. Hu and X. Liu, *Quantum synchronizable codes from the ring
`F_q + vF_q`*, Quantum Information Processing **23**(2) (2024), 44.
(DOI not independently confirmed, therefore omitted.) (Closest prior art over a
product ring with `v² = v`.)

**[DML23]** C. Du, Z. Ma and Y. Liu, *Quantum synchronizable codes from
repeated-root quasi-cyclic codes*, Computational and Applied Mathematics **42**
(2023), 161. DOI 10.1007/s40314-023-02298-7.

**[DM21]** H. Q. Dinh, T. Bag, A. K. Upadhyay, R. Bandi and W. Tansuchat,
*A class of skew cyclic codes and application in quantum codes construction*,
Discrete Mathematics **344**(2) (2021), 112189.
DOI 10.1016/j.disc.2020.112189. (Prior art: cyclic/skew-cyclic codes over rings
with applications to quantum codes.)

*Background records, verified but not relied upon* (listed in
`references_verified.csv`): Y. Fujiwara, V. D. Tonchev and T. W. H. Wong,
Phys. Rev. A **88** (2013), 012318; Y. Fujiwara and P. Vandendriessche,
IEEE Trans. Inform. Theory **60** (2014), 7345–7354; L. Li, S. Zhu and L. Liu,
IEEE Commun. Lett. **23**(1) (2019), 12–15; T. Brun, I. Devetak and M.-H. Hsieh,
Science **314** (2006), 436–439; H. Li and X. Liu, Quantum Inf. Process. **24**
(2025), 49.
