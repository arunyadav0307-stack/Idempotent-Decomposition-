#!/usr/bin/env python3
"""md2tex.py -- deterministic converter from FINAL_MANUSCRIPT.md to FINAL_MANUSCRIPT.tex.

Usage:  python3 src/tools/md2tex.py [input.md] [output.tex]

Design notes
------------
* The manuscript is written in Markdown whose mathematics is already LaTeX
  (``$...$``), so a faithful conversion is possible without a full Markdown
  engine.
* Inline code spans are rendered as mathematics when they look like expressions
  (they contain a math signal such as ``_``, ``^`` or ``=``), otherwise as
  ``\\texttt{...}``.  Paths and commands get ``\\allowbreak`` so that long
  teletype strings can wrap.
* Section numbers, theorem numbers and cross-references are preserved: manual
  numbers in the headings are stripped and LaTeX numbering is used, which
  reproduces the Markdown numbering exactly (Sections 1-7, Appendices A-C).
* The output is ASCII-only and the reference list is self-contained, so a plain
  ``pdflatex`` run with a base TeX Live installation is enough.
"""

import re
import sys

# --------------------------------------------------------------------------
# unicode -> LaTeX tables (single backslashes, raw strings)
# --------------------------------------------------------------------------
# used in running text (delimiters included)
UNI = [
    ("⊆", r"$\subseteq$"), ("⊇", r"$\supseteq$"), ("⊂", r"$\subset$"),
    ("⊊", r"$\subsetneq$"), ("∈", r"$\in$"), ("∉", r"$\notin$"),
    ("≥", r"$\ge$"), ("≤", r"$\le$"), ("×", r"$\times$"),
    ("∤", r"$\nmid$"), ("∅", r"$\emptyset$"), ("∖", r"$\setminus$"),
    ("≡", r"$\equiv$"), ("∏", r"$\prod$"), ("∩", r"$\cap$"),
    ("∀", r"$\forall$"), ("⇒", r"$\Rightarrow$"), ("⟹", r"$\Longrightarrow$"),
    ("⇐", r"$\Longleftarrow$"), ("→", r"$\to$"), ("←", r"$\leftarrow$"),
    ("≈", r"$\approx$"), ("∼", r"$\sim$"), ("≅", r"$\cong$"),
    ("↦", r"$\mapsto$"), ("≠", r"$\ne$"), ("±", r"$\pm$"),
    ("·", r"$\cdot$"), ("∞", r"$\infty$"), ("⊕", r"$\oplus$"),
    ("⊗", r"$\otimes$"), ("⊥", r"$\perp$"), ("⟨", r"$\langle$"),
    ("⟩", r"$\rangle$"), ("α", r"$\alpha$"), ("β", r"$\beta$"),
    ("δ", r"$\delta$"), ("ε", r"$\varepsilon$"), ("ζ", r"$\zeta$"),
    ("ι", r"$\iota$"), ("µ", r"$\mu$"), ("ω", r"$\omega$"),
    ("Σ", r"$\Sigma$"), ("Φ", r"$\Phi$"), ("′", r"$'$"),
    ("₀", r"$_0$"), ("₁", r"$_1$"), ("₂", r"$_2$"), ("₃", r"$_3$"),
    ("²", r"$^2$"), ("³", r"$^3$"), ("⁴", r"$^4$"), ("⁵", r"$^5$"),
    ("⁶", r"$^6$"), ("☐", r"$\square$"), ("∎", r"$\square$"),
    ("…", "\u2026"), ("§", "\u00a7"), ("—", "---"), ("–", "--"),
    ("‘", "`"), ("’", "'"), ("“", "``"), ("”", "''"),
    ("F̄", r"$\overline{F}$"),
]

# used inside existing math spans (no delimiters)
MATHONLY = [
    ("−", "-"), ("⊆", r"\subseteq"), ("⊇", r"\supseteq"),
    ("⊂", r"\subset"), ("⊊", r"\subsetneq"), ("∈", r"\in"),
    ("∉", r"\notin"), ("≥", r"\ge"), ("≤", r"\le"), ("×", r"\times"),
    ("∤", r"\nmid"), ("∅", r"\emptyset"), ("∖", r"\setminus"),
    ("≡", r"\equiv"), ("∏", r"\prod"), ("∩", r"\cap"),
    ("∀", r"\forall"), ("⇒", r"\Rightarrow"),
    ("⟹", r"\Longrightarrow"), ("⇐", r"\Longleftarrow"),
    ("→", r"\to"), ("←", r"\leftarrow"), ("≈", r"\approx"),
    ("∼", r"\sim"), ("≅", r"\cong"), ("↦", r"\mapsto"),
    ("≠", r"\ne"), ("±", r"\pm"), ("·", r"\cdot"),
    ("∞", r"\infty"), ("⊕", r"\oplus"), ("⊗", r"\otimes"),
    ("⊥", r"\perp"), ("⟨", r"\langle"), ("⟩", r"\rangle"),
    ("α", r"\alpha"), ("β", r"\beta"), ("δ", r"\delta"),
    ("ε", r"\varepsilon"), ("ζ", r"\zeta"), ("ι", r"\iota"),
    ("µ", r"\mu"), ("ω", r"\omega"), ("Σ", r"\Sigma"),
    ("Φ", r"\Phi"), ("′", r"^{\prime}"), ("∎", r"\square"),
    ("☐", r"\square"), ("…", r"\dots "), ("F̄", r"\overline{F}"),
    ("₀", "_0"), ("₁", "_1"), ("₂", "_2"), ("₃", "_3"),
    ("²", "^2"), ("³", "^3"), ("⁴", "^4"), ("⁵", "^5"), ("⁶", "^6"),
]

SPECIAL = {'&': r"\&", '%': r'\%', '#': r'\#', '_': r'\_', '{': r'\{',
           '}': r'\}', '$': r'\$', '~': r'\textasciitilde{}',
           '^': r'\textasciicircum{}'}

MATH_HINT = set("_^=≤≥⊆⊂⊇∈∉+×·⋅∖[]{}<>")

SUBDIG = "₀₁₂₃₄₅₆₇₈₉"
SUPDIG = "⁰¹²³⁴⁵⁶⁷⁸⁹"


def esc(t):
    return ''.join(SPECIAL.get(c, c) for c in t)


def collapse_digits(txt):
    """Merge runs of unicode sub/superscript digits into _{..}/^{..}."""
    def sub(m):
        return "_{" + "".join(str(SUBDIG.index(c)) for c in m.group(0)) + "}"

    def sup(m):
        return "^{" + "".join(str(SUPDIG.index(c)) for c in m.group(0)) + "}"

    txt = re.sub("[%s]+" % SUBDIG, sub, txt)
    txt = re.sub("[%s]+" % SUPDIG, sup, txt)
    return txt


def guard_commands(txt):
    """Insert {} after one of our control words when a letter follows it.

    Longest match wins and there is no fallback to a shorter command, so a
    prefix relationship (\subset vs \subseteq, \in vs \infty) is preserved.
    """
    cmds = sorted({c for _, c in MATHONLY if re.fullmatch(r'\\[A-Za-z]+', c)},
                  key=len, reverse=True)
    out = []
    i = 0
    while i < len(txt):
        if txt[i] == '\\':
            for c in cmds:
                if txt.startswith(c, i):
                    j = i + len(c)
                    out.append(c + '{}' if (j < len(txt) and txt[j].isalpha()) else c)
                    i = j
                    break
            else:
                out.append(txt[i])
                i += 1
        else:
            out.append(txt[i])
            i += 1
    return ''.join(out)


def map_math(inner):
    """Apply the math-context unicode mapping to the body of a math span."""
    t = inner
    for a, b in MATHONLY:
        t = t.replace(a, b)
    return guard_commands(t)


def mathify(content):
    """Return a math rendering of a code span, or None if it is ordinary text."""
    txt = collapse_digits(content)
    for a, b in MATHONLY:
        txt = txt.replace(a, b)
    if re.fullmatch(r'[A-Za-z]', txt):
        return "$" + txt + "$"
    ident = re.fullmatch(r'([A-Za-z0-9]+)((?:_[A-Za-z0-9]+)+)', content)
    if ident:
        parts = content.split("_")
        body, rest = parts[0], "_".join(parts[1:])
        if len(rest) > 1:
            body += r"_{\text{" + rest.replace("_", r"\_") + "}}"
        else:
            body += "_" + rest
        return "$" + body + "$"
    has_long_word = any(len(w) >= 4 and w.isalpha()
                        for w in re.split(r"[^A-Za-z]+", txt))
    if not (any(c in MATH_HINT for c in txt) and not has_long_word
            and not content.startswith("python3")):
        return None
    out = txt.replace('#', r'\#').replace('%', r'\%').replace('&', r'\&')
    return "$" + guard_commands(out) + "$"


def texttt(content):
    """Render a code span: mathematics if it looks like math, else teletype."""
    collapsed = collapse_digits(content)
    mapped = collapsed
    for a, b in MATHONLY:
        mapped = mapped.replace(a, b)
    if "\\" in mapped:
        return "$" + guard_commands(mapped) + "$"
    base = esc(collapsed)
    if ("/" in base) or ("." in base):          # paths/commands: allow breaks
        base = base.replace("/", r"/\allowbreak ").replace(".", r".\allowbreak ")
        base = base.replace(" ", r"\allowbreak ")
        base = re.sub(r'(\\allowbreak )+', r'\\allowbreak ', base)
    return r"\texttt{" + base + "}"


def inline(t):
    t = t.replace("\u2212", "-")
    math_ph, code_ph = {}, {}

    def stash_math(m):
        k = "\x01%d\x02" % len(math_ph)
        math_ph[k] = m.group(0)
        return k

    def stash_code(m):
        k = "\x05%d\x06" % len(code_ph)
        code_ph[k] = m.group(1)
        return k

    t = re.sub(r'\$\$[^$]*\$\$|\$[^$]*\$', stash_math, t)
    t = re.sub(r'`([^`]*)`', stash_code, t)
    for a, b in UNI:
        t = t.replace(a, b)
    t = re.sub(r'\$[^$]*\$', stash_math, t)      # protect freshly inserted math
    t = esc(t)
    t = t.replace("\u00a7", r"\S{}").replace("\u2026", r"\dots{}")
    t = re.sub(r'\*\*(.+?)\*\*', lambda m: r'\textbf{' + m.group(1) + '}',
               t, flags=re.S)
    t = re.sub(r'(?<!\*)\*([^*\n]+)\*(?!\*)',
               lambda m: r'\emph{' + m.group(1) + '}', t)
    for k, v in math_ph.items():
        if v.startswith('$$') and v.endswith('$$') and len(v) > 4:
            body = map_math(v[2:-2])
            body = re.sub(r'\\tag\{([^}]*)\}', r'\\qquad(\1)', body)
            v = '$$' + body + '$$'
        elif v.startswith('$') and v.endswith('$') and len(v) > 2:
            v = '$' + map_math(v[1:-1]) + '$'
        t = t.replace(k, v)
    for k, v in code_ph.items():
        m = mathify(v)
        t = t.replace(k, m if m else texttt(v))
    return t


def convert_table(rows):
    """LaTeX tabular: font size by column count, p-columns for long cells."""
    cells = [[c.strip() for c in r.strip().strip('|').split('|')] for r in rows]
    cells = [c for c in cells
             if not all(re.fullmatch(r':?-{2,}:?', x or '-') for x in c)]
    ncol = max(len(c) for c in cells)
    for c in cells:
        c += [''] * (ncol - len(c))
    size = 'small' if ncol <= 4 else ('footnotesize' if ncol <= 7 else 'scriptsize')
    colmax = [max(len(c[j]) for c in cells) for j in range(ncol)]
    if ncol <= 4 and max(colmax) <= 16:
        spec = 'l' * ncol                       # short, narrow table: natural width
    else:                                       # proportional widths, fits \textwidth
        weights = [max(m, 10) for m in colmax]
        total = 0.99 if ncol >= 9 else 0.97
        spec = ''.join('>{\\raggedright\\arraybackslash}p{%.4f\\textwidth}'
                       % (total * w / sum(weights)) for w in weights)
    sep = 2 if ncol >= 9 else (3 if ncol >= 6 else 4)
    out = [r'\begin{center}\setlength{\tabcolsep}{%dpt}' % sep,
           r'{\%s' % size,
           r'\begin{tabular}{%s}' % spec, r'\hline']
    for j, row in enumerate(cells):
        out.append(' & '.join(inline(c) for c in row) + r' \\')
        if j == 0:
            out.append(r'\hline')
    out += [r'\hline', r'\end{tabular}}', r'\end{center}']
    return out


PREAMBLE = r"""\documentclass[11pt,reqno]{amsart}
\usepackage{lmodern}
\usepackage{amsmath,amssymb,amsthm}
\usepackage{array}
\usepackage{microtype}
\usepackage[margin=1in]{geometry}
\usepackage[hidelinks]{hyperref}
\tolerance=2000
\emergencystretch=3em
\hbadness=10000
\vbadness=10000
% Statements are printed in run-in style with explicit numbers (Theorem 4.2, ...),
% matching the Markdown source one-for-one, so that the two representations cannot
% drift apart; hence no \newtheorem declarations are used.
\newcommand{\F}{\mathbb{F}}
\newcommand{\wt}{\operatorname{wt}}
\newcommand{\ord}{\operatorname{ord}}
\newcommand{\code}[1]{\mathcal{#1}}
\newcommand{\Ob}{\mathcal{O}}
\newcommand{\Z}{\mathbb{Z}}
"""

TITLE_THANKS = (r"\thanks{Produced by an automated research pipeline; no author "
                r"identity is asserted. The framework studied here is that of "
                r"Y.~Fujiwara, V.~D.~Tonchev, T.~W.~H.~Wong and of "
                r"T.~Tansuwannont, A.~Nemec; the odd-characteristic results are "
                r"independently re-derived. See Section~7.4 for positioning and "
                r"non-claims.}")


def main(src_path, out_path):
    src = open(src_path).read()
    lines = src.split('\n')
    title = "Manuscript"
    for l in lines:
        if l.startswith('# '):
            title = l[2:].strip()
            break
    m = re.search(r'\*\*Abstract\.\*\*\s*(.+?)\n\n', src, re.S)
    abstract = m.group(1).replace('\n', ' ') if m else ""
    head = (PREAMBLE
            + "\\title[Idempotent decomposition and synchronizable hybrid "
              "subsystem quantum codes]{" + inline(title) + "}\n"
            + "\\subjclass[2020]{81P73, 94B15, 11T71}\n"
            + "\\keywords{quantum synchronizable codes; hybrid subsystem codes; "
              "finite rings;\nidempotent decomposition; cyclic codes; block "
              "misalignment}\n"
            + "\\date{2026-09-29}\n" + TITLE_THANKS + "\n"
            + "\\begin{document}\n\\begin{abstract}\n"
            + inline(abstract) + "\n\\end{abstract}\n\\maketitle\n")
    body = src[m.end():] if m else src
    L = body.split('\n')
    out = []
    i = 0
    appendix_started = [False]
    while i < len(L):
        l = L[i]
        s = l.strip()
        if s.startswith('```'):
            i += 1
            buf = []
            while i < len(L) and not L[i].strip().startswith('```'):
                buf.append(L[i])
                i += 1
            i += 1
            out += ['\\begin{verbatim}'] + buf + ['\\end{verbatim}']
            continue
        if s.startswith('|'):
            rows = []
            while i < len(L) and L[i].strip().startswith('|'):
                rows.append(L[i])
                i += 1
            out += convert_table(rows)
            out.append('')
            continue
        if re.match(r'^#{1,4}\s', s):
            lvl = len(s.split(' ')[0])
            txt = s[lvl:].strip()
            if lvl == 2:
                m_app = re.match(r'^Appendix\s+([A-Z])\.?\s*(.*)$', txt)
                m_num = re.match(r'^(\d+(?:\.\d+)*)\.?\s+(.*)$', txt)
                if m_app:
                    if not appendix_started[0]:
                        out.append('\\appendix')
                        appendix_started[0] = True
                    cmd, txt = 'section', m_app.group(2)
                elif m_num:
                    cmd, txt = 'section', m_num.group(2)
                elif txt in ('Verification index', 'References'):
                    cmd = 'section*'
                else:
                    cmd = 'section'
            elif lvl == 3:
                m_num = re.match(r'^(\d+(?:\.\d+)*)\.?\s+(.*)$', txt)
                cmd, txt = 'subsection', (m_num.group(2) if m_num else txt)
            else:
                cmd = 'section*'
            out.append('\\%s{%s}' % (cmd, inline(txt)))
            i += 1
            continue
        if s.startswith('> '):
            buf = []
            while i < len(L) and L[i].strip().startswith('>'):
                buf.append(L[i].strip()[1:].strip())
                i += 1
            out += ['\\begin{quote}', inline(' '.join(buf)), '\\end{quote}']
            continue
        if s == '---':
            out.append('\\medskip')
            i += 1
            continue
        if re.match(r'^\s*([-*]|\d+\.)\s', l):
            marker = (r'^\s*[-*]\s' if re.match(r'^\s*[-*]\s', l)
                      else r'^\s*\d+\.\s')
            items = []
            while i < len(L):
                if re.match(marker, L[i]):
                    items.append(re.sub(marker, '', L[i], count=1))
                    i += 1
                elif (L[i].strip() == ''
                      or re.match(r'^(\s*[-*]\s|\s*\d+\.\s|\||#{1,4}\s|> |```|---)',
                                  L[i])):
                    break
                else:
                    if not items:
                        break
                    items[-1] = items[-1].rstrip() + ' ' + L[i].strip()
                    i += 1
            env = 'itemize' if marker == r'^\s*[-*]\s' else 'enumerate'
            out.append('\\begin{%s}' % env)
            for b in items:
                out.append('\\item ' + inline(b))
            out.append('\\end{%s}' % env)
            continue
        if s == '':
            out.append('')
            i += 1
            continue
        buf = [l]
        i += 1
        while (i < len(L) and L[i].strip() != ''
               and not re.match(r'^(\s*[-*]\s|\s*\d+\.\s|\||#{1,4}\s|> |```|---)',
                                L[i])):
            buf.append(L[i].strip())
            i += 1
        out.append(inline(' '.join(x.strip() for x in buf)))
    tex = (head + "\n".join(out)
           + "\n% The reference list above is self-contained (no BibTeX run "
             "needed).\n% To use the bundled database instead, replace it by:\n"
             "%   \\bibliographystyle{plain}\n%   \\bibliography{references}\n"
             "\\end{document}\n")
    open(out_path, 'w').write(tex)
    print("wrote %s (%d chars)" % (out_path, len(tex)))


if __name__ == '__main__':
    a = sys.argv[1:] or ['/home/user/FINAL_MANUSCRIPT.md',
                         '/home/user/FINAL_MANUSCRIPT.tex']
    main(a[0], a[1] if len(a) > 1 else a[0].replace('.md', '.tex'))
