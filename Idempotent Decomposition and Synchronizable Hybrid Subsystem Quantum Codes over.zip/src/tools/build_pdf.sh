#!/bin/sh
# build_pdf.sh -- compile FINAL_MANUSCRIPT.tex exactly as done in this project.
#
# Requirements: a TeX Live installation providing pdflatex, lmodern, amsmath,
# amssymb, amsthm, array, microtype, geometry, hyperref.  No BibTeX run and no
# figure files are needed: the reference list is self-contained and the source
# has no \includegraphics.
#
# Usage:  sh src/tools/build_pdf.sh [output-directory]
set -e
cd "$(dirname "$0")/../.."
OUT="${1:-build}"
mkdir -p "$OUT"
cp FINAL_MANUSCRIPT.tex "$OUT/"
cd "$OUT"
pdflatex -interaction=nonstopmode -halt-on-error FINAL_MANUSCRIPT.tex > pass1.log 2>&1
pdflatex -interaction=nonstopmode FINAL_MANUSCRIPT.tex > pass2.log 2>&1
cp FINAL_MANUSCRIPT.pdf ..
echo "compiled: FINAL_MANUSCRIPT.pdf ($(pdfinfo FINAL_MANUSCRIPT.pdf 2>/dev/null | awk '/^Pages/{print $2}') pages)"
