# MAGMA sources (provided, NOT executed)

The working environment has no MAGMA interpreter (`which magma` is empty, and no
CAS is installed: no MAGMA, GAP, Sage, Singular or Mathematica). These `.m` files
are therefore **unexecuted**; they are included so that the algebraic core of the
paper can be re-run independently on any machine with MAGMA.

Every computation in `src/magma/` has a Python counterpart in `src/python/` that
*was* executed, and the numbers quoted in the manuscript come from the Python
runs (`results/*.txt`, `tables/*.csv`). If a MAGMA run disagrees with the Python
run, the disagreement must be resolved before trusting either; that is the point
of keeping the second implementation.

Files:

| File | Content |
|---|---|
| `ring_qsc.m` | ring $R=\mathbb{F}_q[v]/(v^3-v)$, idempotents, CRT check, cyclic codes over $\mathbb{F}_q$, duals, collision threshold $e=\operatorname{ord}_x(f)$, fusion lcm, existence criterion, hybrid collision test |
| `verify_tables.m` | reproduces the flagship rows of Table 8 and the fusion rows of Table 3 by calling `ring_qsc.m` |

Usage (on a machine with MAGMA):

```
magma -b ring_qsc.m
magma -b verify_tables.m
```

Expected output for the flagship branch `q=3, n=13`,
`p_C = 1 + x^2 + x^5 + x^6`, `p_D = 2 + x + x^2 + x^3`: `deg f = 3`, `e = 13`,
window `12`, and `min wt(D \ C^perp) = 3` — matching `tables/table8_flagship.csv`.
