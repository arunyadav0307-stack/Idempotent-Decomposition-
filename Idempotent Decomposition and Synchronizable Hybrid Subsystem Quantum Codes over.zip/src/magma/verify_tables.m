/* verify_tables.m -- UNEXECUTED (no MAGMA available); mirrors the Python
   results in tables/table3_fusion.csv and tables/table8_flagship.csv. */

load "ring_qsc.m";

F<v> := GF(3);
P<x> := PolynomialRing(F);

/* Table 8, row 1: q = 3, n = 13 */
q := 3; n := 13;
pC := 1 + x^2 + x^5 + x^6;
pD := 2 + x + x^2 + x^3;
print "flagship (3,13):", WindowData(q, n, pC, pD);           /* deg f, e, window */
print "expected: <3, 13, 12, 2, [13]>";

/* Table 10, rows for (3,13): hybrid collisions for y = 0, 1, 2 */
for y in [0, 1, 2] do
    cols, bound := HybridCollisions(q, n, pC, pD, y);
    print "hybrid (3,13), y =", y, "collisions at", cols, "guarantee bound", bound;
end for;
print "expected: y=0 -> [], y=1 -> [3,10], y=2 -> [1..12]";

/* Table 3: fusion census at (q,n) = (3,8) and the structural no-go (3,10) */
for qq in [3] do
    for nn in [8, 10] do
        printf "branch orders at (%o,%o): %o  (criterion says branches exist: %o)\n",
               qq, nn, AllBranchOrders(qq, nn), ExistenceCriterion(qq, nn);
    end for;
end for;
print "expected: (3,8) orders = {2,4,8} with max = n = 8; (3,10) empty set (no-go)";

/* Table 4 (relaxation family): (13,12) with orders (3,3,4) fusing to 12 = n */
print "Lcm check (13,12):", FusedThreshold(13, 12,
      [<x^12-1 div (x-2), 1>, <x^12-1 div (x-2), 1>, <x^12-1 div (x-3), 1>] >);
print "expected: es = [12,12,4], L = 12 = n, maxsingle = 12, no strict gain";
