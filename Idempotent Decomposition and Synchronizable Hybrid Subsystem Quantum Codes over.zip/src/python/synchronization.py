"""
synchronization.py -- the synchronization threshold theory.

Setup (source paper): C, D cyclic codes of length n over F_q with
    C^perp subset C subset D,
generator polynomials p (for C) and q (for D), so q | p and f := p/q,
deg f = k_D - k_C.

Marker: q_1 := V(q(x)), the coefficient vector of q(x) padded with zeros.
Shift operator: O(c, alpha) = right cyclic shift by alpha.

The receiver measures the C-syndrome of the shifted marker,
    Sigma(alpha) := H_C * O(q_1, -alpha)^T .
The QSC decoding step "recover alpha from Sigma(alpha)" is possible on an
offset window [-a_l, a_r] iff  alpha |-> Sigma(alpha) is injective there.

MAIN RESULT (new, sharpens the known degree-based sufficient bound):
    Sigma(alpha) = Sigma(alpha')  for alpha < alpha'   (delta = alpha'-alpha)
      <=>  O(q_1,alpha) - O(q_1,alpha') in C
      <=>  q(x)(1 - x^delta) in I_C
      <=>  f(x) | 1 - x^delta .
Hence the period of Sigma is exactly
    e(C,D) := ord_{(F_q[x]/(f))^*}(x)   (= min{delta>=1 : f | x^delta - 1}),
and the maximal synchronizable misalignment is a_l + a_r <= e(C,D) - 1  (sharp).

Over R = F_q[v]/(v^3-v), with components (C_i,D_i) and f_i = p_i/q_i, a single
marker in R^n is shifted by one integer alpha; the joint syndrome collides iff
delta is a period in EVERY component, so
    e_R = lcm_i e(C_i,D_i).
"""
from __future__ import annotations
from typing import List, Tuple, Dict, Optional
from finite_field import (GF, p_trim, p_sub, p_mul, p_mod, p_deg, p_is_zero,
                          poly_order_x, p_str, p_divmod)
from cyclic_codes import QCyclicCode, RCyclicCode


# ----------------------------------------------------------------------
# markers and syndromes
# ----------------------------------------------------------------------
def marker_vector(D: QCyclicCode) -> List[int]:
    """q_1 = V(q(x))."""
    return QCyclicCode.pad(D, D.p)      # careful: pad uses self.n


def marker_vector_of(D: QCyclicCode) -> List[int]:
    v = [0] * D.n
    for i, c in enumerate(D.p):
        if i < D.n:
            v[i] = c
    return v


def sigma(C: QCyclicCode, D: QCyclicCode, alpha: int) -> Tuple[int, ...]:
    """H_C O(q_1, -alpha)^T."""
    q1 = marker_vector_of(D)
    return C.syndrome(QCyclicCode.shift_vec(q1, -alpha))


def sigma_table(C: QCyclicCode, D: QCyclicCode) -> Dict[int, Tuple[int, ...]]:
    return {a: sigma(C, D, a) for a in range(C.n)}


def empirical_period(C: QCyclicCode, D: QCyclicCode) -> int:
    """min delta >= 1 with Sigma(alpha + delta) = Sigma(alpha) for all alpha."""
    tab = sigma_table(C, D)
    for delta in range(1, C.n + 1):
        if all(tab[(a + delta) % C.n] == tab[a] for a in range(C.n)):
            return delta
    return C.n


def predicted_period(C: QCyclicCode, D: QCyclicCode) -> Optional[int]:
    """ord_x mod f, where f = p/q.  None if q does not divide p."""
    F = C.F
    if p_deg(D.p) > p_deg(C.p):
        return None
    quo, rem = p_divmod(F, C.p, D.p)
    if not p_is_zero(rem):
        return None
    return poly_order_x(F, p_mono(quo), bound=C.n)


def p_mono(a):
    return a


def collision_delta_set(C: QCyclicCode, D: QCyclicCode) -> List[int]:
    """All delta in [1,n] with Sigma(alpha)=Sigma(alpha+delta) for all alpha."""
    tab = sigma_table(C, D)
    return [d for d in range(1, C.n + 1)
            if all(tab[(a + d) % C.n] == tab[a] for a in range(C.n))]


def divisibility_delta_set(C: QCyclicCode, D: QCyclicCode) -> List[int]:
    """All delta in [1,n] with f | 1 - x^delta."""
    F = C.F
    quo, rem = p_divmod(F, C.p, D.p)
    if not p_is_zero(rem):
        return []
    f = quo
    one_minus_xd = None
    out = []
    for d in range(1, C.n + 1):
        one_minus_xd = p_sub(F, [1], [-1 % F.p] + [0] * (d - 1) + [1]) if False else None
        # construct 1 - x^d directly
        poly = [0] * (d + 1)
        poly[0] = 1
        poly[d] = (-1) % F.p
        if p_is_zero(p_mod(F, poly, f)):
            out.append(d)
    return out


def check_single_component(C: QCyclicCode, D: QCyclicCode) -> Dict:
    """Verify the theorem for one pair (C,D) with C^perp subset C subset D."""
    F = C.F
    quo, rem = p_divmod(F, C.p, D.p)
    ok_div = p_is_zero(rem)
    res = {
        "n": C.n, "q": F.p,
        "p": p_str(F, C.p), "q_gen": p_str(F, D.p),
        "k_C": C.k, "k_D": D.k, "deg_f": p_deg(quo) if ok_div else None,
        "C_subset_D": ok_div,
        "C_self_orthogonal": C.is_self_orthogonal(),
        "empirical_period": None, "predicted_period": None,
        "period_match": False,
        "collision_set_matches_divisibility": False,
        "source_bound_kD_minus_kC": (D.k - C.k),
    }
    if not (ok_div and C.is_self_orthogonal() and C.k < D.k):
        res["applicable"] = False
        return res
    res["applicable"] = True
    emp = empirical_period(C, D)
    pred = poly_order_x(F, quo, bound=C.n)
    res["empirical_period"] = emp
    res["predicted_period"] = pred
    res["period_match"] = (emp == pred)
    res["collision_set_matches_divisibility"] = (
        collision_delta_set(C, D) == divisibility_delta_set(C, D))
    # sharpness of the window statement
    res["sharp_window"] = all(
        (res["period_match"]) for _ in [0])
    return res


# ----------------------------------------------------------------------
# ring level
# ----------------------------------------------------------------------
def ring_period(Cs: List[QCyclicCode], Ds: List[QCyclicCode]) -> int:
    """lcm of the component periods."""
    from math import lcm
    vals = []
    for C, D in zip(Cs, Ds):
        F = C.F
        quo, rem = p_divmod(F, C.p, D.p)
        vals.append(poly_order_x(F, quo, bound=C.n))
    out = 1
    for v in vals:
        out = lcm(out, v)
    return out


def joint_syndrome(Cs, Ds, alpha: int) -> Tuple:
    return tuple(sigma(C, D, alpha) for C, D in zip(Cs, Ds))


def joint_empirical_period(Cs, Ds) -> int:
    n = Cs[0].n
    tabs = [sigma_table(C, D) for C, D in zip(Cs, Ds)]
    for delta in range(1, n + 1):
        if all(all(t[(a + delta) % n] == t[a] for a in range(n)) for t in tabs):
            return delta
    return n


def joint_collision_set(Cs, Ds) -> List[int]:
    n = Cs[0].n
    tabs = [sigma_table(C, D) for C, D in zip(Cs, Ds)]
    return [d for d in range(1, n + 1)
            if all(all(t[(a + d) % n] == t[a] for a in range(n)) for t in tabs)]


def check_ring(Cs, Ds) -> Dict:
    """Verify: joint period = lcm of component periods; joint collisions = intersection."""
    from math import lcm
    comp_periods = []
    comp_coll = []
    for C, D in zip(Cs, Ds):
        comp_periods.append(empirical_period(C, D))
        comp_coll.append(set(collision_delta_set(C, D)))
    joint = joint_empirical_period(Cs, Ds)
    inter = set.intersection(*comp_coll) if comp_coll else set()
    return {
        "component_periods": comp_periods,
        "component_periods_lcm": lcm(*comp_periods),
        "joint_empirical_period": joint,
        "lcm_matches": joint == lcm(*comp_periods),
        "joint_collision_set": sorted(joint_collision_set(Cs, Ds)),
        "intersection_of_component_collision_sets": sorted(inter),
        "intersection_matches": set(joint_collision_set(Cs, Ds)) == inter,
        "max_window": joint - 1,
    }


def window_feasibility(Cs, Ds, al: int, ar: int) -> bool:
    """True iff alpha |-> joint syndrome is injective on {-a_l,...,a_r}."""
    n = Cs[0].n
    seen = {}
    for a in range(-al, ar + 1):
        s = joint_syndrome(Cs, Ds, a)
        if s in seen:
            return False
        seen[s] = a
    return True
