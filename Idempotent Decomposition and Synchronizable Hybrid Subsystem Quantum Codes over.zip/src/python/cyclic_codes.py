"""
cyclic_codes.py -- Cyclic codes over F_q and over R = F_q[v]/(v^3-v).

Conventions
-----------
* length n with gcd(n,q) = 1 (semisimple case; x is a unit modulo x^n - 1).
* A cyclic code over F_q of length n is a divisor p(x) | x^n - 1; the code is
  the principal ideal (p) in F_q[x]/(x^n - 1); dim = n - deg p.
* The dual code has generator polynomial the reciprocal of the check
  polynomial:  h(x) = (x^n-1)/p(x),  h*(x) = x^(deg h) h(1/x).
* A cyclic code over R of length n is an R[x]/(x^n-1)-ideal, equivalently a
  triple (C1, C2, C3) of F_q-cyclic codes (CRT / idempotent decomposition).

The code never assumes R-freeness (see `is_free_R_module`).
"""
from __future__ import annotations
from typing import List, Tuple, Dict
from finite_field import (GF, p_trim, p_add, p_sub, p_mul, p_divmod, p_mod, p_deg,
                          p_is_zero, p_monic, p_reverse, p_gcd, p_factor,
                          poly_order_x, p_str)


# ----------------------------------------------------------------------
# F_q cyclic codes
# ----------------------------------------------------------------------
class QCyclicCode:
    """A cyclic code C = (p(x)) in F_q[x]/(x^n-1)."""

    def __init__(self, F: GF, n: int, p: List[int], name: str = ""):
        self.F, self.n = F, n
        self.p = p_monic(F, p)
        self.name = name
        self._cm = None
        self._h = None
        if not self._divides_xn_minus_1():
            raise ValueError(
                f"generator polynomial {p_str(F, self.p)} does not divide x^{n}-1 "
                f"over F_{F.p}; (p) is not a cyclic code of length {n}")

    def _divides_xn_minus_1(self) -> bool:
        xn1 = [self.F.neg(1) % self.F.p] + [0] * (self.n - 1) + [1]
        return p_is_zero(p_mod(self.F, xn1, self.p))

    # ---- basic invariants ----
    @property
    def n_(self) -> int:
        return self.n

    @property
    def k(self) -> int:
        return self.n - p_deg(self.p)

    @property
    def check_poly(self) -> List[int]:
        if self._h is None:
            xn1 = [self.F.neg(1) % self.F.p] + [0] * (self.n - 1) + [1]
            self._h = p_divmod(self.F, xn1, self.p)[0]
        return self._h

    @property
    def dual_gen(self) -> List[int]:
        """Generator polynomial of C^perp (reciprocal of the check polynomial)."""
        h = self.check_poly
        return p_monic(self.F, p_reverse(self.F, h, p_deg(h)))

    @property
    def dual(self) -> "QCyclicCode":
        return QCyclicCode(self.F, self.n, self.dual_gen, self.name + "^perp")

    def contains(self, other: "QCyclicCode") -> bool:
        """True iff other's ideal is inside self, i.e. self.p | other.p."""
        return p_is_zero(p_mod(self.F, other.p, self.p))

    def is_self_orthogonal(self) -> bool:
        return self.contains(self.dual)

    # ---- vector bookkeeping ----
    def words(self) -> List[Tuple[int, ...]]:
        """All codewords (requires manageable size)."""
        F, n, k = self.F, self.n, self.k
        # basis = shifts of p by 0..k-1
        basis = [self.shift_vec(self.pad(self.p), i) for i in range(k)]
        out = []
        q = F.p
        for idx in range(q ** k):
            v = [0] * n
            t = idx
            for b in range(k):
                c = t % q
                t //= q
                if c:
                    for j in range(n):
                        v[j] = (v[j] + c * basis[b][j]) % q
            out.append(tuple(v))
        return out

    def pad(self, poly) -> List[int]:
        v = [0] * self.n
        for i, c in enumerate(poly):
            if i < self.n:
                v[i] = c
        return v

    @staticmethod
    def shift_vec(v, alpha: int):
        n = len(v)
        alpha %= n
        return [v[(i - alpha) % n] for i in range(n)]   # right shift by alpha

    def vectorize(self, poly) -> List[int]:
        return self.pad(poly)

    def weight(self, v) -> int:
        return sum(1 for c in v if c % self.F.p != 0)

    def min_distance(self) -> int:
        d = self.n + 1
        for w in self.words():
            if any(c % self.F.p != 0 for c in w):
                d = min(d, self.weight(w))
        return d if d <= self.n else 0

    # ---- parity check matrix (rows = shifts of dual generator) ----
    def check_matrix(self) -> List[List[int]]:
        """H_C: a generator matrix of C^perp, i.e. the (n-k) rows obtained by
        shifting V(g) where g generates C^perp.  n - deg(g) rows in total
        (deg(g) = k), so the row count is n - k = dim C^perp."""
        if self._cm is None:
            g = self.dual_gen
            self._cm = [self.shift_vec(self.pad(g), i)
                        for i in range(self.n - p_deg(g))]
        return self._cm

    def syndrome(self, v) -> Tuple[int, ...]:
        return tuple(sum(c * r[j] for j, c in enumerate(v)) % self.F.p
                     for r in self.check_matrix())

    def __repr__(self):
        return f"[{self.n},{self.k}] cycl (p={p_str(self.F, self.p)})"


# ----------------------------------------------------------------------
# R-cyclic codes
# ----------------------------------------------------------------------
class RCyclicCode:
    """A cyclic code over R of length n: a triple of F_q-cyclic codes."""

    def __init__(self, R, n: int, comps: List[QCyclicCode], name: str = ""):
        assert len(comps) == 3
        self.R, self.n, self.comps, self.name = R, n, comps, name

    @property
    def k_vector(self) -> Tuple[int, int, int]:
        return tuple(c.k for c in self.comps)

    @property
    def cardinality(self) -> int:
        """|C| = q^(sum of F_q-dimensions) = q^(log_q |C|)."""
        return self.R.q ** sum(self.k_vector)

    @property
    def log_q_cardinality(self) -> int:
        return sum(self.k_vector)

    @property
    def is_free_R_module(self) -> bool:
        k = self.k_vector
        return k[0] == k[1] == k[2]

    @property
    def R_rank(self):
        return self.k_vector[0] if self.is_free_R_module else None

    @property
    def dual(self) -> "RCyclicCode":
        return RCyclicCode(self.R, self.n, [c.dual for c in self.comps], self.name + "^perp")

    def contains(self, other: "RCyclicCode") -> bool:
        return all(a.contains(b) for a, b in zip(self.comps, other.comps))

    def is_self_orthogonal(self) -> bool:
        return all(c.is_self_orthogonal() for c in self.comps)

    def min_weight_tuple(self) -> Tuple[int, int, int]:
        return tuple(c.min_distance() for c in self.comps)

    # ---- CRT expansion to F_q^(3n), interleaved ("cell") and block layouts ----
    def expand_interleaved(self, words_components):
        """cells: cell t carries (comp1_t, comp2_t, comp3_t) at positions 3t,3t+1,3t+2."""
        n = self.n
        out = []
        for wc in words_components:
            v = [0] * (3 * n)
            for t in range(n):
                for i in range(3):
                    v[3 * t + i] = wc[i][t] % self.R.q
            out.append(tuple(v))
        return out

    def expand_block(self, words_components):
        n = self.n
        out = []
        for wc in words_components:
            v = []
            for i in range(3):
                v.extend([c % self.R.q for c in wc[i]])
            out.append(tuple(v))
        return out

    def all_component_words(self):
        return [tuple(c.words()) for c in self.comps]

    def __repr__(self):
        return (f"R-cyclic n={self.n} k_vector={self.k_vector} "
                f"free={self.is_free_R_module}")


# ----------------------------------------------------------------------
# enumerate cyclic codes of length n over F_q
# ----------------------------------------------------------------------
def divisors_of_xn_minus_1(F: GF, n: int) -> List[List[int]]:
    """All monic divisors of x^n - 1 over F_q (q coprime to n)."""
    xn1 = [F.neg(1) % F.p] + [0] * (n - 1) + [1]
    facs = p_factor(F, xn1)
    # all products of subsets
    out = [[1]]
    for f in facs:
        new = []
        for d in out:
            new.append(p_monic(F, p_mul(F, d, f)))
        out = out + new
    # unique
    uniq = {}
    for d in out:
        uniq[tuple(p_trim(d))] = p_trim(d)
    return sorted(uniq.values(), key=lambda a: (p_deg(a), a))


def num_irreducible_factors(F: GF, n: int) -> int:
    """t such that x^n - 1 is a product of t monic irreducibles over F_q
    (computed WITHOUT materializing the 2^t divisors)."""
    xn1 = [F.neg(1) % F.p] + [0] * (n - 1) + [1]
    return len(p_factor(F, xn1))


def all_cyclic_codes(F: GF, n: int) -> List[QCyclicCode]:
    return [QCyclicCode(F, n, d) for d in divisors_of_xn_minus_1(F, n)]


def nested_pairs(F: GF, n: int, self_orthogonal_C: bool = True,
                 proper: bool = True) -> List[Tuple[QCyclicCode, QCyclicCode]]:
    """All pairs (C,D) with C^perp subset C subset D (or all pairs if flags off)."""
    codes = all_cyclic_codes(F, n)
    pairs = []
    for C in codes:
        if self_orthogonal_C and not C.is_self_orthogonal():
            continue
        for D in codes:
            if D.contains(C):          # C subset D  <=>  D.p | C.p
                if proper and not (C.k < D.k):
                    continue
                pairs.append((C, D))
    return pairs


def nested_triples(F: GF, n: int) -> List[Tuple[QCyclicCode, QCyclicCode, QCyclicCode]]:
    """All triples C^perp subset C subset D with k_C < k_D."""
    pairs = nested_pairs(F, n)
    return [(C.dual, C, D) for (C, D) in pairs]
