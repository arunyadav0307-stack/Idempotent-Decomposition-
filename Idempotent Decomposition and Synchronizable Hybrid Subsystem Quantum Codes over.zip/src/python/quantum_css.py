"""
quantum_css.py -- q-ary CSS / hybrid / subsystem helpers on the interleaved lift.

QUANTUM MODEL: **Model A** of /home/user/quantum_model_decision.md (Phase 7
decision, frozen).  Conventions implemented here:

  * Hilbert space (C^q)^{\otimes 3n}, N = 3n qudits; position 3t+i carries the
    t-th symbol of the i-th CRT component code C_i (i = 1,2,3, t in Z_n).
  * Pauli group <X(a), Z(b)> with X(a)Z(b) = omega^{a.b} Z(b)X(a), omega = e^{2 pi i/q};
    symplectic form <(a|b),(a'|b')> = a.b' - a'.b  (q odd prime).
  * Misalignment: cyclic rotation by 3*alpha positions ("cell shift" alpha);
    only cell-aligned offsets are correctable (documented limitation).
  * Parameters [[N, K : M, R_g, D]]_q with K = sum_i (2 k_{C,i} - n),
    D = min_i min wt(D_i \ C_i) for the basic construction, and the branch
    threshold e_i = ord_x(p_{C_i}/p_{D_i}); the joint threshold is lcm_i e_i.

Do not call the brute-force QuditCSS.distance_X / distance_Z for N = 3n >= 12:
they enumerate 4*N-q-ary Pauli words and blow up.  Use comp_css_distance()
(componentwise, exact for the interleaved lift).
"""
from __future__ import annotations
from typing import List, Tuple, Dict
from finite_field import GF
from cyclic_codes import QCyclicCode, RCyclicCode


def dot(F: GF, a, b) -> int:
    return sum(x * y for x, y in zip(a, b)) % F.p


def weight(v) -> int:
    return sum(1 for c in v if c % 1 != 0 and c != 0)


def wt(v) -> int:
    return sum(1 for c in v if c != 0)


def span(F: GF, basis: List[List[int]]) -> List[Tuple[int, ...]]:
    """All F_q-linear combinations of `basis`."""
    q = F.p
    out = []
    m = len(basis)
    N = len(basis[0]) if basis else 0
    for idx in range(q ** m):
        v = [0] * N
        t = idx
        for b in range(m):
            c = t % q
            t //= q
            if c:
                for j in range(N):
                    v[j] = (v[j] + c * basis[b][j]) % q
        out.append(tuple(v))
    return out


def nullspace(F: GF, basis: List[List[int]], N: int) -> List[List[int]]:
    """A basis of {v : dot(v,b)=0 for all b in basis}."""
    # Gaussian elimination over F_q
    rows = [list(b) for b in basis]
    piv = []
    r = 0
    for c in range(N):
        p = None
        for i in range(r, len(rows)):
            if rows[i][c] % F.p:
                p = i
                break
        if p is None:
            continue
        rows[r], rows[p] = rows[p], rows[r]
        inv = F.inv(rows[r][c])
        rows[r] = [F.mul(inv, x) for x in rows[r]]
        for i in range(len(rows)):
            if i != r and rows[i][c] % F.p:
                f = rows[i][c]
                rows[i] = [F.sub(rows[i][j], F.mul(f, rows[r][j])) for j in range(N)]
        piv.append(c)
        r += 1
        if r == len(rows):
            break
    free = [c for c in range(N) if c not in piv]
    basis_out = []
    for fc in free:
        v = [0] * N
        v[fc] = 1
        for i, pc in enumerate(piv):
            v[pc] = F.neg(rows[i][fc])
        basis_out.append(v)
    return basis_out


def css_parameters(F: GF, A_span, B_span, N: int) -> Dict:
    """A_span, B_span: lists of generators generating the X- and Z-subspaces.

    Returns k, and verifies validity (A subset B^perp).
    """
    valid = all(dot(F, a, b) == 0 for a in A_span for b in B_span)
    da = len(A_span)
    db = len(B_span)
    return {"valid": valid, "k": N - da - db, "dim_A": da, "dim_B": db}


class QuditCSS:
    """A q-ary CSS stabilizer code with X-stabilizer space A and Z-space B.

    A and B are given as bases (lists of vectors).  The code is symmetric if
    A == B.
    """

    def __init__(self, F: GF, N: int, basisA: List[List[int]], basisB: List[List[int]], name=""):
        self.F, self.N = F, N
        self.basisA = [list(v) for v in basisA]
        self.basisB = [list(v) for v in basisB]
        self.name = name
        self.valid = all(dot(F, a, b) == 0 for a in self.basisA for b in self.basisB)

    @property
    def dimA(self):
        return len(self.basisA)

    @property
    def dimB(self):
        return len(self.basisB)

    @property
    def K(self):
        return self.N - self.dimA - self.dimB

    def logical_Z(self):
        """Bare Z-type logical operators: vectors in A^perp mod span(B)."""
        Aperp = nullspace(self.F, self.basisA, self.N)
        return Aperp

    def logical_X(self):
        Bperp = nullspace(self.F, self.basisB, self.N)
        return Bperp

    def distance_Z(self) -> int:
        """min weight of v in A^perp (bare X-logical rep) that is not in span(B)
        -- i.e. min wt((A^perp + B-side)... ) computed as: v in A^perp with
        v not in span(B) and v not in ... For CSS: d_Z = min wt(v) for
        v in A^perp \\ B ."""
        F = self.F
        Aperp = nullspace(F, self.basisA, self.N)
        B = span(F, self.basisB)
        Bset = set(B)
        wtmin = self.N + 1
        for v in span(F, Aperp):
            if v not in Bset and wt(v) > 0:
                wtmin = min(wtmin, wt(v))
        return wtmin

    def distance_X(self) -> int:
        F = self.F
        Bperp = nullspace(F, self.basisB, self.N)
        A = span(F, self.basisA)
        Aset = set(A)
        wtmin = self.N + 1
        for v in span(F, Bperp):
            if v not in Aset and wt(v) > 0:
                wtmin = min(wtmin, wt(v))
        return wtmin


# ----------------------------------------------------------------------
# fusion of three q-ary components (the R-code picture)
# ----------------------------------------------------------------------
def fuse_interleaved(F: GF, n: int, components: List[List[Tuple[int, ...]]]) -> List[Tuple[int, ...]]:
    """components[i] = list of words (each length n) for CRT component i.

    Returns the interleaved words of length 3n (cell layout)."""
    out = []
    for tup in zip(*components):
        v = [0] * (3 * n)
        for t in range(n):
            for i in range(3):
                v[3 * t + i] = tup[i][t] % F.p
        out.append(tuple(v))
    return out


def cycle_interleaved(F: GF, v: List[int], alpha: int, n: int) -> List[int]:
    """Shift the whole interleaved word by 3*alpha positions."""
    N = 3 * n
    s = (3 * alpha) % N
    return [v[(i - s) % N] for i in range(N)]


def cell_components(F: GF, v: List[int], n: int) -> List[List[int]]:
    out = [[0] * n for _ in range(3)]
    for t in range(n):
        for i in range(3):
            out[i][t] = v[3 * t + i]
    return out
