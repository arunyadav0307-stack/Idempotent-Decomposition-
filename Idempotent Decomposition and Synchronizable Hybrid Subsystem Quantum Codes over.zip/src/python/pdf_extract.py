"""Minimal PDF content-stream text extractor (no external deps).

Handles: FlateDecode streams, BT/ET blocks, Tj/TJ/'/" operators,
hex strings <...> and literal strings (...), and escapes.
Outputs a rough text approximation useful for auditing.
"""
import re, zlib, sys

def get_objects(data):
    objs = {}
    for m in re.finditer(rb'(\d+)\s+(\d+)\s+obj', data):
        num = int(m.group(1))
        start = m.end()
        end = data.find(b'endobj', start)
        body = data[start:end]
        objs[num] = body
    return objs

def decompress(body):
    sm = re.search(rb'stream\r?\n', body)
    if not sm:
        return None
    s = sm.end()
    e = body.find(b'endstream', s)
    raw = body[s:e]
    if b'FlateDecode' in body[:sm.start()]:
        try:
            return zlib.decompress(raw)
        except Exception:
            try:
                return zlib.decompressobj().decompress(raw)
            except Exception:
                return None
    return raw

def unescape(s):
    out = []
    i = 0
    while i < len(s):
        c = s[i]
        if c == '\\' and i + 1 < len(s):
            n = s[i+1]
            mapping = {'n':'\n','r':'\r','t':'\t','b':'\b','f':'\f','(':'(',')':')','\\':'\\'}
            if n in mapping:
                out.append(mapping[n]); i += 2; continue
            m = re.match(r'[0-7]{1,3}', s[i+1:i+4])
            if m:
                out.append(chr(int(m.group(0), 8))); i += 1 + len(m.group(0)); continue
            out.append(n); i += 2; continue
        out.append(c); i += 1
    return ''.join(out)

TOKEN = re.compile(rb'''
    \[(?P<arr>(?:[^\[\]\\]|\\.)*)\]        # array
  | \((?P<lit>(?:[^()\\]|\\.)*)\)          # literal string
  | <(?P<hex>[0-9A-Fa-f\s]*)>              # hex string
  | (?P<num>[-+]?\d*\.?\d+)                # number
  | (?P<op>[A-Za-z'"*]+)                   # operator
''', re.VERBOSE | re.DOTALL)

def tokens_to_text(chunk):
    """Convert a BT..ET stream chunk to text."""
    out = []
    for m in TOKEN.finditer(chunk):
        if m.group('op'):
            op = m.group('op')
            if op in (b'Tj', b'TJ', b"'", b'"'):
                if op in (b"'", b'"'):
                    out.append('\n')
            continue
        if m.group('arr') is not None:
            body = m.group('arr').decode('latin-1')
            pieces = []
            pos = 0
            for mm in re.finditer(r'\((?:\\.|[^()\\])*\)|[-+]?\d+(?:\.\d+)?', body):
                tok = mm.group(0)
                if tok.startswith('('):
                    pieces.append(unescape(re.sub(r'^-*\(|\)$', '', tok)) if False else unescape(tok[1:-1]))
                else:
                    try:
                        v = float(tok)
                    except ValueError:
                        continue
                    if v <= -100:
                        pieces.append(' ')
            out.append(''.join(pieces))
            continue
        if m.group('lit') is not None:
            out.append(unescape(m.group('lit').decode('latin-1')))
            continue
        if m.group('hex') is not None:
            h = re.sub(r'\s', '', m.group('hex').decode('latin-1'))
            if len(h) % 2: h += '0'
            try:
                out.append(bytes.fromhex(h).decode('latin-1'))
            except Exception:
                pass
            continue
    return ''.join(out)

def extract(path):
    data = open(path, 'rb').read()
    objs = get_objects(data)
    pages = []
    for num, body in objs.items():
        dec = decompress(body)
        if not dec: continue
        if b'BT' not in dec: continue
        # split BT/ET
        chunks = []
        for m in re.finditer(rb'BT(.*?)ET', dec, re.DOTALL):
            chunks.append(m.group(1))
        if not chunks:
            chunks = [dec]
        text = '\n'.join(tokens_to_text(c) for c in chunks)
        text = re.sub(r'[ \t]{2,}', ' ', text)
        pages.append((num, text))
    return pages

if __name__ == '__main__':
    pages = extract(sys.argv[1])
    pages.sort()
    full = []
    for num, t in pages:
        full.append(f"\n===== OBJECT/STREAM {num} =====\n{t}")
    result = '\n'.join(full)
    open(sys.argv[2], 'w', encoding='utf-8').write(result)
    print(result[:1000])
    print('...')
    print('TOTAL CHARS', len(result))
