"""
ring_r.py -- The ring R = F_q[v]/(v^3 - v), q odd with 3 not dividing q.

Everything here is verified computationally (see tests/).  Elements of R are
represented by triples (x0,x1,x2) of F_q elements via the CRT isomorphism
    phi : R -> F_q x F_q x F_q,   f  |->  (f(0), f(1), f(-1)).
A "native producer" representation by coefficient vectors in the basis
{1, v, v^2} is included so that the CRT map, the idempotents and the
multiplication table can all be checked against each other independently.
"""
from __future__ import annotations
from typing import List, Tuple
from finite_field import GF, p_trim, p_add, p_sub, p_mul, p_divmod, p_mod, p_deg, p_is_zero


class RingR:
    """R = F_q[v]/(v^3-v).

    Two parallel representations:
      * native: coefficient list [c0,c1,c2] meaning c0 + c1 v + c2 v^2
      * CRT:    triple (a,b,c) meaning a*e1 + b*e2 + c*e3
    All field arithmetic happens over F = F_q.
    """

    def __init__(self, q: int):
        self.F = GF(q)
        self.q = q
        q_ = q
        # hypotheses of the theory
        self.char_not_2 = (q % 2 == 1)
        self.char_not_3 = (q % 3 != 0)
        self.is_semisimple = self.char_not_2 and self.char_not_3
        # idempotents (native coefficients)
        # e1 = 1 - v^2 ; e2 = (v^2+v)/2 ; e3 = (v^2-v)/2
        inv2 = self.F.inv(2)
        self.e1_native = [1, 0, q_ - 1]
        self.e2_native = [0, inv2, inv2]
        self.e3_native = [0, (q_ - inv2) % q_, inv2]

    # ---------- native arithmetic ----------
    def native_mul(self, a, b) -> List[int]:
        """Multiplication in R: reduce v^3 -> v."""
        q = self.q
        raw = [0] * 5
        for i, x in enumerate(a):
            for j, y in enumerate(b):
                raw[i + j] += x * y
        for k in range(4, 2, -1):
            c = raw[k] % q
            raw[k] = 0
            raw[k - 2] += c
        return [raw[i] % q for i in range(3)]

    def native_add(self, a, b):
        return [(a[i] + b[i]) % self.q for i in range(3)]

    # ---------- CRT map ----------
    def crt(self, native) -> Tuple[int, int, int]:
        """f |-> (f(0), f(1), f(-1))."""
        F = self.F
        f0 = p_eval_native(F, native, 0)
        f1 = p_eval_native(F, native, 1)
        fm1 = p_eval_native(F, native, self.q - 1)
        return (f0, f1, fm1)

    def crt_inv(self, trip) -> List[int]:
        a, b, c = trip
        F, q = self.F, self.q
        inv2 = F.inv(2)
        # coefficients in basis {1, v, v^2}:  f = alpha + beta v + gamma v^2
        alpha = a
        beta = (b + (q - c) % q) * inv2 % q
        gamma = ((b + c) % q - 2 * a) % q
        gamma = gamma * inv2 % q
        return [alpha % q, beta % q, gamma % q]

    def crt_mul(self, t1, t2):
        return tuple((t1[i] * t2[i]) % self.q for i in range(3))

    def crt_add(self, t1, t2):
        return tuple((t1[i] + t2[i]) % self.q for i in range(3))

    # ---------- idempotent checks ----------
    def check_idempotents(self) -> dict:
        """Verify e_i^2 = e_i, e_i e_j = 0 (i != j), e1+e2+e3 = 1.

        Checked in BOTH representations (native multiplication and CRT).
        """
        F, q = self.F, self.q
        e_native = [self.e1_native, self.e2_native, self.e3_native]
        e_crt = [self.crt(e) for e in e_native]
        report = {"e_crt": e_crt, "idempotent": True, "orthogonal": True,
                  "sum_one": True, "native_equals_crt": True}
        for i in range(3):
            for j in range(3):
                prod_native = self.native_mul(e_native[i], e_native[j])
                want = e_native[i] if i == j else [0, 0, 0]
                if prod_native != want:
                    if i == j:
                        report["idempotent"] = False
                    else:
                        report["orthogonal"] = False
                # CRT cross-check
                prod_crt = self.crt_mul(e_crt[i], e_crt[j])
                want_crt = (1 if i == j else 0,)
                expect = tuple(1 if k == i else 0 for k in range(3)) if i == j else (0, 0, 0)
                if prod_crt != expect:
                    report["native_equals_crt"] = False
        s = self.native_add(self.native_add(e_native[0], e_native[1]), e_native[2])
        if s != [1, 0, 0]:
            report["sum_one"] = False
        return report

    def check_structure(self) -> dict:
        """Field-theoretic facts about R."""
        F, q = self.F, self.q
        # factorization of v^3 - v
        roots = [0, 1, (q - 1) % q]
        distinct = len(set(roots)) == 3
        # CRT map is a surjective F_q-algebra homomorphism
        crt_multiplicative = True
        crt_additive = True
        for a in range(q):
            for b in range(q):
                for c in range(q):
                    x = [a, b, c]
                    y = [c, a, b]
                    if self.crt(self.native_mul(x, y)) != self.crt_mul(self.crt(x), self.crt(y)):
                        crt_multiplicative = False
                    if self.crt(self.native_add(x, y)) != self.crt_add(self.crt(x), self.crt(y)):
                        crt_additive = False
        # enumerate units / zero divisors
        zero_div = []
        units = []
        for a in range(q):
            for b in range(q):
                for c in range(q):
                    x = [a, b, c]
                    un = all(v != 0 for v in self.crt(x))
                    (units if un else zero_div).append(tuple(x))
        for x in zero_div:
            if all(v == 0 for v in x):
                zero_div.remove(x)
                break
        return {
            "q": q, "char_not_2": self.char_not_2, "char_not_3": self.char_not_3,
            "v3_minus_v_squarefree": distinct,
            "crt_multiplicative": crt_multiplicative,
            "crt_additive": crt_additive,
            "num_units": len(units), "expected_units": (q - 1) ** 3,
            "num_nonzero_zero_divisors": len(zero_div),
            "expected_nonzero_zero_divisors": q ** 3 - 1 - (q - 1) ** 3,
            "is_semisimple": self.is_semisimple,
        }


def p_eval_native(F: GF, coeffs, x: int) -> int:
    """Evaluate a polynomial given by native coefficient list at x in F_q."""
    val = 0
    for c in reversed(coeffs):
        val = F.add(F.mul(val, x), c)
    return val


def edge_case_char_two():
    """Document (and verify) the failure of the CRT structure in char 2.

    Over F_2 :  v^3 - v = v(v+1)^2, so
        R = F_2[v]/(v^3-v) ~= F_2 x F_2[eps]/(eps^2),
    which is NOT a product of three fields: it is non-reduced, the CRT
    decomposition into three fields fails, and (v^2 +- v)/2 is undefined
    because 2 = 0.  Hence the hypothesis "q odd" is necessary, not cosmetic.
    """
    # (a) multiplicity of the root v = 1 over F_2
    mult_at_1 = "v(v+1)^2 -> the root 1 has multiplicity 2, not 1"
    # (b) 2 is not invertible
    inv2_exists = False
    # (c) v^2 + v : e2 would require dividing by 2
    return {"char": 2,
            "v3_minus_v_factorization": "v * (v+1)^2",
            "squarefree": False,
            "root_1_multiplicity": 2,
            "2_invertible": inv2_exists,
            "R_structure": "F_2 x F_2[eps]/(eps^2)   (non-reduced)",
            "crt_into_3_fields_exists": False,
            "conclusion": ("q must be ODD: for char F_q != 2 the polynomial v^3-v has the "
                           "three distinct roots 0, 1, -1, so R is a product of three copies "
                           "of F_q and the idempotents e1,e2,e3 exist.  (char 3 is allowed.)")}
