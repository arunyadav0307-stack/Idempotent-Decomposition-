"""
experiments.py -- generates every numerical table used in the manuscript.

Run:  python3 src/python/experiments.py [table2 table3 ...]      (from the package root)
Writes: data/tables.json, results/experiments_log.txt, tables/*.csv

Design notes
------------
* Every minimum weight is computed EXACTLY by enumerating vectors in increasing
  weight order and stopping at the first hit.  A per-weight-class budget CAP is
  enforced; when a weight class is too large to enumerate the routine returns
  None ("unknown") rather than a wrong number.
* Code enumeration is guarded by the number 2^t of monic divisors of x^n - 1;
  cases with 2^t > CODE_CAP are skipped (they are covered by the closed-form
  linear-branch family, see table_single / table_fusion).
* Artifacts are (re)written after EVERY table so that a timeout still leaves a
  consistent partial set on disk.
"""
from __future__ import annotations

import csv
import json
import os
import sys
import time
from itertools import combinations, product, combinations_with_replacement
from math import comb as binom, lcm

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, os.path.join(ROOT, "src", "python"))

from finite_field import (GF, p_deg, p_divmod, p_mod, p_mul, p_str,
                           poly_order_x)          # noqa: E402
from cyclic_codes import (QCyclicCode, RCyclicCode, all_cyclic_codes,      # noqa: E402
                          divisors_of_xn_minus_1, num_irreducible_factors)
from synchronization import (empirical_period, joint_empirical_period,     # noqa: E402
                             window_feasibility, joint_collision_set)
from ring_r import RingR, edge_case_char_two                               # noqa: E402

LOG: list = []
TABLES: dict = {}


def log(*a):
    s = " ".join(str(x) for x in a)
    print(s, flush=True)
    LOG.append(s)


# ======================================================================
# exact minimum weights (increasing weight enumeration)
# ======================================================================
CAP = 400_000          # vectors tested per weight class
CODE_CAP = 4096        # 2^t guard for exhaustive code enumeration
PAIR_CAP = 300_000     # 4^t guard for exhaustive pair (C,D) enumeration


def _scan(C: QCyclicCode, D, cap: int = CAP):
    """min weight of C\\{0} if D is None, else of D\\C; None if a weight class
    exceeds the budget (caller must treat None as 'unknown', never as a value)."""
    n, q = C.n, C.F.p
    for w in range(1, n + 1):
        if binom(n, w) * (q - 1) ** w > cap:
            return None
        for sup in combinations(range(n), w):
            for vals in product(range(1, q), repeat=w):
                v = [0] * n
                for i, val in zip(sup, vals):
                    v[i] = val
                inC = not any(C.syndrome(v))
                if D is None:
                    if inC:
                        return w
                else:
                    if inC:
                        continue
                    if not any(D.syndrome(v)):
                        return w
    return None


def min_weight_in(C: QCyclicCode, cap: int = CAP):
    return _scan(C, None, cap)


def min_weight_outside(C: QCyclicCode, D: QCyclicCode, cap: int = CAP):
    return _scan(C, D, cap)


def min_weight_of_difference(A: QCyclicCode, B: QCyclicCode, cap: int = CAP):
    """min weight of A \\ B (both code membership tests by syndrome)."""
    n, q = A.n, A.F.p
    for w in range(1, n + 1):
        if binom(n, w) * (q - 1) ** w > cap:
            return None
        for sup in combinations(range(n), w):
            for vals in product(range(1, q), repeat=w):
                v = [0] * n
                for i, val in zip(sup, vals):
                    v[i] = val
                if any(A.syndrome(v)):
                    continue
                if not any(B.syndrome(v)):
                    continue
                return w
    return None


def elem_of_order(q: int, m: int):
    """a in F_q^* with multiplicative order exactly m (m | q-1)."""
    if m == 1:
        return 1
    for a in range(2, q):
        o, cur = 1, a % q
        while cur != 1:
            cur = (cur * a) % q
            o += 1
        if o == m:
            return a
    return None


def linear_branch(q: int, n: int, m: int):
    """(C,D) with C = <x - a>, ord(a) = m, D = F_q^n:  deg f = 1, e = m."""
    a = elem_of_order(q, m)
    if a is None:
        return None
    return (q, n, [(-a) % q, 1], [1])


# ======================================================================
# TABLE 2 -- single-branch threshold vs the degree-of-f bound
# ======================================================================
SINGLE = [
    # (q, n, C-generator, D-generator); both must divide x^n - 1 over F_q
    (3, 13, [1, 0, 1, 0, 0, 1, 1], [2, 1, 1, 1]),      # C[13,7,4], D[13,10,3]
    (5, 8, [1, 2, 3, 1], [3, 1]),                      # C[8,5,3],  D[8,7,2]
    (7, 6, [6, 2, 1], [5, 1]),                         # C[6,4,3],  D[6,5,2]
    (11, 5, [3, 9, 1], [2, 1]),                        # C[5,3,3],  D[5,4,2]
]

# linear-branch rows: deg f = 1, e = ord(a) = m  (closed form, no search)
_LINEAR = [(3, 7, 7), (5, 8, 4), (7, 9, 3), (11, 10, 5), (13, 12, 4),
           (13, 4, 4), (17, 8, 8), (19, 6, 6), (23, 11, 11), (31, 5, 5),
           (31, 10, 10), (31, 30, 30), (37, 4, 4)]
for _t in _LINEAR:
    _lb = linear_branch(*_t)
    if _lb:
        SINGLE.append(_lb)


def table_single():
    rows = []
    for (q, n, cp, dp) in SINGLE:
        F = GF(q)
        try:
            C = QCyclicCode(F, n, cp)
            D = QCyclicCode(F, n, dp)
        except ValueError:
            log(f"  SKIP (bad generator) q={q} n={n} {cp} -> {dp}")
            continue
        okDC = D.contains(C)
        okSO = C.is_self_orthogonal()          # C^perp subset C (dual-containing)
        if not (okDC and okSO):
            log(f"  SKIP (hypothesis) q={q} n={n}: D contains C = {okDC}, "
                f"C^perp subset C = {okSO}")
            continue
        quo, rem = p_divmod(F, C.p, D.p)
        e = empirical_period(C, D)
        assert e == poly_order_x(F, quo, bound=n), (q, n, e)
        dC = min_weight_in(C)
        dD = min_weight_outside(C, D)
        K = 2 * C.k - n
        wmax = min(e - 1, n - 1)
        degf = D.k - C.k
        rows.append({"q": q, "n": n, "p_C": p_str(F, C.p), "p_D": p_str(F, D.p),
                     "k_C": C.k, "k_D": D.k, "d_C": dC, "d_D_outside_C": dD,
                     "deg_f": degf, "e": e,
                     "window_deg_bound": degf - 1,
                     "window_sharp": wmax,
                     "window_gain": (wmax / (degf - 1)) if degf > 1 else None,
                     "K_single_branch": K, "N_min": n, "N_max": n + wmax})
        log(f"  q={q:2d} n={n:2d}: C[{n},{C.k},{dC}] D[{n},{D.k},{dD}]  "
            f"deg f={degf}  e=ord_x(f)={e}  window<={wmax} "
            f"(deg-f bound would give {degf-1})  K={K}  N in "
            f"[{n}, {n + wmax}]")
    return rows


# ======================================================================
# TABLE 3 -- fusion over R: e_R = lcm(e_1,e_2,e_3)
# ======================================================================
FUSION_CASES = [(3, 8), (3, 10), (5, 8), (7, 6), (7, 10), (7, 15), (11, 5),
                (13, 6), (3, 13), (5, 12), (11, 10), (13, 12)]


def achievable_periods(F, n):
    """dict e -> witness pairs over all chains C^perp subset C subset D, plus
    the census of dual-containing codes (key None)."""
    t = num_irreducible_factors(F, n)
    if 4 ** t > PAIR_CAP:
        return None                      # exhaustive pair search too large
    codes = all_cyclic_codes(F, n)
    dc = [C for C in codes if C.is_self_orthogonal() and C.k < n]
    tab = {}
    for C in codes:
        if not C.is_self_orthogonal():
            continue
        for D in codes:
            if not (D.contains(C) and C.k < D.k):
                continue
            e = empirical_period(C, D)
            lst = tab.setdefault(e, [])
            if len(lst) < 6:                    # keep a few witnesses only
                lst.append((C, D))
    tab[None] = dc
    return tab


def table_fusion():
    rows = []
    for (q, n) in FUSION_CASES:
        F = GF(q)
        tab = achievable_periods(F, n)
        if not tab:
            log(f"  SKIP q={q} n={n}: too many cyclic codes for exhaustive search")
            continue
        dc = tab.pop(None)
        if not tab:
            log(f"  NO-GO q={q} n={n}: the only dual-containing cyclic code of "
                f"length {n} over F_{q} is the whole space F_{q}^{n}; no "
                f"nontrivial branch exists (criterion: -1 in <q> mod n).")
            rows.append({"q": q, "n": n, "N": 3 * n, "no_go": True,
                         "dual_containing_nontrivial": 0,
                         "criterion_minus1_in_q_group": (-1) % n in
                         _q_group(q, n)})
            continue
        vals = sorted(tab)
        best = None
        for tri in combinations_with_replacement(vals, 3):
            L = lcm(*tri)
            key = (L, -max(tri), -sum(tri))
            if best is None or key > best[0]:
                best = (key, L, tri)
        _, L, tri = best
        sel, used = [], set()
        for e in tri:
            cands = [p for p in tab[e] if (tuple(p[0].p), tuple(p[1].p)) not in used]
            if not cands:
                cands = tab[e]
            C, D = max(cands, key=lambda p: (p[0].k, p[1].k))
            used.add((tuple(C.p), tuple(D.p)))
            sel.append((C, D, e))
        Cs = [x[0] for x in sel]
        Ds = [x[1] for x in sel]
        joint = joint_empirical_period(Cs, Ds)
        assert joint == L, (q, n, joint, L)
        for c, d, e in sel:
            assert empirical_period(c, d) == e
        K = sum(2 * c.k - n for c in Cs)
        max_single = max(vals)
        branches = [{"k_C": c.k, "k_D": d.k, "deg_f": d.k - c.k, "e": e,
                     "p_C": p_str(F, c.p), "p_D": p_str(F, d.p)}
                    for c, d, e in sel]
        dw = [(min_weight_in(c), min_weight_outside(c, d))
              for (c, d, _e) in sel]
        rows.append({"q": q, "n": n, "N": 3 * n, "no_go": False, "K": K,
                     "d_C_branches": [x[0] for x in dw],
                     "d_D_branches": [x[1] for x in dw],
                     "branches": branches, "e_branches": list(tri), "e_R": L,
                     "max_e_branch": max(tri),
                     "min_max_branch_order": max(tri),
                     "max_single_branch_period": max_single,
                     "needs_fusion": L > max_single,
                     "min_deg_f": min(b["deg_f"] for b in branches),
                     "window_ring_cells": L - 1,
                     "window_physical_qudits": 3 * (L - 1) + 1,
                     "cell_aligned_offsets": L - 1,
                     "nontrivial_dual_containing_codes": len(dc)})
        log(f"  q={q:2d} n={n:2d}: e_R = lcm{tuple(tri)} = {L} using branches of "
            f"period {tuple(tri)} (best single branch = {max_single}, "
            f"fusion {'STRICTLY NEEDED' if L > max_single else 'not needed'}; "
            f"min_i deg f_i = {rows[-1]['min_deg_f']})  K = {K}  "
            f"window <= {L - 1} cells = {3 * (L - 1)} cell-aligned offsets; "
            f"d_C = {[x[0] for x in dw]}, d_D = {[x[1] for x in dw]}")
    return rows


def _q_group(q, n):
    """the subgroup <q> of (Z/n)^*, for the dual-containing existence criterion."""
    g, cur = {1 % n}, q % n
    while cur not in g:
        g.add(cur)
        cur = (cur * q) % n
    return g


def dual_containing_census(F, n):
    """(number of nontrivial dual-containing cyclic codes, -1 in <q> mod n)."""
    if 2 ** num_irreducible_factors(F, n) > CODE_CAP:
        return None, (-1) % n in _q_group(F.p, n)
    codes = all_cyclic_codes(F, n)
    cnt = sum(1 for C in codes if C.is_self_orthogonal() and C.k < n)
    minus1 = (-1) % n in _q_group(F.p, n)
    return cnt, minus1


# ======================================================================
# TABLE 4 -- families attaining the maximal window e_R = n
# ======================================================================
def factor(n):
    out, d = [], 2
    while d * d <= n:
        if n % d == 0:
            a = 0
            while n % d == 0:
                n //= d
                a += 1
            out.append((d, a))
        d += 1
    if n > 1:
        out.append((n, 1))
    return out


def order_triple(n):
    """Triple of divisors of n, each >= 3, with lcm = n and the SMALLEST
    possible largest member (so that e_R = n is reached with the weakest
    individual branches).  Returns None if no such triple exists."""
    ds = [d for d in range(3, n + 1) if n % d == 0]
    best = None
    for m1 in ds:
        for m2 in ds:
            for m3 in ds:
                if lcm(m1, m2, m3) != n:
                    continue
                key = (max(m1, m2, m3), m1 + m2 + m3)
                if best is None or key < best[0]:
                    best = (key, [m1, m2, m3])
    return None if best is None else best[1]


def table_optimal():
    """Closed-form maximally synchronizing family: three linear branches
    C_i = <x - a_i> with ord(a_i) = m_i >= 3, lcm(m_1,m_2,m_3) = n,
    D_i = F_q^n.  Available whenever n | q-1, so every m | n occurs."""
    rows = []
    for q in [7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 61, 73, 97, 101]:
        for n in [m for m in range(4, q) if (q - 1) % m == 0]:
            ms = order_triple(n)
            if ms is None:
                continue
            F = GF(q)
            branches, ok = [], True
            for m in ms:
                lb = linear_branch(q, n, m)
                if lb is None:
                    ok = False
                    break
                C = QCyclicCode(F, lb[1], lb[2])
                D = QCyclicCode(F, lb[1], lb[3])
                if not C.is_self_orthogonal():
                    ok = False
                    break
                branches.append((C, D, m))
            if not ok:
                continue
            Cs = [b[0] for b in branches]
            Ds = [b[1] for b in branches]
            assert joint_empirical_period(Cs, Ds) == n
            K = sum(2 * c.k - n for c in Cs)
            rows.append({"q": q, "n": n, "N": 3 * n, "K": K,
                         "branch_orders": ms, "e_R": n,
                         "max_branch_order": max(ms),
                         "relaxation_factor": round(n / max(ms), 3),
                         "window_ring_cells": n - 1,
                         "window_physical_qudits": 3 * (n - 1) + 1,
                         "k_C_per_branch": [c.k for c in Cs],
                         "d_C_per_branch": [min_weight_in(c) for c in Cs],
                         "d_D_per_branch": [min_weight_outside(c, d)
                                            for c, d in zip(Cs, Ds)]})
            log(f"  q={q:3d} n={n:2d}: branch orders {ms} -> e_R = {n} = n, "
                f"max branch order {max(ms)} (relaxation x{n / max(ms):.3g}; "
                f"NB max single-branch period is n, so this is a relaxation, "
                f"not a capability gain), "
                f"window <= {n - 1} cells, K = {K}, "
                f"d_C = {rows[-1]['d_C_per_branch']}, "
                f"d_D = {rows[-1]['d_D_per_branch']}")
    return rows


# ======================================================================
# TABLE 5 -- non-free R-cyclic codes (freeness is NOT assumed anywhere)
# ======================================================================
def table_nonfree():
    rows = []
    for q in (5, 7):
        F = GF(q)
        n = 4
        codes = all_cyclic_codes(F, n)
        seen = set()
        for a in codes:
            for b in codes:
                if a.k == b.k:
                    continue
                key = (a.k, b.k)
                if key in seen:
                    continue
                seen.add(key)
                RC = RCyclicCode(RingR(q), n, [a, b, a])
                rows.append({"q": q, "n": n, "k_vector": [a.k, b.k, a.k],
                             "log_q_card": RC.log_q_cardinality,
                             "R_rank": RC.R_rank, "free": RC.is_free_R_module,
                             "p_1": p_str(F, a.p), "p_2": p_str(F, b.p)})
    for (q, n, ks) in [(5, 4, [4, 4, 1]), (5, 4, [2, 2, 2]), (7, 4, [4, 4, 1])]:
        F = GF(q)
        codes = {c.k: c for c in all_cyclic_codes(F, n)}
        if all(k in codes for k in ks):
            RC = RCyclicCode(RingR(q), n, [codes[k] for k in ks])
            rows.append({"q": q, "n": n, "k_vector": ks,
                         "log_q_card": RC.log_q_cardinality,
                         "R_rank": RC.R_rank, "free": RC.is_free_R_module,
                         "p_1": p_str(F, codes[ks[0]].p),
                         "p_2": p_str(F, codes[ks[1]].p)})
    for r in rows:
        log(f"  q={r['q']} n={r['n']} k-vector {r['k_vector']}: "
            f"log_q|C| = {r['log_q_card']}, R-free = {r['free']}, "
            f"R-rank = {r['R_rank']}")
    return rows[:12]


# ======================================================================
# TABLE 6 -- edge cases / exclusions
# ======================================================================
def table_edge():
    out = [edge_case_char_two()]
    out.append({"case": "q = 3 (characteristic 3, odd)",
                "verdict": "ADMITTED: 0, 1, -1 are pairwise distinct mod 3, so "
                           "v^3 - v = v(v-1)(v+1) is squarefree with linear "
                           "factors; the three idempotents exist and are "
                           "primitive.  q = 3 is NOT excluded."})
    out.append({"case": "q = 2 (characteristic 2)",
                "verdict": "EXCLUDED as a model: v^3 - v = v(v+1)^2, so "
                           "R = F_2 x F_2[eps]/(eps^2) is not reduced, the "
                           "third CRT component is not a field, and "
                           "e_2 = (v^2+v)/2 does not exist (2 is not a unit)."})
    out.append({"case": "gcd(n,q) > 1 (repeated-root case)",
                "verdict": "EXCLUDED: x is a zero divisor modulo x^n - 1, the "
                           "CRT F_q[x]/(x^n-1) = prod F_q[x]/(f_i) fails, and "
                           "the order criterion needs f(0) != 0."})
    out.append({"case": "k_D = k_C in a branch (f = 1)",
                "verdict": "Excluded as a synchronization branch: e = 1, the "
                           "branch contributes no nonzero offset to alpha "
                           "recovery, and lcm ignores it (identity element)."})
    out.append({"case": "D = F_q^n (maximal marker code)",
                "verdict": "Admitted and extremal: it makes e as large as "
                           "possible (e = ord(a) for C = <x-a>), but then "
                           "d_D = min wt(D\\C) = 1 because every weight-one "
                           "vector lies outside C.  Maximum window is bought "
                           "with distance 1: a genuine window/distance "
                           "trade-off, not a defect of the construction."})
    out.append({"case": "k_C = n/2 exactly (self-dual branch)",
                "verdict": "Admitted but yields K_i = 2k_C - n = 0 in that "
                           "branch; the branch still synchronizes but carries "
                           "no logical qudit."})
    out.append({"case": "no nontrivial dual-containing cyclic code (e.g. q=3 "
                        "or q=7, n=10)",
                "verdict": "STRUCTURAL NO-GO for the branch search, not a bug: "
                           "x^10 - 1 factors into irreducibles that are all "
                           "self-reciprocal, so the only dual-containing cyclic "
                           "code is the whole space; no branch exists at all. "
                           "General criterion (proved in the manuscript): with "
                           "gcd(n,q)=1 a nontrivial dual-containing cyclic code "
                           "exists iff -1 is NOT in the subgroup <q> of "
                           "(Z/n)^*; see table 7, verified exhaustively."})
    for o in out:
        log("  edge:", o)
    return out


# ======================================================================
# TABLE 7 -- existence criterion for nontrivial dual-containing branches
# ======================================================================
def table_existence():
    rows = []
    for q in (3, 5, 7, 11, 13):
        for n in range(3, 17):
            if n % q == 0:
                continue
            cnt, minus1 = dual_containing_census(GF(q), n)
            if cnt is None:
                continue
            pred = (cnt == 0)
            ok = (pred == minus1)
            # direct check of Lemma 4.7 (e | n) and Theorem 4.8 (max E = n
            # whenever E is non-empty) for the cases small enough to enumerate.
            maxper = None
            nvals = 0
            if 4 ** num_irreducible_factors(GF(q), n) <= 30000:
                tab = achievable_periods(GF(q), n)
                if tab:
                    vals = [k for k in tab if k is not None]
                    nvals = len(vals)
                    if vals:
                        maxper = max(vals)
                        if not all(n % e == 0 for e in vals):
                            raise AssertionError(("e does not divide n", q, n, vals))
                        if maxper != n:
                            raise AssertionError(("max E != n", q, n, vals))
            rows.append({"q": q, "n": n, "nontrivial_dual_containing": cnt,
                         "minus1_in_q_group": minus1,
                         "criterion_says_no_go": minus1, "criterion_ok": ok,
                         "enumeration_feasible": maxper is not None,
                         "distinct_periods": nvals,
                         "max_branch_period": maxper,
                         "max_period_is_n": (maxper == n) if maxper else None})
            log(f"  q={q:2d} n={n:2d}: nontrivial dual-containing codes = "
                f"{cnt:4d}; -1 in <q> mod n = {minus1}  "
                f"{'OK' if ok else 'MISMATCH'}"
                + (f";  e | n for all {nvals} distinct periods, max period = "
                   f"{maxper} = n" if maxper else ";  (enumeration skipped)"))
            if not ok:
                raise AssertionError((q, n, cnt, minus1))
    return rows


# ======================================================================
# artifact writing
# ======================================================================
def write_artifacts():
    os.makedirs(os.path.join(ROOT, "data"), exist_ok=True)
    os.makedirs(os.path.join(ROOT, "results"), exist_ok=True)
    os.makedirs(os.path.join(ROOT, "tables"), exist_ok=True)
    with open(os.path.join(ROOT, "results", "experiments_log.txt"), "w") as fh:
        fh.write("\n".join(LOG) + "\n")
    with open(os.path.join(ROOT, "data", "tables.json"), "w") as fh:
        json.dump(TABLES, fh, indent=1)
    if "single" in TABLES:
        _csv("table2_single_branch.csv", TABLES["single"])
    if "fusion" in TABLES:
        flat = []
        for r in TABLES["fusion"]:
            base = {k: v for k, v in r.items() if k != "branches"}
            for i, b in enumerate(r.get("branches", [{}])):
                flat.append({**base, "branch": i + 1, **b})
        _csv("table3_fusion.csv", flat)
    if "optimal" in TABLES:
        _csv("table4_optimal.csv", TABLES["optimal"])
    if "nonfree" in TABLES:
        _csv("table5_nonfree.csv", TABLES["nonfree"])
    if "existence" in TABLES:
        _csv("table7_existence.csv", TABLES["existence"])
    if "flagship" in TABLES:
        _csv("table8_flagship.csv", TABLES["flagship"])
    if "dconstrained" in TABLES:
        _csv("table9_distance_constrained.csv", TABLES["dconstrained"])
    if "hybrid" in TABLES:
        _csv("table10_hybrid.csv", TABLES["hybrid"])


def _csv(name, rows):
    if not rows:
        return
    keys = sorted({k for r in rows for k in r})
    with open(os.path.join(ROOT, "tables", name), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k) for k in keys})


# ======================================================================
# TABLE 8 -- flagship branches: large window AND d >= 2
# ======================================================================
FLAGSHIP = [
    (3, 13, [1, 0, 1, 0, 0, 1, 1], [2, 1, 1, 1]),
    (5, 8, [1, 2, 3, 1], [3, 1]),
    (7, 6, [6, 2, 1], [5, 1]),
    (11, 5, [3, 9, 1], [2, 1]),
    (2, 7, [1, 1, 0, 1], [1]),          # char 2 reference point (Hamming)
    (2, 15, [1, 0, 0, 1, 1], [1]),      # char 2 reference point (BCH)
]


def table_flagship():
    rows = []
    for (q, n, cp, dp) in FLAGSHIP:
        F = GF(q)
        try:
            C = QCyclicCode(F, n, cp)
            D = QCyclicCode(F, n, dp)
        except ValueError:
            continue
        if not (D.contains(C) and C.is_self_orthogonal()):
            log(f"  SKIP flagship q={q} n={n}: hypothesis fails")
            continue
        f, _ = p_divmod(F, C.p, D.p)
        e = empirical_period(C, D)
        assert e == poly_order_x(F, f, bound=n)
        dC = min_weight_in(C)
        dD = min_weight_in(D)
        Cperp = C.dual
        d_basic = min_weight_of_difference(C, Cperp)       # min wt(C \ C^perp)
        d_hyb = min_weight_of_difference(D, Cperp)         # min wt(D \ C^perp)
        K1 = 2 * C.k - n
        rows.append({"q": q, "n": n, "p_C": p_str(F, C.p), "p_D": p_str(F, D.p),
                     "k_C": C.k, "k_D": D.k, "deg_f": p_deg(f), "e": e,
                     "d_C": dC, "d_D": dD,
                     "d_basic_inner": d_basic, "d_hybrid_inner": d_hyb,
                     "window_cells": min(e, n) - 1,
                     "degree_bound_window": D.k - C.k - 1,
                     "N_ring": 3 * n, "K_ring_3copies": 3 * K1,
                     "K_branch": K1,
                     "ring_D": d_hyb, "ring_d_basic": d_basic})
        log(f"  q={q:2d} n={n:2d}: C[{n},{C.k},{dC}] D[{n},{D.k},{dD}] "
            f"deg f={p_deg(f)} e={e} -> window {min(e,n)-1} cells "
            f"(degree bound: {D.k-C.k-1}); inner separations "
            f"min wt(C\\C^perp)={d_basic}, min wt(D\\C^perp)={d_hyb}; "
            f"3-copy ring code: N={3*n}, K={3*K1}, D>={d_hyb}")
    return rows


# ======================================================================
# TABLE 9 -- distance-constrained fusion: can fusion regain window?
# ======================================================================
DC_CASES = [(3, 13), (3, 16), (5, 8), (5, 12), (5, 16), (7, 6), (7, 9),
            (7, 12), (7, 15), (11, 14), (11, 16), (13, 4), (13, 8),
            (13, 12), (13, 16)]


def table_dconstrained():
    rows = []
    for (q, n) in DC_CASES:
        F = GF(q)
        t = num_irreducible_factors(F, n)
        if 4 ** t > 120_000:
            log(f"  SKIP q={q} n={n}: chain search too large")
            continue
        codes = all_cyclic_codes(F, n)
        tab = {}
        for C in codes:
            if not C.is_self_orthogonal():
                continue
            for D in codes:
                if not (D.contains(C) and C.k < D.k):
                    continue
                w = min_weight_outside(C, D, cap=120000)
                if w is None or w < 2:
                    continue
                tab.setdefault(empirical_period(C, D), []).append((C, D, w))
        if not tab:
            log(f"  q={q:2d} n={n:2d}: no branch has d(D\C) >= 2")
            rows.append({"q": q, "n": n, "E2": [], "max_single": None,
                         "max_lcm3": None, "gain": False})
            continue
        vals = sorted(tab)
        mx = max(vals)
        L = max(lcm(*tr) for tr in combinations_with_replacement(vals, 3))
        wit = min((tr for tr in combinations_with_replacement(vals, 3)
                   if lcm(*tr) == L), key=lambda tr: (max(tr), sum(tr)))
        rows.append({"q": q, "n": n, "E2": vals, "max_single": mx,
                     "max_lcm3": L, "gain": L > mx, "witness": list(wit),
                     "d_of_witness": [tab[e][0][2] for e in wit],
                     "n_in_E2": n in vals})
        log(f"  q={q:2d} n={n:2d}: periods with d>=2: {vals}  max single = {mx}"
            f"  max lcm(3) = {L}  -> {'GAIN' if L > mx else 'no fusion gain'}"
            f"  (witness {tuple(wit)}, d = {[tab[e][0][2] for e in wit]})")
    return rows


# ======================================================================
# TABLE 10 -- hybrid (message-carrying) markers: exact collision set
# ======================================================================
HY_BRANCHES = FLAGSHIP[:4]


def message_set(F, y):
    """M = 1 + span_F{x,...,x^y}: coefficient vectors, constant term 1."""
    out = []
    for tail in product(range(F.p), repeat=y):
        out.append([1] + list(tail))
    return out


def hybrid_collisions(F, f, y, n):
    """differences delta in [1,n] at which some pair of messages collides:
    f | x^delta b - b' for some b,b' in M, i.e. x^delta b mod f in M."""
    M = message_set(F, y)
    mset = {tuple(m): m for m in M}
    cols = []
    for delta in range(1, n + 1):
        xd = [0] * delta + [1]
        hit = False
        for b in M:
            r = p_mod(F, p_mul(F, xd, b), f)
            t = tuple(r + [0] * max(0, len(b) - len(r)))
            if len(t) <= y + 1 and t in mset:
                hit = True
                break
        if hit:
            cols.append(delta)
    return [d for d in cols if d % n], M


def table_hybrid():
    rows = []
    for (q, n, cp, dp) in HY_BRANCHES:
        F = GF(q)
        C = QCyclicCode(F, n, cp)
        D = QCyclicCode(F, n, dp)
        f, _ = p_divmod(F, C.p, D.p)
        e = empirical_period(C, D)
        for y in (0, 1, 2):
            cols, M = hybrid_collisions(F, f, y, n)
            first = min(cols) if cols else None
            wex = (first - 1) if first else n - 1
            wdeg = p_deg(f) - y - 1
            rows.append({"q": q, "n": n, "p_C": p_str(F, C.p),
                         "p_D": p_str(F, D.p), "f": p_str(F, f),
                         "deg_f": p_deg(f), "e": e, "y": y,
                         "n_messages": len(M),
                         "collision_deltas": cols, "first_collision": first,
                         "W_exact": wex, "W_degree_bound": wdeg,
                         "degree_bound_sharp": wex == max(wdeg, -1),
                         "degree_bound_too_weak": wex > max(wdeg, -1)})
            log(f"  q={q:2d} n={n:2d} y={y}: f = {p_str(F, f)} (deg {p_deg(f)}, "
                f"e = {e}), {len(M)} messages, collisions at delta in "
                f"{cols}; exact window W <= {wex}, degree-type guarantee "
                f"W < {p_deg(f) - y}"
                + ("  [guarantee NOT sharp]" if wex > max(wdeg, -1) else ""))
    return rows


TASKS = [("table2", "TABLE 2: single-branch threshold vs the degree-of-f bound",
          "single", table_single),
         ("table3", "TABLE 3: fusion over R = F_q[v]/(v^3-v)",
          "fusion", table_fusion),
         ("table4", "TABLE 4: closed-form maximally synchronizing family (e_R = n)",
          "optimal", table_optimal),
         ("table5", "TABLE 5: non-free cyclic codes over R",
          "nonfree", table_nonfree),
         ("table6", "TABLE 6: edge cases", "edge", table_edge),
         ("table7", "TABLE 7: existence criterion for nontrivial branches",
          "existence", table_existence),
         ("table8", "TABLE 8: flagship branches (large window and d >= 2)",
          "flagship", table_flagship),
         ("table9", "TABLE 9: distance-constrained fusion (d(D\\C) >= 2)",
          "dconstrained", table_dconstrained),
         ("table10", "TABLE 10: hybrid markers -- exact collision set",
          "hybrid", table_hybrid)]


def main(argv):
    want = [a for a in argv[1:] if a.startswith("table")] or [t[0] for t in TASKS]
    for key, title, slot, fn in TASKS:
        if key not in want:
            continue
        log("=" * 74)
        log(title)
        log("=" * 74)
        t0 = time.time()
        TABLES[slot] = fn()
        log(f"  [{key}: {time.time() - t0:.1f} s, {len(TABLES[slot])} rows]")
        write_artifacts()
    log("DONE")


if __name__ == "__main__":
    main(sys.argv)
