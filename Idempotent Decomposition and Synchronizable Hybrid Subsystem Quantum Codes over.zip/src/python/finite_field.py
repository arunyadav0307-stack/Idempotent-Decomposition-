"""
finite_field.py -- Minimal exact arithmetic in F_q (q prime) and F_q[x].

Design notes
------------
* A field element is a Python int in range(p).
* A polynomial is a list [a0, a1, ..., ad] of coefficients (low degree first),
  over F_p, with no "should be int" assumptions elsewhere.
* All routines are exact (no floating point).

The whole research package uses q an ODD PRIME with q % 3 != 0, i.e. the theory
needs char F_q not in {2,3}.  See ring_r.py for why.
"""

from __future__ import annotations
from typing import List, Sequence, Tuple


# ----------------------------------------------------------------------
# F_p
# ----------------------------------------------------------------------
class GF:
    """Prime field F_p."""

    def __init__(self, p: int):
        if p < 2:
            raise ValueError("p must be >= 2")
        # primality
        if any(p % d == 0 for d in range(2, int(p ** 0.5) + 1)):
            raise ValueError(f"{p} is not prime")
        self.p = p

    def add(self, a: int, b: int) -> int:
        return (a + b) % self.p

    def sub(self, a: int, b: int) -> int:
        return (a - b) % self.p

    def neg(self, a: int) -> int:
        return (-a) % self.p

    def mul(self, a: int, b: int) -> int:
        return (a * b) % self.p

    def inv(self, a: int) -> int:
        if a % self.p == 0:
            raise ZeroDivisionError
        return pow(a, self.p - 2, self.p)

    def div(self, a: int, b: int) -> int:
        return self.mul(a, self.inv(b))

    def elements(self):
        return range(self.p)

    def is_square(self, a: int) -> bool:
        if a % self.p == 0:
            return True
        return pow(a % self.p, (self.p - 1) // 2, self.p) == 1

    def __repr__(self):
        return f"F_{self.p}"


# ----------------------------------------------------------------------
# polynomials over F_p  (coefficient lists, low -> high)
# ----------------------------------------------------------------------
def p_trim(a: Sequence[int]) -> List[int]:
    a = list(a)
    while len(a) > 1 and a[-1] == 0:
        a.pop()
    if not a:
        a = [0]
    return a


def p_is_zero(a: Sequence[int]) -> bool:
    return all(c == 0 for c in a)


def p_deg(a: Sequence[int]) -> int:
    a = p_trim(a)
    if p_is_zero(a):
        return -1
    return len(a) - 1


def p_add(F: GF, a, b) -> List[int]:
    n = max(len(a), len(b))
    out = [0] * n
    for i in range(n):
        x = a[i] if i < len(a) else 0
        y = b[i] if i < len(b) else 0
        out[i] = F.add(x, y)
    return p_trim(out)


def p_sub(F: GF, a, b) -> List[int]:
    n = max(len(a), len(b))
    out = [0] * n
    for i in range(n):
        x = a[i] if i < len(a) else 0
        y = b[i] if i < len(b) else 0
        out[i] = F.sub(x, y)
    return p_trim(out)


def p_mul(F: GF, a, b) -> List[int]:
    if p_is_zero(a) or p_is_zero(b):
        return [0]
    out = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        if x == 0:
            continue
        for j, y in enumerate(b):
            if y:
                out[i + j] = F.add(out[i + j], F.mul(x, y))
    return p_trim(out)


def p_scale(F: GF, a, c: int) -> List[int]:
    return p_trim([F.mul(x, c) for x in a])


def p_monic(F: GF, a) -> List[int]:
    a = p_trim(a)
    if p_is_zero(a):
        return [0]
    inv = F.inv(a[-1])
    return p_scale(F, a, inv)


def p_divmod(F: GF, a, b) -> Tuple[List[int], List[int]]:
    """Return (quotient, remainder) with a = q*b + r, deg r < deg b."""
    a = p_trim(a)
    b = p_trim(b)
    if p_is_zero(b):
        raise ZeroDivisionError("polynomial division by zero")
    if p_deg(a) < p_deg(b):
        return [0], a
    inv_lead = F.inv(b[-1])
    r = list(a)
    q = [0] * (p_deg(a) - p_deg(b) + 1)
    db = p_deg(b)
    while p_deg(r) >= db and not p_is_zero(r):
        shift = p_deg(r) - db
        coef = F.mul(r[-1], inv_lead)
        q[shift] = F.add(q[shift], coef)
        for i in range(db + 1):
            r[shift + i] = F.sub(r[shift + i], F.mul(coef, b[i]))
        r = p_trim(r)
    return p_trim(q), p_trim(r)


def p_mod(F: GF, a, m) -> List[int]:
    return p_divmod(F, a, m)[1]


def p_gcd(F: GF, a, b) -> List[int]:
    a, b = p_trim(a), p_trim(b)
    while not p_is_zero(b):
        a, b = b, p_mod(F, a, b)
    return p_monic(F, a)


def p_xgcd(F: GF, a, b):
    """Extended Euclid: returns (g, s, t) with s*a + t*b = g, g monic."""
    old_r, r = p_trim(a), p_trim(b)
    old_s, s = [1], [0]
    old_t, t = [0], [1]
    while not p_is_zero(r):
        q, rem = p_divmod(F, old_r, r)
        old_r, r = r, rem
        old_s, s = s, p_sub(F, old_s, p_mul(F, q, s))
        old_t, t = t, p_sub(F, old_t, p_mul(F, q, t))
    if p_is_zero(old_r):
        return [0], [0], [0]
    c = F.inv(old_r[-1])
    return p_scale(F, old_r, c), p_scale(F, old_s, c), p_scale(F, old_t, c)


def p_powmod(F: GF, base, exp: int, m) -> List[int]:
    result = [1]
    b = p_mod(F, base, m)
    while exp > 0:
        if exp & 1:
            result = p_mod(F, p_mul(F, result, b), m)
        b = p_mod(F, p_mul(F, b, b), m)
        exp >>= 1
    return result


def p_pow(F: GF, base, exp: int) -> List[int]:
    result = [1]
    b = list(base)
    while exp > 0:
        if exp & 1:
            result = p_mul(F, result, b)
        b = p_mul(F, b, b)
        exp >>= 1
    return result


def p_is_irreducible(F: GF, f) -> bool:
    """Rabin's irreducibility test (exact)."""
    f = p_monic(F, f)
    d = p_deg(f)
    if d <= 0:
        return False
    if d == 1:
        return True
    x = [0, 1]
    for l in _prime_factors(d):
        h = p_powmod(F, x, F.p ** (d // l), f)
        if p_deg(p_gcd(F, p_sub(F, h, x), f)) > 0:
            return False
    return p_is_zero(p_sub(F, p_powmod(F, x, F.p ** d, f), x))


def _prime_factors(n: int):
    out, m, p = [], n, 2
    while p * p <= m:
        if m % p == 0:
            out.append(p)
            while m % p == 0:
                m //= p
        p += 1
    if m > 1:
        out.append(m)
    return out


def p_is_squarefree(F: GF, f) -> bool:
    f = p_monic(F, f)
    if p_deg(f) <= 0:
        return True
    df = p_derivative(F, f)
    if p_is_zero(df):
        return False
    return p_deg(p_gcd(F, f, df)) == 0


def p_derivative(F: GF, a) -> List[int]:
    a = p_trim(a)
    return p_trim([F.mul(i % F.p, a[i]) for i in range(1, len(a))]) if len(a) > 1 else [0]


def p_eval(F: GF, a, x: int) -> int:
    val = 0
    for c in reversed(a):
        val = F.add(F.mul(val, x), c)
    return val


def p_roots(F: GF, a) -> List[int]:
    return [x for x in F.elements() if p_eval(F, a, x) == 0]


def p_ddf(F: GF, f) -> List[Tuple[List[int], int]]:
    """Distinct-degree factorization of a monic squarefree f.

    Returns list of (product_of_irreducibles_of_degree_d, d) with matching degrees.
    """
    f = p_monic(F, f)
    out = []
    d = 1
    x = [0, 1]
    h = x
    while p_deg(f) >= 2 * d:
        h = p_powmod(F, h, F.p, f)
        g = p_gcd(F, p_sub(F, h, x), f)
        if p_deg(g) > 0:
            out.append((g, d))
            f = p_divmod(F, f, g)[0]
        d += 1
    if p_deg(f) > 0:
        out.append((f, d))
    return out


def p_edf(F: GF, f, d: int, seed: int = 1, _depth: int = 0) -> List[List[int]]:
    """Equal-degree factorization: split f (product of irreducibles of degree d)."""
    if p_deg(f) == d:
        return [p_monic(F, f)]
    if _depth > 500:
        raise RuntimeError("EDF failed to split")
    rng = _Lcg(seed)
    while True:
        a = [rng.randrange(F.p) for _ in range(p_deg(f))]
        if p_is_zero(a) or p_deg(a) == 0:
            continue
        # Cantor-Zassenhaus for odd q: gcd(a^((q^d-1)/2) - 1, f)
        e = (F.p ** d - 1) // 2
        h = p_sub(F, p_powmod(F, a, e, f), [1])
        g = p_gcd(F, h, f)
        if 0 < p_deg(g) < p_deg(f):
            return p_edf(F, g, d, seed + 1, _depth + 1) + p_edf(F, p_divmod(F, f, g)[0], d, seed + 2, _depth + 1)


class _Lcg:
    def __init__(self, seed: int):
        self.s = seed * 6364136223846793005 + 1442695040888963407

    def randrange(self, n: int) -> int:
        self.s = (self.s * 6364136223846793005 + 1442695040888963407) & ((1 << 64) - 1)
        return (self.s >> 17) % n


def p_factor(F: GF, f) -> List[List[int]]:
    """Complete factorization into monic irreducibles (f monic and squarefree)."""
    f = p_monic(F, f)
    out: List[List[int]] = []
    d, x, h = 1, [0, 1], [0, 1]
    while p_deg(f) >= 2 * d:
        h = p_powmod(F, h, F.p, f)
        g = p_gcd(F, p_sub(F, h, x), f)
        if p_deg(g) > 0:
            if p_deg(g) == d:
                out.append(p_monic(F, g))
            else:
                out.extend(p_monic(F, t) for t in p_edf(F, g, d))
            f = p_divmod(F, f, g)[0]
        d += 1
    if p_deg(f) > 0:
        out.append(p_monic(F, f))
    return out


def p_is_primitive_root_mod(F: GF, x: int, m: int) -> bool:
    """True if x has multiplicative order m modulo F_p (m | p-1)."""
    if m == 1:
        return x % F.p == 1
    if pow(x % F.p, m, F.p) != 1:
        return False
    for d in range(2, m):
        if m % d == 0 and pow(x, m // d, F.p) == 1:
            return False
    return True


def multiplicative_order(F: GF, x: int) -> int:
    x %= F.p
    if x == 0:
        raise ZeroDivisionError
    m = 1
    cur = x
    while cur != 1:
        cur = F.mul(cur, x)
        m += 1
        if m > F.p:
            raise RuntimeError("no order")
    return m


def poly_order_x(F: GF, f, bound: int | None = None) -> int:
    """Smallest delta >= 1 with x^delta == 1 (mod f).

    f must be monic, coprime to x.  Equivalently: the multiplicative order of
    the class of x in (F_q[x]/(f))^*.  If f | x^n - 1 then the order divides n,
    and passing bound = n keeps the search cheap.
    """
    f = p_monic(F, f)
    d = p_deg(f)
    if d <= 0:
        return 1
    x = [0, 1]
    cur = p_mod(F, x, f)
    if cur == [1]:
        return 1
    delta = 1
    # order divides |(F_q[x]/(f))^*| <= q^d - 1 ; but for f | x^n - 1 it divides n.
    limit = max(2, bound) if bound is not None else max(2, F.p ** d - 1)
    while delta <= limit + 1:
        if cur == [1]:
            return delta
        cur = p_mod(F, p_mul(F, cur, x), f)
        delta += 1
    raise RuntimeError("order not found (should not happen)")


def p_reverse(F: GF, a, deg: int | None = None) -> List[int]:
    """Reciprocal polynomial x^m a(1/x), padded to degree m (= deg a if None)."""
    a = p_trim(a)
    if deg is None:
        deg = p_deg(a)
    out = [0] * (deg + 1)
    for i, c in enumerate(a):
        if i <= deg:
            out[deg - i] = c
    return p_trim(out)


def p_str(F: GF, a) -> str:
    a = p_trim(a)
    if p_is_zero(a):
        return "0"
    terms = []
    for i, c in enumerate(a):
        if c == 0:
            continue
        if i == 0:
            terms.append(f"{c}")
        elif i == 1:
            terms.append(f"{c}*x" if c != 1 else "x")
        else:
            terms.append(f"{c}*x^{i}" if c != 1 else f"x^{i}")
    return " + ".join(terms)
