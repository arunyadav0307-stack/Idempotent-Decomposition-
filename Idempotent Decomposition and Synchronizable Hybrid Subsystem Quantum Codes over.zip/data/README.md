# data/

| File | Content | Produced by |
|---|---|---|
| `tables.json` | nine data tables (209 rows) in JSON form; the authoritative form of Tables 2–10 | `src/python/experiments.py` |
| `examples.csv`, `examples.json` | the theory suite's example dumps: 11 **classical** fusion triples (quantum condition dropped — these are the Corollary 4.11 contrast witnesses), 16 maximal-window families (with per-branch `self_orthogonal` flags), and the 8794-pair single-component summary | `tests/test_theory.py` |
| `flagship_candidates.json` | the flagship-branch candidates found during Phase 10 (superseded by Table 8, kept for provenance) | `src/python/experiments.py` (earlier version) |

**Do not conflate the two fusion data sets.** `tables.json["fusion"]` requires
`C^⊥ ⊆ C` in every branch and shows no gain; `examples.json["fusion"]` is the
classical setting where amplification does occur. The manuscript cites the first
for Table 3 and the second for Corollary 4.11.
