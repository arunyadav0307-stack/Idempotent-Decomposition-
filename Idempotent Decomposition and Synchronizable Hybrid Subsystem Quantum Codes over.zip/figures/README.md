# Figures

| File | Content |
|---|---|
| `interleaved_lift.svg` | Model A: the interleaving of three component codewords into one `3n`-qudit word, and the action of a shift by one ring cell (= three qudit positions). It also records the window bound `a_l + a_r ≤ e_R − 1` and the no-gain reference. |

Notes.

* The figure is a reading aid; it carries no data. Every numerical statement in
  the paper is in `tables/` or `results/`.
* It is an SVG with inline styling only (no external fonts, no images), so it
  renders in any viewer, including sandboxed ones.
* `FINAL_MANUSCRIPT.tex` deliberately does **not** include it via
  `\includegraphics`, so the LaTeX source has no external dependencies.
