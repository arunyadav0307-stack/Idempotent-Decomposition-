# Manuscript + code bundle

**Title:** *Idempotent Decomposition and Synchronizable Hybrid Subsystem Quantum
Codes over `F_q[v]/(v³ − v)`: Sharp Misalignment Thresholds and a No-Gain Theorem
for Ring Fusion.*

**Status:** VALIDATED — complete manuscript (PDF + TeX + Markdown), verified
bibliography, Python implementation, data tables and test suites. This bundle
keeps the project layout (`src/python`, `tests`, `data`, `results`) so that every
script and test runs out of the box.

---

## 1. Where to start

| I want to… | Open |
|---|---|
| read the paper | `manuscript/FINAL_MANUSCRIPT.pdf` (17 pages) |
| compile or edit it | `manuscript/FINAL_MANUSCRIPT.tex` + `bibliography/references.bib` |
| read it as plain text | `manuscript/FINAL_MANUSCRIPT.md` |
| read the code | `src/python/` (7 modules, standard library only) |
| get the numbers | `data/tables.json`, `tables/table*.csv` |
| check the numbers | `tests/`, `results/` |
| the one-page summary of the whole project | `FINAL_RESEARCH_REPORT.md` |

## 2. Tree

```
manuscript/
  FINAL_MANUSCRIPT.pdf       compiled paper, 17 pp., pdfTeX, 0 errors
  FINAL_MANUSCRIPT.tex       LaTeX source: ASCII-only, amsart, self-contained
                             reference list (two pdflatex passes; no BibTeX run)
  FINAL_MANUSCRIPT.md        Markdown source of the same text
  PDF_COMPILATION_STATUS.md  build record, compiler statistics, how to rebuild

bibliography/
  references.bib             8 cited entries
  references_verified.csv    13 verified records (incl. 5 background), each with
                             its verification route and any declared caveat

src/python/
  finite_field.py            GF(q) arithmetic and polynomials (prime q)
  ring_r.py                  R = F_q[v]/(v^3-v): idempotents, CRT, duality
  cyclic_codes.py            cyclic codes, divisors, R-cyclic codes, cardinality
  synchronization.py         syndrome maps, periods, collision sets, windows
  quantum_css.py             Pauli groups, CSS codes, stabiliser rank, distances
  experiments.py             the nine data tables (Tables 2-10)
  pdf_extract.py             helper for text extraction from a source PDF
src/tools/
  md2tex.py                  Markdown -> LaTeX converter that built the .tex
  build_pdf.sh               one-command PDF rebuild
src/magma/
  ring_qsc.m, verify_tables.m, README.md   MAGMA transcription - NOT executed here

tests/
  test_theorems.py           751 checks, 0 failures (sections A-G)
  test_theory.py             8794 branch pairs, 1026 windows, triples, ring algebra
  test_quantum.py            interleaved model, CSS parameters, recovery tables

data/       tables.json (209 rows, authoritative), examples.csv/json, README.md
tables/     table2, table3, table4, table5, table7, table8, table9, table10 (.csv)
results/    verification_report.md, *_checks.json, *_log.txt, experiments_run.txt
figures/    interleaved_lift.svg (Model A diagram), README.md

FINAL_RESEARCH_REPORT.md / .txt   the final report in the required fields
```

## 3. Reproduce everything

Run from the **top level of the unpacked bundle**:

```bash
python3 src/python/experiments.py     # nine data tables, 209 rows, ~14 s
python3 tests/test_theorems.py        # 751 checks            (~27 s)
python3 tests/test_theory.py          # 8794 branch pairs    (~7 min)
python3 tests/test_quantum.py         # quantum layer        (~2.5 min)
```

Requirements: Python 3.8+ only (standard library; no third-party packages). The
runs are deterministic — repeated runs produce byte-identical JSON/CSV.

Rebuilding the PDF (needs a TeX Live installation; the bundle ships the compiled
PDF so this is optional):

```bash
sh src/tools/build_pdf.sh             # two pdflatex passes into build/
# or manually, from the folder holding the .tex:
pdflatex FINAL_MANUSCRIPT.tex         # run it twice; no BibTeX needed
```

Required LaTeX packages: `lmodern`, `amsmath`, `amssymb`, `amsthm`, `array`,
`microtype`, `geometry`, `hyperref`.

## 4. Headline results

Over `R = F_q[v]/(v³ − v) ≅ F_q³` (q odd) an `R`-cyclic code is three cyclic codes
over `F_q` sharing one physical frame. The paper proves:

1. **Sharp threshold.** The correctable window of a branch is `e − 1` cells with
   `e = ord_x(p_C/p_D)`; collisions are exactly the multiples of `e`. The classical
   degree bound `k_D − k_C` is sufficient but never sharp — strictly beaten in
   **7883 of 8794** checked branch pairs (89.6 %), e.g. `q = 3, n = 13`: window 12
   against a bound of 2.
2. **Existence criterion.** A nontrivial dual-containing cyclic code of length
   `n` over `F_q` exists **iff** `−1 ∉ ⟨q⟩ mod n`; equivalently, the maximal
   misalignment `n − 1` is attainable iff that condition holds.
3. **No gain from fusion.** Every branch threshold divides `n` and one branch
   already attains `n` whenever any branch exists, so the fused threshold
   `lcm(e₁,e₂,e₃)` never beats the best single component: three-component ring
   fusion is **window-neutral**. It only *relaxes* the per-branch requirements
   (74 closed-form families, factor up to ×12). The obstruction is exactly the
   quantum condition `C^⊥ ⊆ C`: drop it and amplification returns
   ((2,2,5) → 10 over `F_7`, `n = 10`).
4. **Hybrid layer.** Exact marker criterion `f | x^δ b − b′`, the degree-type
   guarantee `|δ| + y ≥ deg f` (sometimes sharp, sometimes strictly weaker than
   the truth). Flagship: `[[39,3 : 9, 0, ≥3]]₃` with a 12-cell window.

## 5. Honesty notes

* The project's original headline (ring fusion enlarges the window) was **refuted
  by our own computation** and replaced by the proved no-gain theorem; the
  refutation and the repair are documented in the full package.
* The order criterion `e = ord_x(f)` in characteristic 2 is **Fujiwara's**; the
  maximum synchronisation distance `k_D − k_C` and the hybrid/subsystem framework
  belong to the source paper (Tansuwannont & Nemec, IEEE TQE 2026,
  arXiv:2409.11312). Everything of theirs used here is attributed, never claimed.
* `src/magma/*.m` was **not executed** (no MAGMA interpreter was available); it is
  included for independent use, and no number in the paper comes from it.
* One question is stated as open (Question 4.12, for distance constraint `t ≥ 4`).

## 6. Related archives

The complete research package with all audits and process records —
source audit, quantum-model decision, novelty gate, consistency and referee
audits, manuscript blueprint, 24 phase reports, changelog, checksum manifest and
licence notes — is `research_package_2026-09-29.zip` (89 files).
